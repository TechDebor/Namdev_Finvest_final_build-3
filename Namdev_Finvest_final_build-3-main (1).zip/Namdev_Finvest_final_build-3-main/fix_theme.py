# The inline theme variables that were in index.html but missing from the generated files
dark_theme_css = """
  <style>
    :root {
      --bg: #000000;
      --bg-surface: #0a0a0a;
      --bg-card: rgba(255,255,255,0.02);
      --text-primary: #ffffff;
      --text-secondary: #a0aec0;
      --text-muted: #718096;
      --brand: #ffffff;
      --border: rgba(255,255,255,0.08);
      --accent: #5149dc;
    }
    
    body {
      background-color: var(--bg);
      color: var(--text-primary);
    }

    .info-card { background: var(--bg-surface); border: 1px solid var(--border); }
    h1, h2, h3, h4, h5, h6 { color: var(--text-primary); }
    p { color: var(--text-secondary); }
  </style>
"""

pages_to_fix = ['about.html', 'investor.html', 'team.html', 'contact.html']

for page in pages_to_fix:
    try:
        with open(page, 'r') as f:
            content = f.read()
            
        # Insert the dark theme variables before </head>
        if "--bg: #000000" not in content:
            content = content.replace('</head>', dark_theme_css + '\n</head>')
            
            with open(page, 'w') as f:
                f.write(content)
            print(f"Injected Dark Theme into {page}")
    except Exception as e:
        print(f"Error fixing {page}: {e}")
