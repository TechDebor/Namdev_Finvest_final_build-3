import glob
import re

for f in glob.glob('*.html'):
    with open(f, 'r') as file:
        content = file.read()
    
    # replace inline color: #ffffff with color: var(--text-primary)
    content = content.replace('color: #ffffff;', 'color: var(--text-primary);')
    content = content.replace('color:#ffffff;', 'color: var(--text-primary);')
    
    # replace rgba backgrounds that assume dark mode
    content = content.replace('background: rgba(255, 255, 255, 0.015);', 'background: var(--bg-surface);')
    content = content.replace('background: rgba(255, 255, 255, 0.04);', 'background: var(--bg-elevated);')
    
    # replace inline border rgba
    content = content.replace('border: 1px solid rgba(255, 255, 255, 0.1);', 'border: 1px solid var(--mono-border);')
    
    with open(f, 'w') as file:
        file.write(content)

print("Fixed inline styles in HTML.")
