import glob

# Bulletproof wrapper for hero section
def wrap_hero(section_id, badge, title, desc):
    return f"""
    <section class="hero-quantum" id="{section_id}" style="padding-top: 140px; min-height: 50vh; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
      <div class="container" style="width: 100%; max-width: 900px; margin: 0 auto; display: block;">
        <div style="margin-bottom: 20px;">
          <span class="badge-quantum">{badge}</span>
        </div>
        <h1 style="font-family: 'Syne', sans-serif; font-size: 3.5rem; font-weight: 800; margin-bottom: 20px; letter-spacing: -0.05em; color: #ffffff;">{title}</h1>
        <p style="font-family: 'Space Grotesk', sans-serif; font-size: 1.2rem; color: #a0aec0; line-height: 1.6;">{desc}</p>
      </div>
    </section>
"""

head_nav = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Namdev Finvest | {TITLE}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;800&family=Space+Grotesk:wght@400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/components.css">
  <style>
    /* Absolute Dark Theme override */
    :root {
      --bg: #050505 !important;
      --bg-surface: #111111 !important;
      --bg-card: rgba(255,255,255,0.03) !important;
      --text-primary: #ffffff !important;
      --text-secondary: #a0aec0 !important;
      --text-muted: #718096 !important;
      --brand: #ffffff !important;
      --border: rgba(255,255,255,0.1) !important;
      --accent: #5149dc !important;
    }
    body { background-color: var(--bg) !important; color: var(--text-primary) !important; }
    .info-card { background: var(--bg-surface) !important; border: 1px solid var(--border) !important; border-radius: 12px; padding: 30px; transition: transform 0.3s; }
    .info-card:hover { transform: translateY(-5px); border-color: var(--brand) !important; }
    h1, h2, h3, h4, h5, h6 { color: var(--text-primary) !important; }
    p, li { color: var(--text-secondary) !important; }
    
    .dropdown-menu-simple { position: absolute; top: 100%; left: 0; background: var(--bg-surface); border: 1px solid var(--border); border-radius: 8px; padding: 10px 0; min-width: 220px; opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.3s ease; box-shadow: 0 10px 25px rgba(0,0,0,0.5); z-index: 100; }
    .nav-item-dropdown:hover .dropdown-menu-simple { opacity: 1; visibility: visible; transform: translateY(0); }
    .dropdown-menu-simple li { list-style: none; }
    .dropdown-menu-simple a { display: block; padding: 8px 20px; color: var(--text-primary); text-decoration: none; font-size: 0.85rem; font-weight: 500; transition: background 0.2s, color 0.2s; }
    .dropdown-menu-simple a:hover { background: #222222; color: #ffffff; }
    
    .section-stage { padding: 80px 20px; }
    .content-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; max-width: 1200px; margin: 0 auto; }
  </style>
</head>
<body style="background-color: #050505; color: #ffffff;">
  <div class="ambient-glow-layer"><div class="glow-orb glow-orb-1"></div><div class="glow-orb glow-orb-2"></div></div>
  <div class="cyber-grid-bg"></div>

  <div class="app-container">
    <header class="quantum-nav">
      <div class="container">
        <div class="nav-inner">
          <a href="index.html" class="brand-quantum">
            <div class="brand-emblem">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>
              </svg>
            </div>
            <div class="brand-text"><span class="brand-title">NAMDEV FINVEST</span><span class="brand-sub">NBFC // RBI REGISTERED</span></div>
          </a>
          <nav>
            <ul class="nav-menu">
              <li class="nav-item-dropdown">
                <a href="about.html" class="nav-link">About <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="about.html#who-we-are">Get to Know Us</a></li>
                  <li><a href="about.html#board">Board of Directors</a></li>
                  <li><a href="about.html#management">Management Team</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="index.html#products" class="nav-link">Products <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-quantum">
                  <li><a href="msme.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">MSME Business Loans</span></div></a></li>
                  <li><a href="two-wheeler.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Two Wheeler Loans</span></div></a></li>
                  <li><a href="lap.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Loan Against Property (LAP)</span></div></a></li>
                  <li><a href="solar.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Solar & Clean Energy</span></div></a></li>
                  <li><a href="tractor.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Tractor & Agri Loans</span></div></a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="investor.html" class="nav-link" style="color: #ff4757;">Investor <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="investor.html#partners">Growth Partners</a></li>
                  <li><a href="investor.html#policies">Codes and Policies</a></li>
                  <li><a href="investor.html#reports">Annual Report</a></li>
                  <li><a href="investor.html#esg">ESG</a></li>
                  <li><a href="investor.html#rta">Registrar & Transfer Agent</a></li>
                  <li><a href="investor.html#disclosures">Disclosure Under Regulation 62...</a></li>
                  <li><a href="investor.html#financials">Financial Performance</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="team.html" class="nav-link">Our Team <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="team.html#culture">Life at Namdev</a></li>
                  <li><a href="team.html#gallery">Gallery</a></li>
                  <li><a href="team.html#careers">Career - Apply for positions</a></li>
                </ul>
              </li>
              <li><a href="contact.html" class="nav-link">Contact</a></li>
              <li style="margin-left: 15px;"><a href="payment.html" class="btn-quantum" style="padding: 8px 16px; font-size: 0.85rem; text-decoration: none;">Pay EMI</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
"""

footer = """
    <footer class="quantum-footer">
      <div class="container">
        <div class="footer-bottom-bar" style="border: none; padding-top: 0;">
          <div>© 2026 Namdev Finvest Limited • CIN: U65921RJ1997PLC047090</div>
          <div class="status-indicator-strip"><span class="pulse-dot"></span> 137+ BRANCHES ACTIVE</div>
        </div>
      </div>
    </footer>
  </div>
</body>
</html>
"""

# ABOUT
about_hero = wrap_hero("who-we-are", "ESTABLISHED 2013", "Empowering Rural Bharat.", "Namdev Finvest Limited is a fast-growing RBI-registered NBFC dedicated to driving financial inclusion across India's underbanked sectors. With AUM crossing ₹1,200 Cr, we specialize in MSME, Green Finance, and Asset-backed lending.")
about_content = head_nav.replace("{TITLE}", "About Us") + about_hero + """
    <section class="section-stage" id="board">
      <div class="container">
        <h2 style="text-align:center; font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px; color: #fff;">Board of Directors & Management</h2>
        <div class="content-grid">
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Jitendra Tanwar</h3>
            <p style="color: #ff4757 !important; font-size: 0.9rem; font-weight:bold;">Managing Director & CEO</p>
            <p style="margin-top: 15px;">A visionary leader driving Namdev Finvest's mission to bridge the credit gap in semi-urban and rural geographies through innovative underwriting.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Independent Directors</h3>
            <p style="color: #ff4757 !important; font-size: 0.9rem; font-weight:bold;">Corporate Governance</p>
            <p style="margin-top: 15px;">Our board comprises distinguished veterans from the banking, finance, and regulatory sectors ensuring the highest standards of ESG and governance.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Core Management</h3>
            <p style="color: #ff4757 !important; font-size: 0.9rem; font-weight:bold;">Execution Leaders</p>
            <p style="margin-top: 15px;">A robust team of domain experts leading Credit, Operations, Compliance, and Technology, delivering a seamless 10-minute digital lending experience.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('about.html', 'w') as f: f.write(about_content)


# INVESTOR
invest_hero = wrap_hero("partners", "CAPITAL PARTNERS", "Growth & Investors.", "Namdev Finvest is backed by globally respected institutional investors and development finance institutions. We recently raised $19 Million in Pre-Series C funding led by Maj Invest to deepen our presence in rural India.")
investor_content = head_nav.replace("{TITLE}", "Investor Relations") + invest_hero + """
    <section class="section-stage" style="background: var(--bg-surface);">
      <div class="container">
        <div class="content-grid">
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Maj Invest</h3>
            <p>Lead Investor - Pre-Series C</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Incofin</h3>
            <p>Global Impact Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">BII</h3>
            <p>British International Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">FMO & IIX</h3>
            <p>Development Finance Partners</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section-stage" id="disclosures">
      <div class="container">
        <h2 style="font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px; color:#fff;">Disclosures & ESG</h2>
        <div class="content-grid">
          <div class="info-card" id="esg">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">ESG Commitment</h3>
            <p>Namdev Finvest Pvt. Ltd. earned the GOLD-level Client Protection certification from MFR for its high standards in social and environmental performance.</p>
          </div>
          <div class="info-card" id="financials">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Financial Performance</h3>
            <p>AUM crossed ₹1,200 Cr mark in FY24. Successfully raised USD 37 million (324 crore) from globally respected partners through listed NCDs and ECB structures.</p>
          </div>
          <div class="info-card" id="rta">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">RTA, DT & GRO</h3>
            <p>Access official documentation regarding Registrar & Transfer Agent details, Debenture Trustees, and Grievance Redressal Officers.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('investor.html', 'w') as f: f.write(investor_content)


# TEAM
team_hero = wrap_hero("culture", "LIFE AT NAMDEV", "Build the Future of Finance.", "Join a dynamic team of over 1,000+ professionals spread across 137+ branches in Rajasthan, Gujarat, MP, Punjab, and Delhi NCR. We are mechanizing Bharat and funding green transitions.")
team_content = head_nav.replace("{TITLE}", "Our Team") + team_hero + """
    <section class="section-stage" id="careers">
      <div class="container">
        <div class="content-grid">
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Careers at Namdev</h3>
            <p style="margin-bottom: 25px;">We are always looking for ambitious Credit Managers, Branch Managers, and Technology experts.</p>
            <a href="https://namdevcareers.peoplestrong.com/" target="_blank" class="btn-quantum" style="text-decoration:none; padding:10px 20px; font-size:0.9rem;">View Open Roles</a>
          </div>
          <div class="info-card" id="gallery">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Gallery & Culture</h3>
            <p>Experience our vibrant branch culture, offsites, and the impact we create on the ground with our MSME partners and Solar adopters.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Employee Testimonials</h3>
            <p>Hear directly from our branch leaders and credit officers about their rapid career growth journeys within Namdev Finvest.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('team.html', 'w') as f: f.write(team_content)


# CONTACT
contact_hero = wrap_hero("support", "24/7 SUPPORT", "Contact Us.", "Whether you need a new loan, support with your EMI, or want to locate your nearest branch, our team is ready to assist you.")
contact_content = head_nav.replace("{TITLE}", "Contact Us") + contact_hero + """
    <section class="section-stage">
      <div class="container">
        <div class="content-grid" style="grid-template-columns: 1fr 1fr;">
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Corporate Headquarters</h3>
            <p style="font-size: 1.1rem; margin-bottom: 10px;">"Namdev House", Plot No. 21</p>
            <p style="font-size: 1.1rem; margin-bottom: 10px;">Neer Sagar-A, Bhankrota</p>
            <p style="font-size: 1.1rem; margin-bottom: 30px;">Jaipur, Rajasthan - 302026</p>
            
            <h4 style="color: #ff4757 !important; margin-bottom: 5px;">Toll Free</h4>
            <p style="font-size: 1.5rem; font-weight: bold; margin-bottom: 20px; color:#fff !important;">1800-103-5800</p>
            
            <h4 style="color: #ff4757 !important; margin-bottom: 5px;">Email</h4>
            <p style="font-size: 1.2rem; font-weight: bold; color:#fff !important;">info@namfin.in</p>
          </div>
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">137+ Branches Across India</h3>
            <p style="margin-bottom: 20px;">We are expanding rapidly to serve you better. Find us in:</p>
            <ul style="color: #fff !important; font-size: 1.1rem; line-height: 2; padding-left: 20px; font-weight: 600;">
              <li>Rajasthan</li>
              <li>Gujarat</li>
              <li>Madhya Pradesh</li>
              <li>Punjab</li>
              <li>Haryana</li>
              <li>Delhi NCR</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('contact.html', 'w') as f: f.write(contact_content)

