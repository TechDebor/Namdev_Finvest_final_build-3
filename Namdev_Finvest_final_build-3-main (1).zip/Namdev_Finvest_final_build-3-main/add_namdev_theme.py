import glob

# 1. Update js/main.js
try:
    with open('js/main.js', 'r') as f:
        js_content = f.read()
        
    if "namdev:" not in js_content:
        # Find the ocean: line and append namdev:
        old_js = "ocean:     { c1: '#06b6d4', c2: '#3b82f6', c3: '#4f46e5', glow: 'rgba(59,130,246,0.4)' }"
        new_js = "ocean:     { c1: '#06b6d4', c2: '#3b82f6', c3: '#4f46e5', glow: 'rgba(59,130,246,0.4)' },\n        namdev:    { c1: '#ef4444', c2: '#8b5cf6', c3: '#3b82f6', glow: 'rgba(239,68,68,0.4)' }"
        
        if old_js in js_content:
            js_content = js_content.replace(old_js, new_js)
            with open('js/main.js', 'w') as f:
                f.write(js_content)
            print("Added Namdev theme to JS.")
        else:
            print("Could not find the target JS line.")
except Exception as e:
    print(f"JS Error: {e}")

# 2. Update all HTML files
new_dot_html = '    <div class="theme-dot" data-grad="ocean" style="background: linear-gradient(135deg, #06b6d4, #4f46e5);" title="Ocean"></div>\n    <div class="theme-dot" data-grad="namdev" style="background: linear-gradient(135deg, #ef4444, #3b82f6);" title="Namdev Official (Red & Blue)"></div>'

html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        old_dot = '    <div class="theme-dot" data-grad="ocean" style="background: linear-gradient(135deg, #06b6d4, #4f46e5);" title="Ocean"></div>'
        
        if old_dot in content and "data-grad=\"namdev\"" not in content:
            content = content.replace(old_dot, new_dot_html)
            with open(file, 'w') as f:
                f.write(content)
            print(f"Added Namdev dot to {file}")
            
    except Exception as e:
        print(f"HTML Error on {file}: {e}")

