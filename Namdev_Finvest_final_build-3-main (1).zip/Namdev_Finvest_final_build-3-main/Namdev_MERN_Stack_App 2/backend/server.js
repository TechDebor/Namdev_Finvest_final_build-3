
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

// In a real app, you would connect to MongoDB here
// mongoose.connect(process.env.MONGO_URI);

let applications = [];
let tasks = [
    { id: 'DEV-1001', loan: 'LN-260901', name: 'Rahul Sharma', product: 'MSME', rule: 'FOIR exceeds permitted threshold', dept: 'Credit', priority: 'High', status: 'Open' },
    { id: 'DEV-1002', loan: 'LN-260902', name: 'Priya Meena', product: 'LAP', rule: 'Aadhaar / PAN name mismatch', dept: 'KYC', priority: 'High', status: 'Open' }
];

app.get('/api/health', (req, res) => res.json({ status: 'ok', engine: 'DEBOR' }));

app.post('/api/applications', (req, res) => {
    const appData = { id: 'APP-' + Date.now(), ...req.body, status: 'Processing' };
    applications.push(appData);
    res.json(appData);
});

app.get('/api/tasks', (req, res) => {
    res.json(tasks);
});

app.post('/api/tasks/:id/resolve', (req, res) => {
    const { id } = req.params;
    tasks = tasks.map(t => t.id === id ? { ...t, status: 'Resolved' } : t);
    res.json({ success: true });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
