
import React, { useState, useEffect } from 'react';

export default function CRMWorkbench() {
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);

  useEffect(() => {
    // In a real app, fetch from backend: fetch('http://localhost:5000/api/tasks')
    setTasks([
      { id: 'DEV-1001', name: 'Aarav Sharma', product: 'MSME', rule: 'FOIR exceeds permitted threshold', dept: 'Credit', priority: 'High', status: 'Open' },
      { id: 'DEV-1002', name: 'Aarav Sharma', product: 'MSME', rule: 'Aadhaar / PAN name mismatch', dept: 'KYC', priority: 'High', status: 'Open' }
    ]);
  }, []);

  const resolveTask = () => {
    setTasks(tasks.map(t => t.id === selectedTask.id ? { ...t, status: 'Resolved' } : t));
    setSelectedTask(null);
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-bgLight">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r flex flex-col">
        <div className="p-6 border-b">
          <div className="font-black text-ink text-lg tracking-tight">DEBOR <span className="text-brand font-normal">BRE OS</span></div>
          <div className="text-[10px] bg-blue-50 text-brand px-2 py-1 rounded inline-block mt-1 font-bold">LENDING INTELLIGENCE</div>
        </div>
        <div className="p-4 flex-1">
          <div className="text-[10px] font-bold text-gray-400 tracking-wider mb-3 px-3">WORKSPACE</div>
          <div className="px-3 py-2 bg-blue-50 text-brand rounded-lg font-bold text-sm mb-1">Command Centre</div>
          <div className="px-3 py-2 text-gray-500 hover:bg-gray-50 rounded-lg text-sm mb-1 cursor-pointer font-medium">My Task Workspace</div>
          <div className="px-3 py-2 text-gray-500 hover:bg-gray-50 rounded-lg text-sm mb-1 cursor-pointer font-medium">All Deviations</div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-auto">
        <div className="flex justify-between items-start mb-8">
          <div>
            <div className="text-[11px] font-bold text-brand tracking-widest mb-1">BRE EXCEPTION MANAGEMENT</div>
            <h1 className="text-2xl font-black text-ink tracking-tight mb-1">Deviation Command Centre</h1>
            <p className="text-gray-500 text-sm">Your live queue of credit policy exceptions, obligations and BRE failures.</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-500">Viewing as</span>
            <select className="border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-ink bg-white shadow-sm outline-none">
              <option>Credit Manager</option>
              <option>KYC Officer</option>
              <option>Disbursement Officer</option>
            </select>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Assigned Deviations', value: tasks.length },
            { label: 'New Tasks', value: tasks.filter(t=>t.status==='Open').length },
            { label: 'SLA Breaches', value: '0' },
            { label: 'Resolved', value: tasks.filter(t=>t.status==='Resolved').length }
          ].map((s, i) => (
            <div key={i} className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden">
              <div className="text-xs font-bold text-gray-400 mb-2">{s.label}</div>
              <div className="text-3xl font-black text-ink tracking-tight">{s.value}</div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex justify-between items-center">
            <h2 className="font-bold text-ink">Assigned Deviation Queue</h2>
            <span className="text-xs bg-gray-100 px-3 py-1 rounded-full text-gray-500 font-bold">{tasks.length} OPEN</span>
          </div>
          <table className="w-full text-left">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Case / Customer</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">BRE Deviation</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Department</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Status</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => (
                <tr key={t.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">
                  <td className="p-4">
                    <div className="font-bold text-ink text-sm">{t.name}</div>
                    <div className="text-xs text-gray-400 mt-1">{t.id} · {t.product}</div>
                  </td>
                  <td className="p-4 text-sm font-bold text-ink">{t.rule}</td>
                  <td className="p-4 text-sm text-gray-600">{t.dept}</td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide ${t.status === 'Open' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-green-50 text-green-600 border border-green-100'}`}>
                      {t.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <button 
                      onClick={() => setSelectedTask(t)} 
                      disabled={t.status === 'Resolved'} 
                      className="text-brand font-bold text-xs bg-blue-50 px-3 py-2 rounded-lg hover:bg-blue-100 transition disabled:opacity-50 disabled:grayscale">
                      Review Case ->
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Resolution Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-ink/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 w-full max-w-lg shadow-2xl">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-xl font-black text-ink mb-1">Resolve Exception</h2>
                <p className="text-sm text-gray-500">{selectedTask.id}: {selectedTask.rule}</p>
              </div>
              <button onClick={() => setSelectedTask(null)} className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-500">✕</button>
            </div>
            
            <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl mb-6 text-sm text-orange-800">
              Assigned to: <strong>{selectedTask.dept}</strong>. Only authorized officers can resolve this deviation.
            </div>

            <div className="mb-6">
              <label className="block text-xs font-bold text-gray-600 mb-2">Resolution Notes / Evidence Reference *</label>
              <textarea className="w-full border border-gray-200 rounded-xl p-3 text-sm outline-none focus:border-brand resize-none" rows="4" placeholder="Add supporting remarks, verification logs, or evidence reference IDs..."></textarea>
            </div>
            
            <div className="flex justify-end gap-3">
              <button onClick={() => setSelectedTask(null)} className="px-5 py-2.5 rounded-xl font-bold text-gray-600 hover:bg-gray-100 transition">Cancel</button>
              <button onClick={resolveTask} className="px-5 py-2.5 bg-brand text-white rounded-xl font-bold shadow-lg shadow-brand/30 hover:bg-blue-700 transition">✓ Mark Resolved</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
