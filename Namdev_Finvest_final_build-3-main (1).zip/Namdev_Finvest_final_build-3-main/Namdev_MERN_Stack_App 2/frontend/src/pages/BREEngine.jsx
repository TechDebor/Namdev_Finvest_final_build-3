
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function BREEngine() {
  const navigate = useNavigate();
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const startEngine = () => {
    setRunning(true);
    let p = 0;
    const interval = setInterval(() => {
      p += 15;
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
      }
    }, 500);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-bgLight p-8">
      <div className="max-w-5xl mx-auto">
        
        <div className="flex justify-between items-start mb-8">
          <div>
            <div className="text-xs font-bold text-brand tracking-widest mb-2">ORIGINATION / DECISION INTELLIGENCE</div>
            <h1 className="text-3xl font-black tracking-tight text-ink">Smart Loan Decision Engine ✧</h1>
            <p className="text-gray-500 mt-1">Capture minimum information. Automate verification. Route exceptions.</p>
          </div>
          <div className="px-4 py-2 bg-white border rounded-full text-xs font-bold shadow-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span> ENGINE ONLINE
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Form Panel */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 className="text-lg font-bold mb-1">01. Minimal Applicant Intake</h2>
            <p className="text-xs text-gray-500 mb-6">Enter the core KYC details to initiate the journey.</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-600 mb-1">Applicant Name</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" defaultValue="Aarav Sharma" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Mobile Number</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" defaultValue="9876543210" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">PAN Number</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand uppercase" defaultValue="ABCDE1234F" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Loan Product</label>
                <select className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand">
                  <option>MSME Loan</option>
                  <option>LAP</option>
                  <option>Solar Loan</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Amount (₹)</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" type="number" defaultValue="350000" />
              </div>
            </div>
            
            <button onClick={startEngine} disabled={running} className="w-full bg-brand text-white py-3 rounded-lg font-bold shadow-lg shadow-brand/30 hover:bg-blue-700 transition disabled:opacity-50">
              ✧ Run Intelligent Assessment
            </button>
          </div>

          {/* Execution Panel */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex flex-col">
            <h2 className="text-lg font-bold mb-1">02. Live Decision Execution</h2>
            <p className="text-xs text-gray-500 mb-6">Transparent checks, logs and exception traceability.</p>
            
            <div className="flex-1 bg-gray-50 rounded-xl p-5 border border-gray-100 flex flex-col justify-center">
              {!running ? (
                <div className="text-center text-gray-400 font-medium">Awaiting assessment start...</div>
              ) : (
                <>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-bold text-ink">Executing BRE Checks...</span>
                    <span className="text-xs font-bold text-brand">{Math.min(progress, 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-6 overflow-hidden">
                    <div className="bg-brand h-2 rounded-full transition-all duration-300" style={{width: `${progress}%`}}></div>
                  </div>
                  
                  {progress >= 100 && (
                    <div className="mt-auto bg-red-50 border border-red-100 p-4 rounded-lg">
                      <h3 className="text-red-700 font-bold text-sm mb-1">Exceptions Routed</h3>
                      <p className="text-red-600/80 text-xs mb-3">Tasks assigned to specific department owners. Review required before disbursement.</p>
                      <button onClick={() => navigate('/crm')} className="bg-white border border-red-200 text-red-700 px-4 py-2 rounded font-bold text-xs shadow-sm w-full">
                        Open Deviation Command Centre ->
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
