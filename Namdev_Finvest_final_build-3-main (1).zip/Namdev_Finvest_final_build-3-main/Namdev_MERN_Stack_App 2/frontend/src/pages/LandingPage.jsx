
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function LandingPage() {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand rounded-full mix-blend-screen filter blur-[120px] opacity-20"></div>
      
      <div className="z-10 text-center max-w-3xl">
        <div className="mb-6 flex justify-center gap-4">
          <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-bold tracking-wider">RBI REGISTERED NBFC</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter leading-tight">Minimalist Financing for <span className="text-gray-400">Bharat's Visionaries.</span></h1>
        <p className="text-lg text-gray-400 mb-10 leading-relaxed">
          Empowering grassroots entrepreneurs, rural farmers, clean energy adopters, and transport fleets with instant underwriting and high-contrast simplicity.
        </p>
        <button 
          onClick={() => navigate('/apply')} 
          className="bg-white text-black px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-200 hover:scale-105 transition transform shadow-[0_0_40px_rgba(255,255,255,0.3)]">
          Instant Apply (10 Min Flow) ->
        </button>
      </div>
    </div>
  );
}
