
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import BREEngine from './pages/BREEngine';
import CRMWorkbench from './pages/CRMWorkbench';

export default function App() {
  return (
    <BrowserRouter>
      <nav className="bg-ink text-white p-4 flex justify-between items-center shadow-lg">
        <div className="font-black text-xl tracking-tight">NAMDEV <span className="text-brand">FINVEST</span></div>
        <div className="flex gap-6 text-sm font-bold text-gray-300">
          <Link to="/" className="hover:text-white transition">Home</Link>
          <Link to="/apply" className="hover:text-white transition">BRE Decision Engine</Link>
          <Link to="/crm" className="hover:text-white transition">Deviation CRM Workbench</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/apply" element={<BREEngine />} />
        <Route path="/crm" element={<CRMWorkbench />} />
      </Routes>
    </BrowserRouter>
  );
}
