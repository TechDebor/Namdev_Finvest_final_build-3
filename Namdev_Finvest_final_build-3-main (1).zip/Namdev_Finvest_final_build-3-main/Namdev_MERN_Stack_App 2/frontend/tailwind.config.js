
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { brand: '#4b47df', ink: '#15233d', bgLight: '#f5f7fb' } } },
  plugins: [],
}