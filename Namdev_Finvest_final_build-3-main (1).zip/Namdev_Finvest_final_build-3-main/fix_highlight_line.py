import re
import time
import glob

# Read the CSS file
try:
    with open('css/style.css', 'r') as f:
        css = f.read()

    # We need to remove these blocks:
    # .hero-headline .highlight { position: relative; display: inline-block; }
    # .hero-headline .highlight::after { ... }
    
    # Use regex to remove both blocks
    css = re.sub(r'\.hero-headline \.highlight\s*\{[^}]*\}', '', css)
    css = re.sub(r'\.hero-headline \.highlight::after\s*\{[^}]*\}', '', css)

    # Make the highlight even bolder/cleaner globally
    if '/* CLEAN HIGHLIGHT FIX */' not in css:
        css += """
/* CLEAN HIGHLIGHT FIX */
.highlight {
    display: inline-block !important;
    position: relative !important;
    padding-bottom: 2px !important; /* Prevents descender cutoff on some fonts */
}
.highlight::after {
    display: none !important;
}
"""
    
    with open('css/style.css', 'w') as f:
        f.write(css)
    print("Fixed highlight line in CSS.")
    
    # Bust cache on HTML files
    timestamp = str(int(time.time()))
    for file in glob.glob('*.html'):
        with open(file, 'r') as f:
            content = f.read()
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        with open(file, 'w') as f:
            f.write(content)
    print("Cache busted.")
    
except Exception as e:
    print(e)
