import re

with open('los-bre-engine.html', 'r') as f:
    html = f.read()

sync_logic = """
// Live sync with Namfindesk CRM
window.addEventListener('storage', (e) => {
    if (e.key === 'namfin_resolved_roles') {
        let resolvedRoles = JSON.parse(localStorage.getItem('namfin_resolved_roles') || '{}');
        let roleMap = {
            'ops': 'EXC-001',
            'rcu': 'EXC-002',
            'legal': 'EXC-003',
            'credit': 'EXC-004'
        };
        
        let updated = false;
        issues.forEach(issue => {
            // Find which role this issue belongs to
            let role = null;
            if(issue.department.includes('KYC')) role = 'ops';
            else if(issue.department.includes('Compliance')) role = 'rcu';
            else if(issue.department.includes('Legal') || issue.department.includes('Technical')) role = 'legal';
            else if(issue.department.includes('Credit')) role = 'credit';
            
            if (role && resolvedRoles[role] && !issue.resolved) {
                issue.resolved = true;
                results[issue.stage+'-'+issue.check] = 'ok';
                addLog(`AUTHORIZED REMEDIATION (Via Namfindesk CRM): ${issue.id} resolved by ${issue.owner}`, 'g');
                updated = true;
            }
        });
        
        if (updated) {
            addLog('Auto-resume: releasing dependent workflow holds', 'g');
            render();
            
            if(!issues.some(x=>!x.resolved)) {
               addLog('RULE RUN COMPLETE: All CRM holds cleared. Ready for Disbursement Officer.', 'g');
               renderDecision();
            }
        }
    }
});
"""

# Insert sync logic before resetAll()
html = html.replace('resetAll();\n// Auto-populate', sync_logic + '\nresetAll();\n// Auto-populate')

with open('los-bre-engine.html', 'w') as f:
    f.write(html)
