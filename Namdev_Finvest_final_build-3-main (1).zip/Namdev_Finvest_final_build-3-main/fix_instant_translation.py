import glob
import re

# 1. Update js/main.js with instant translation logic
instant_js = """
/* ==========================================================================
   INSTANT MULTILINGUAL TRANSLATION ENGINE (GOOGLE TRANSLATE)
   ========================================================================== */
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        autoDisplay: false,
        includedLanguages: 'en,hi,mr,gu,ur,pa,or',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, 'google_translate_element');
}

function switchLanguage(langCode) {
    var select = document.querySelector('select.goog-te-combo');
    if (select) {
        select.value = langCode;
        select.dispatchEvent(new Event('change'));
    } else {
        // Fallback if script hasn't fully loaded yet
        document.cookie = "googtrans=/en/" + langCode + "; path=/;";
        document.cookie = "googtrans=/en/" + langCode + "; path=/; domain=" + location.hostname;
        window.location.reload();
    }
    
    // Close the dropdown visually if needed
    document.activeElement.blur();
}
"""

try:
    with open('js/main.js', 'r') as f:
        js_content = f.read()
    
    # Remove the old translation logic if it exists
    js_content = re.sub(r'/\* ==========================================================================\s*DYNAMIC MULTILINGUAL TRANSLATION ENGINE.*?(?=\/\*|$)', '', js_content, flags=re.DOTALL)
    
    with open('js/main.js', 'a') as f:
        f.write("\n" + instant_js)
    print("Instant JS logic injected.")
except Exception as e:
    print(f"JS Error: {e}")

# 2. Hard-replace the dropdown menu in all HTML files
dropdown_block_old = r'<ul class="dropdown-menu-simple" style="min-width: 160px; right: 0; left: auto; top: 45px;">(.*?)</ul>'
dropdown_block_new = """<ul class="dropdown-menu-simple" style="min-width: 160px; right: 0; left: auto; top: 45px;">
                <li><a href="#" onclick="switchLanguage('en'); return false;">English</a></li>
                <li><a href="#" onclick="switchLanguage('hi'); return false;">हिंदी (Hindi)</a></li>
                <li><a href="#" onclick="switchLanguage('mr'); return false;">मराठी (Marathi)</a></li>
                <li><a href="#" onclick="switchLanguage('gu'); return false;">ગુજરાતી (Gujarati)</a></li>
                <li><a href="#" onclick="switchLanguage('ur'); return false;">اردو (Urdu)</a></li>
                <li><a href="#" onclick="switchLanguage('pa'); return false;">ਪੰਜਾਬੀ (Punjabi)</a></li>
                <li><a href="#" onclick="switchLanguage('or'); return false;">ଓଡ଼ିଆ (Odia)</a></li>
              </ul>"""

google_translate_div = """
  <!-- Hidden Google Translate Element for Instant Translation -->
  <div id="google_translate_element" style="display:none;"></div>
  <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
"""

import time
timestamp = str(int(time.time()))

for file in glob.glob('*.html'):
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # Replace the dropdown inner contents
        content = re.sub(dropdown_block_old, dropdown_block_new, content, flags=re.DOTALL)
        
        # Inject the google translate div before closing body if not present
        if 'id="google_translate_element"' not in content:
            content = content.replace('</body>', google_translate_div + '\n</body>')
            
        # Inject CSS to hide the banner if not present
        if 'goog-te-banner-frame' not in content:
            style_inject = """
    <style>
      /* Hide Google Translate Top Banner and Tooltips */
      .goog-te-banner-frame.skiptranslate, .goog-te-gadget-icon { display: none !important; }
      body { top: 0px !important; }
      #goog-gt-tt, .goog-te-balloon-frame { display: none !important; }
      .goog-text-highlight { background: none !important; box-shadow: none !important; }
    </style>
"""
            content = content.replace('</head>', style_inject + '</head>')
            
        # Bust cache
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'src="js/main\.js\?v=\d+"', f'src="js/main.js?v={timestamp}"', content)
            
        with open(file, 'w') as f:
            f.write(content)
    except Exception as e:
        print(f"Error on {file}: {e}")

print("HTML updated with INSTANT translation logic.")
