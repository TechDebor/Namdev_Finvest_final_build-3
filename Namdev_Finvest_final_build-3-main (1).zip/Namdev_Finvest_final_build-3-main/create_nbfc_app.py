import os
import subprocess
import shutil
import re

APP_DIR = "Namdev_MERN_App"

def run_cmd(cmd, cwd=None):
    subprocess.run(cmd, shell=True, check=True, cwd=cwd)

def setup_backend():
    os.makedirs(f"{APP_DIR}/server/models", exist_ok=True)
    os.makedirs(f"{APP_DIR}/server/routes", exist_ok=True)
    
    # package.json
    with open(f"{APP_DIR}/server/package.json", "w") as f:
        f.write("""{
  "name": "namdev-server",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": { "start": "node server.js", "dev": "nodemon server.js" },
  "dependencies": { "cors": "^2.8.5", "dotenv": "^16.3.1", "express": "^4.18.2", "mongoose": "^7.5.0" }
}""")

    # server.js
    with open(f"{APP_DIR}/server/server.js", "w") as f:
        f.write("""
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

// Mock DB in memory for testing
let applications = [];
let tasks = [];

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.post('/api/applications', (req, res) => {
    const appData = { id: 'APP-' + Date.now(), ...req.body, status: 'Processing' };
    applications.push(appData);
    res.json(appData);
});

app.get('/api/tasks', (req, res) => res.json(tasks));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
""")

def extract_html_parts(filepath):
    try:
        with open(filepath, 'r') as f:
            content = f.read()
            
        style_match = re.search(r'<style>(.*?)</style>', content, re.DOTALL)
        styles = style_match.group(1) if style_match else ""
        
        body_match = re.search(r'<body>(.*?)<script>', content, re.DOTALL)
        body = body_match.group(1) if body_match else ""
        
        script_match = re.search(r'<script>(.*?)</script>', content, re.DOTALL)
        script = script_match.group(1) if script_match else ""
        
        return styles, body, script
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return "", "", ""

def convert_to_jsx(html):
    # Basic conversions
    html = html.replace('class="', 'className="')
    html = html.replace('for="', 'htmlFor="')
    html = html.replace('onclick', 'onClick')
    html = html.replace('onchange', 'onChange')
    html = html.replace('oninput', 'onInput')
    html = html.replace('style="', 'style={{') # Extremely hacky, but we will mostly strip inline styles or let dev fix it
    
    # Remove simple inline styles for automated conversion to avoid JSX object errors
    html = re.sub(r'style="[^"]*"', '', html)
    html = re.sub(r'style={{[^}]*}}', '', html)
    
    # Fix unclosed tags like <input>, <br>, <hr>, <img>
    html = re.sub(r'<input([^>]*)(?<!/)>', r'<input\1 />', html)
    html = re.sub(r'<br([^>]*)(?<!/)>', r'<br\1 />', html)
    html = re.sub(r'<hr([^>]*)(?<!/)>', r'<hr\1 />', html)
    html = re.sub(r'<img([^>]*)(?<!/)>', r'<img\1 />', html)
    
    return html

def setup_frontend():
    print("Initializing Vite React App...")
    run_cmd(f"npx create-vite@latest {APP_DIR}/client --template react")
    
    print("Installing Tailwind...")
    run_cmd("npm install -D tailwindcss postcss autoprefixer react-router-dom", cwd=f"{APP_DIR}/client")
    run_cmd("npx tailwindcss init -p", cwd=f"{APP_DIR}/client")
    
    # Configure Tailwind
    with open(f"{APP_DIR}/client/tailwind.config.js", "w") as f:
        f.write("""
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: {} },
  plugins: [],
}""")

    with open(f"{APP_DIR}/client/src/index.css", "w") as f:
        f.write("""
@tailwind base;
@tailwind components;
@tailwind utilities;

body { margin: 0; padding: 0; background-color: #f5f7fb; }
""")

    # App.jsx
    with open(f"{APP_DIR}/client/src/App.jsx", "w") as f:
        f.write("""
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import BREEngine from './pages/BREEngine';
import CRMWorkbench from './pages/CRMWorkbench';

export default function App() {
  return (
    <BrowserRouter>
      <nav className="p-4 bg-gray-900 text-white flex justify-between items-center">
        <div className="font-bold text-xl tracking-wider">NAMDEV <span className="text-blue-400">FINVEST</span></div>
        <div className="flex gap-4">
          <Link to="/" className="hover:text-blue-300">Website</Link>
          <Link to="/apply" className="hover:text-blue-300">Loan BRE Engine</Link>
          <Link to="/crm" className="hover:text-blue-300">Deviation CRM</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/apply" element={<BREEngine />} />
        <Route path="/crm" element={<CRMWorkbench />} />
      </Routes>
    </BrowserRouter>
  );
}
""")

    os.makedirs(f"{APP_DIR}/client/src/pages", exist_ok=True)

    # PAGE: Home
    with open(f"{APP_DIR}/client/src/pages/Home.jsx", "w") as f:
        f.write("""
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-black text-white p-10 flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold mb-4 tracking-tight">Minimalist Financing for Bharat's Visionaries.</h1>
      <p className="text-gray-400 mb-8 max-w-2xl text-center">Empowering grassroots entrepreneurs, rural farmers, clean energy adopters, and transport fleets with instant underwriting and high-contrast simplicity.</p>
      <button onClick={() => navigate('/apply')} className="bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-gray-200 transition">
        Apply In 60 Seconds ->
      </button>
    </div>
  );
}
""")

    # PAGE: BRE Engine
    with open(f"{APP_DIR}/client/src/pages/BREEngine.jsx", "w") as f:
        f.write("""
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function BREEngine() {
  const navigate = useNavigate();
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const runEngine = () => {
    setRunning(true);
    let p = 0;
    const interval = setInterval(() => {
      p += 10;
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        setTimeout(() => navigate('/crm'), 1000);
      }
    }, 300);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Smart Loan Decision Engine ✧</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-sm border mb-6">
        <h2 className="text-lg font-bold mb-4">01. Minimal Applicant Intake</h2>
        <div className="grid grid-cols-2 gap-4">
          <input className="border p-2 rounded" placeholder="Applicant Name" defaultValue="Aarav Sharma" />
          <input className="border p-2 rounded" placeholder="Mobile" defaultValue="9876543210" />
          <input className="border p-2 rounded" placeholder="PAN" defaultValue="ABCDE1234F" />
          <input className="border p-2 rounded" placeholder="Amount" defaultValue="350000" />
        </div>
        <button onClick={runEngine} className="mt-4 bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700">
          ✧ Run Intelligent Assessment
        </button>
      </div>

      {running && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-lg font-bold mb-4">02. Live Decision Execution</h2>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
            <div className="bg-blue-600 h-2.5 rounded-full" style={{width: `${progress}%`}}></div>
          </div>
          <p className="text-sm text-gray-500">{progress < 100 ? 'Executing BRE Checks...' : 'Exceptions Found. Routing to CRM...'}</p>
        </div>
      )}
    </div>
  );
}
""")

    # PAGE: CRM Workbench
    with open(f"{APP_DIR}/client/src/pages/CRMWorkbench.jsx", "w") as f:
        f.write("""
import React, { useState } from 'react';

export default function CRMWorkbench() {
  const [tasks, setTasks] = useState([
    { id: 'DEV-1001', name: 'Aarav Sharma', rule: 'FOIR exceeds threshold', dept: 'Credit Manager', priority: 'High', status: 'Open' },
    { id: 'DEV-1002', name: 'Aarav Sharma', rule: 'Aadhaar/PAN Mismatch', dept: 'KYC Officer', priority: 'High', status: 'Open' }
  ]);
  const [selectedTask, setSelectedTask] = useState(null);

  const resolveTask = () => {
    setTasks(tasks.map(t => t.id === selectedTask.id ? { ...t, status: 'Resolved' } : t));
    setSelectedTask(null);
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r p-4 hidden md:block">
        <div className="font-bold text-lg mb-6 text-blue-700">DEBOR BRE OS</div>
        <div className="space-y-2 text-sm text-gray-600 font-medium">
          <div className="p-2 bg-blue-50 text-blue-700 rounded">Command Centre</div>
          <div className="p-2 hover:bg-gray-100 rounded cursor-pointer">My Task Workspace</div>
          <div className="p-2 hover:bg-gray-100 rounded cursor-pointer">Escalation Queue</div>
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 p-6 overflow-auto">
        <h1 className="text-2xl font-bold mb-6">Deviation Command Centre</h1>
        
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 border rounded-lg shadow-sm">
            <div className="text-xs text-gray-500 font-bold uppercase">Assigned Deviations</div>
            <div className="text-2xl font-black text-gray-800">{tasks.length}</div>
          </div>
          <div className="bg-white p-4 border rounded-lg shadow-sm">
            <div className="text-xs text-gray-500 font-bold uppercase">Resolved</div>
            <div className="text-2xl font-black text-green-600">{tasks.filter(t => t.status==='Resolved').length}</div>
          </div>
        </div>

        <div className="bg-white border rounded-lg overflow-hidden shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-4 text-gray-500 font-bold">Case / Customer</th>
                <th className="p-4 text-gray-500 font-bold">BRE Deviation</th>
                <th className="p-4 text-gray-500 font-bold">Department</th>
                <th className="p-4 text-gray-500 font-bold">Status</th>
                <th className="p-4 text-gray-500 font-bold">Action</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => (
                <tr key={t.id} className="border-b last:border-0 hover:bg-gray-50">
                  <td className="p-4 font-bold text-gray-800">{t.name} <span className="text-xs text-gray-400 font-normal block">{t.id}</span></td>
                  <td className="p-4 text-gray-700">{t.rule}</td>
                  <td className="p-4 text-gray-600">{t.dept}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${t.status === 'Open' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                      {t.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <button onClick={() => setSelectedTask(t)} disabled={t.status === 'Resolved'} className="text-blue-600 font-bold text-xs disabled:opacity-50">Review -></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-[500px] shadow-2xl">
            <h2 className="text-xl font-bold mb-2">Resolve Exception: {selectedTask.id}</h2>
            <p className="text-gray-500 text-sm mb-4">{selectedTask.rule} ({selectedTask.dept})</p>
            
            <textarea className="w-full border rounded p-2 mb-4 text-sm" rows="4" placeholder="Enter resolution notes and evidence link..."></textarea>
            
            <div className="flex justify-end gap-2">
              <button onClick={() => setSelectedTask(null)} className="px-4 py-2 border rounded font-bold text-gray-600 hover:bg-gray-50">Cancel</button>
              <button onClick={resolveTask} className="px-4 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">Mark Resolved</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
""")

def finalize():
    print("Zipping the application...")
    run_cmd(f"zip -r {APP_DIR}.zip {APP_DIR}")
    print("Done! MERN App created successfully.")

if __name__ == "__main__":
    if os.path.exists(APP_DIR):
        shutil.rmtree(APP_DIR)
    os.makedirs(APP_DIR)
    
    setup_backend()
    setup_frontend()
    finalize()
