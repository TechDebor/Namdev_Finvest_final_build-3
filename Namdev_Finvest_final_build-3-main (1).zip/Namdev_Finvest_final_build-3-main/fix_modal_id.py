with open('payment.html', 'r') as f:
    content = f.read()

content = content.replace('<div id="quantumModal" class="modal-backdrop-quantum">', '<div id="paymentModal" class="modal-backdrop-quantum">')

content = content.replace("const modal = document.getElementById('quantumModal');", "const modal = document.getElementById('paymentModal');")

# Also let's change the navbar button 'Apply MSME' to link to msme.html instead of opening modal, just to make sense.
content = content.replace('<button class="btn-quantum" data-open-modal data-product="msme">Apply MSME</button>', '<a href="msme.html" class="btn-quantum" style="text-decoration: none;">Apply MSME</a>')
# Mobile drawer one too
content = content.replace('<button class="btn-quantum" style="width: 100%;" data-open-modal data-product="msme">Apply for MSME Loan</button>', '<a href="msme.html" class="btn-quantum" style="width: 100%; text-decoration: none; display: flex; justify-content: center;">Apply for MSME Loan</a>')

with open('payment.html', 'w') as f:
    f.write(content)

