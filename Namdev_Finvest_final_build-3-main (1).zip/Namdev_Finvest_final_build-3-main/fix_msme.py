import re

with open('msme.html', 'r') as f:
    html = f.read()

# 1. Add "Overview" text into the Hero section (or right after)
# Find the hero-lead and replace/append
overview_text = """<p class="hero-lead" style="margin-bottom: 20px;">Empowering Small and Medium Enterprises with Tailored Financial Solutions. At Namdev Finvest, we understand the crucial role that Micro, Small, and Medium Enterprises (MSMEs) play in driving economic growth, especially in rural and semi-urban areas.</p>
            <p class="hero-lead">Our MSME Loans are specifically designed to support these enterprises, providing easy financial backing for expanding operations, investing in new equipment, or managing working capital.</p>"""

html = re.sub(r'<p class="hero-lead">.*?</p>', overview_text, html, count=1, flags=re.DOTALL)

# 2. Add "Features and Benefits" grid
# We'll insert this right after the "Business Expansion Solutions" section
features_benefits_html = """
    <!-- FEATURES AND BENEFITS (FROM OFFICIAL SITE) -->
    <section class="section-stage" style="background: var(--bg-surface);">
      <div class="container">
        <div class="section-head">
          <span class="badge-quantum">WHY CHOOSE US</span>
          <h2 class="section-title">Features and <span class="highlight">Benefits</span></h2>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
          <div class="feature-card">
            <h3 style="margin-top: 0;">Attractive Interest Rates</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Optimized pricing tailored to your cash flows.</p>
          </div>
          <div class="feature-card">
            <h3 style="margin-top: 0;">Quick Disbursal</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Lightning-fast approval and funding process.</p>
          </div>
          <div class="feature-card">
            <h3 style="margin-top: 0;">Multi Repayment Options</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Flexible terms designed around your business cycles.</p>
          </div>
          <div class="feature-card">
            <h3 style="margin-top: 0;">Easy to Manage Loans</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Full transparency via our digital dashboard.</p>
          </div>
          <div class="feature-card">
            <h3 style="margin-top: 0;">Minimal Documentation</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Paperless uploading with rapid verification.</p>
          </div>
          <div class="feature-card">
            <h3 style="margin-top: 0;">Transparent Process</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">No hidden fees or complex jargon.</p>
          </div>
        </div>
      </div>
    </section>
"""

# Find the end of the first feature section to inject
html = html.replace('</section>\n\n    <!-- CRITERIA -->', '</section>\n\n' + features_benefits_html + '\n    <!-- CRITERIA -->')

# 3. Add "How to Apply" 4-Step Process before FAQS
how_to_apply_html = """
    <!-- HOW TO APPLY -->
    <section class="section-stage">
      <div class="container">
        <div class="section-head">
          <span class="badge-quantum">SIMPLE WORKFLOW</span>
          <h2 class="section-title">How to <span class="highlight">Apply</span></h2>
        </div>
        <div class="pipeline-flow-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px;">
          <div class="pipeline-node">
            <div class="pipeline-step-badge">01</div>
            <h4 class="pipeline-title">Fill Out the Application</h4>
            <p class="pipeline-desc">Provide your business and personal details through our easy online form or by visiting one of our branches.</p>
          </div>
          <div class="pipeline-node">
            <div class="pipeline-step-badge">02</div>
            <h4 class="pipeline-title">Submit Your Documents</h4>
            <p class="pipeline-desc">Submit the necessary documents, including business registration, financial statements, and identification proof.</p>
          </div>
          <div class="pipeline-node">
            <div class="pipeline-step-badge">03</div>
            <h4 class="pipeline-title">Verification & Approval</h4>
            <p class="pipeline-desc">Our team will review your application, verify your documents, and process the approval swiftly.</p>
          </div>
          <div class="pipeline-node">
            <div class="pipeline-step-badge">04</div>
            <h4 class="pipeline-title">Funds Disbursed</h4>
            <p class="pipeline-desc">Once approved, the funds will be sanctioned and directly disbursed to your account.</p>
          </div>
        </div>
      </div>
    </section>
"""

html = html.replace('</section>\n\n    <!-- FAQS -->', '</section>\n\n' + how_to_apply_html + '\n    <!-- FAQS -->')


# 4. Replace FAQs with the official FAQs
official_faqs = """
          <div class="faq-item">
            <button class="faq-question-btn">
              What are MSME business loans?
              <span class="faq-arrow">▼</span>
            </button>
            <div class="faq-answer-panel">
              MSME business loans are financial products designed specifically for Micro, Small, and Medium Enterprises. These loans help businesses expand, purchase equipment, manage working capital, or cover other operational needs, supporting their growth and success in the competitive market.
            </div>
          </div>

          <div class="faq-item">
            <button class="faq-question-btn">
              How to apply for an MSME loan?
              <span class="faq-arrow">▼</span>
            </button>
            <div class="faq-answer-panel">
              You can apply for an MSME loan by filling out our simple online application form or visiting a Namdev Finvest branch. Submit the required documents, such as business registration, financial statements, and identity proof. Our team will review and approve your application quickly.
            </div>
          </div>

          <div class="faq-item">
            <button class="faq-question-btn">
              What documents are required to apply for an MSME Business Loan?
              <span class="faq-arrow">▼</span>
            </button>
            <div class="faq-answer-panel">
              To apply for an MSME Business Loan, you'll need to provide business registration documents, financial statements, proof of identity, address proof, and any other relevant business-related paperwork. These documents help us assess your eligibility and process your loan application smoothly.
            </div>
          </div>

          <div class="faq-item">
            <button class="faq-question-btn">
              How can I improve my chances of loan approval?
              <span class="faq-arrow">▼</span>
            </button>
            <div class="faq-answer-panel">
              Maintain a good credit score, provide accurate and complete documentation, and demonstrate a stable income or profitable business. Show a clear plan for using the loan and repaying it on time. Strengthening your financial records and reducing existing debts can also boost your chances.
            </div>
          </div>
"""

html = re.sub(r'<div class="faq-grid">.*?<!-- CTA Banner -->', f'<div class="faq-grid">\n{official_faqs}\n        </div>\n\n        <!-- CTA Banner -->', html, flags=re.DOTALL)


# Update Eligibility wording to match official site closer
eligibility_official = """<div class="criteria-card">
            <h3 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 8px;">MSME Loan Eligibility</h3>
            <p style="font-size: 0.9rem; color: var(--text-muted);">To be eligible for an MSME loan, applicants must own a registered small or medium enterprise with a stable operating history.</p>
            <ul class="criteria-list">
              <li class="criteria-item"><span class="check-icon-box">✓</span><span><strong>Good Credit Score:</strong> A solid track record enhances loan approval chances.</span></li>
              <li class="criteria-item"><span class="check-icon-box">✓</span><span><strong>Valid Business Registration:</strong> Proof of a stable operating enterprise.</span></li>
              <li class="criteria-item"><span class="check-icon-box">✓</span><span><strong>Residence Proof:</strong> Clear KYC and address validation.</span></li>
              <li class="criteria-item"><span class="check-icon-box">✓</span><span><strong>Sound Financial Statement:</strong> Demonstrated business viability and cash flow.</span></li>
            </ul>
          </div>

          <div class="docs-card">
            <h3 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 8px;">MSME Loan Documents</h3>
            <p style="font-size: 0.9rem; color: var(--text-muted);">Empower your business growth with these required documents:</p>
            <ul class="docs-list">
              <li class="docs-item"><span class="check-icon-box">✓</span><span><strong>KYC Documents:</strong> Valid photo ID and Aadhaar/PAN.</span></li>
              <li class="docs-item"><span class="check-icon-box">✓</span><span><strong>Copy of Business Registration:</strong> Udyam, GST, or local licenses.</span></li>
              <li class="docs-item"><span class="check-icon-box">✓</span><span><strong>Bank Statement:</strong> Up-to-date operating account statements.</span></li>
              <li class="docs-item"><span class="check-icon-box">✓</span><span><strong>Residence Proof:</strong> Recent utility bill or agreement.</span></li>
            </ul>
          </div>"""

html = re.sub(r'<div class="criteria-card">.*?</div>\n        </div>\n      </div>', f'{eligibility_official}\n        </div>\n      </div>', html, flags=re.DOTALL)

with open('msme.html', 'w') as f:
    f.write(html)
