import os
import glob
import re
import time

timestamp = str(int(time.time()))

# 1. Update navigation to include Login button
html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        old_btn = '<button class="btn-quantum" data-open-modal data-product="msme">'
        login_html = '<a href="login.html" class="nav-link" style="margin-right: 20px; font-weight: 700; display: inline-flex; align-items: center;">Login <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-left: 4px;"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg></a>\n            '
        
        if 'href="login.html"' not in content and old_btn in content:
            content = content.replace(old_btn, login_html + old_btn)
            with open(file, 'w') as f:
                f.write(content)
            print(f"Added Login to nav in {file}")
    except Exception as e:
        print(f"Error on nav update for {file}: {e}")

# 2. Create login.html based on about.html structure (which is clean and bulletproof)
with open('about.html', 'r') as f:
    about_content = f.read()

# Extract header (everything up to <section class="hero-quantum")
# First, ensure we get the updated nav with the Login button we just might have missed if about.html didn't trigger correctly
header_match = re.search(r'(.*?)<section class="hero-quantum"', about_content, re.DOTALL)
footer_match = re.search(r'(<footer class="quantum-footer">.*)', about_content, re.DOTALL)

if header_match and footer_match:
    header = header_match.group(1)
    # Ensure header has the correct title
    header = re.sub(r'<title>.*?</title>', '<title>Namdev Finvest | Login</title>', header)
    
    # Also add the login button to the header just in case it didn't get added yet
    if 'href="login.html"' not in header:
        old_btn = '<button class="btn-quantum" data-open-modal data-product="msme">'
        login_html = '<a href="login.html" class="nav-link" style="margin-right: 20px; font-weight: 700; display: inline-flex; align-items: center;">Login <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-left: 4px;"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg></a>\n            '
        header = header.replace(old_btn, login_html + old_btn)
        
    footer = footer_match.group(1)
    
    login_body = """
    <section class="hero-quantum" style="justify-content: center; align-items: center; text-align: center; min-height: 100vh; padding-top: 100px; position: relative; overflow: hidden; display: flex; flex-direction: column;">
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.15;">
        <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=2400&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">
      </div>
      
      <div class="container" style="width: 100%; display: flex; justify-content: center; z-index: 1; position: relative;">
        
        <div style="background: var(--bg-surface); border: 1px solid var(--border); padding: 40px; border-radius: 16px; width: 100%; max-width: 420px; box-shadow: var(--glass-shadow); text-align: left; backdrop-filter: blur(10px);">
          
          <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 30px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 32px; height: 32px; color: var(--text-primary);">
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                <polyline points="2 17 12 22 22 17"></polyline>
                <polyline points="2 12 12 17 22 12"></polyline>
            </svg>
            <h2 style="font-family: 'Syne', sans-serif; font-size: 1.5rem; letter-spacing: -0.02em;">Welcome Back</h2>
          </div>
          
          <div style="margin-bottom: 20px;">
            <label style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--text-muted); margin-bottom: 8px;">Employee ID / Mobile Number</label>
            <input type="text" placeholder="Enter your ID" style="width: 100%; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--mono-border); background: var(--bg-card); color: var(--text-primary); font-family: var(--font-sans); outline: none; transition: border-color 0.2s;">
          </div>
          
          <div style="margin-bottom: 25px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <label style="font-size: 0.85rem; font-weight: 600; color: var(--text-muted);">Password / OTP</label>
              <a href="#" class="highlight" style="font-size: 0.75rem; text-decoration: none;">Forgot Password?</a>
            </div>
            <input type="password" placeholder="••••••••" style="width: 100%; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--mono-border); background: var(--bg-card); color: var(--text-primary); font-family: var(--font-sans); outline: none; transition: border-color 0.2s;">
          </div>
          
          <button class="btn-quantum" style="width: 100%; padding: 14px; font-size: 1rem; border-radius: 8px; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 8px;" onclick="document.getElementById('loginSpinner').style.display='block'; setTimeout(() => window.location.href='namfindesk.html', 1500);">
            Secure Login
            <svg id="loginSpinner" style="display: none; animation: spin 1s linear infinite;" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
          </button>
          
          <style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>
          
          <div style="margin-top: 24px; text-align: center; font-size: 0.8rem; color: var(--text-muted);">
            Need access? <a href="contact.html" style="color: var(--text-primary); font-weight: 600; text-decoration: none;">Contact IT Admin</a>
          </div>
          
        </div>
      </div>
    </section>
    """
    
    with open('login.html', 'w') as f:
        f.write(header + login_body + footer)
    print("Created login.html")

