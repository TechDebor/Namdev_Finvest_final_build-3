with open('namfindesk.html', 'r') as f:
    html = f.read()

# 1. Update Login Options
html = html.replace(
    '<option value="head_credit">Head of Credit</option>',
    '<option value="head_credit">Head of Credit</option>\n          <option disabled>──────────</option>\n          <option value="admin">System Admin (BRE Manager)</option>'
)

# 2. Update Sidebar
html = html.replace(
    '<div class="nav-item" id="nav-perf" onclick="switchTab(\'perf\')">📊 Team Performance (HUD)</div>',
    '<div class="nav-item" id="nav-perf" onclick="switchTab(\'perf\')">📊 Team Performance (HUD)</div>\n    <div class="nav-item" id="nav-bre" style="display: none;" onclick="switchTab(\'bre\')">⚙️ BRE Rules Manager</div>'
)

# 3. Add BRE View HTML
bre_view = """
    <!-- BRE MANAGER VIEW -->
    <div id="view-bre" class="content-area">
      <h1 class="page-title">DEBOR Engine - Rule Configuration</h1>
      <div style="margin-bottom: 20px; padding: 15px; background: #f0fdf4; border-left: 4px solid var(--success); border-radius: 4px; font-size: 14px; color: #166534;">
        <strong>Live Production Engine:</strong> Parameters defined here are pushed instantly to the automated Decision Intelligence Engine.
      </div>

      <div style="display: flex; gap: 20px;">
        <!-- Left Panel: Products -->
        <div style="width: 250px; background: #fff; border: 1px solid var(--border); border-radius: 12px; overflow: hidden; height: fit-content;">
          <div style="padding: 15px; font-weight: bold; background: #f8fafc; border-bottom: 1px solid var(--border);">Select Product Policy</div>
          <div class="nav-item" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('lap')">🏢 Loan Against Property (LAP)</div>
          <div class="nav-item" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('tractor')">🚜 Tractor Loan</div>
          <div class="nav-item" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('solar')">☀️ Solar / Clean Energy</div>
          <div class="nav-item" style="margin: 0; border-radius: 0; color: var(--text);" onclick="loadProductConfig('msme')">🏪 MSME Business Loan</div>
        </div>

        <!-- Right Panel: Parameters -->
        <div style="flex: 1; background: #fff; border: 1px solid var(--border); border-radius: 12px; padding: 25px;">
          <h2 style="margin-top: 0;" id="bre-product-title">Configuring: Loan Against Property (LAP)</h2>
          
          <div class="metric-grid" style="grid-template-columns: 1fr 1fr;">
            
            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Max LTV Limit (%)</label>
              <input type="number" id="bre-ltv" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>
            
            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Max Tenure (Months)</label>
              <input type="number" id="bre-tenure" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>

            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Min Loan Amount (₹)</label>
              <input type="number" id="bre-min" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>

            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Max Loan Amount (₹)</label>
              <input type="number" id="bre-max" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>

            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Max FOIR Allowed (%)</label>
              <input type="number" id="bre-foir" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>

            <div style="margin-bottom: 15px;">
              <label style="display:block; font-size:12px; font-weight:bold; color:var(--text-muted); margin-bottom:5px;">Min CIBIL / Bureau Score</label>
              <input type="number" id="bre-cibil" class="input-group input" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border);">
            </div>

          </div>

          <div style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 20px; text-align: right;">
            <button class="btn btn-outline" style="margin-right: 10px;">Discard Changes</button>
            <button class="btn btn-success" onclick="saveBREConfig()">🚀 Deploy Rules to DEBOR Engine</button>
          </div>
        </div>
      </div>
    </div>
"""

html = html.replace('<!-- FULL SCREEN RESOLVE UI -->', bre_view + '\n  <!-- FULL SCREEN RESOLVE UI -->')

# 4. Update JS logic for roles and tabs
js_roleNames_old = """const roleNames = {
        ops: "Operations Checker", rcu: "Compliance Officer", legal: "Legal Officer",
        credit: "Credit Underwriter", do: "Disbursement Officer",
        head_ops: "Head of Operations", head_credit: "Head of Credit"
      };"""
js_roleNames_new = """const roleNames = {
        ops: "Operations Checker", rcu: "Compliance Officer", legal: "Legal Officer",
        credit: "Credit Underwriter", do: "Disbursement Officer",
        head_ops: "Head of Operations", head_credit: "Head of Credit", admin: "System Admin (BRE)"
      };"""
html = html.replace(js_roleNames_old, js_roleNames_new)

js_login_old = """if (role.startsWith('head_')) switchTab('perf');
      else switchTab('tasks');"""
js_login_new = """document.getElementById('nav-bre').style.display = (role === 'admin') ? 'flex' : 'none';
      if (role === 'admin') { switchTab('bre'); loadProductConfig('lap'); }
      else if (role.startsWith('head_')) switchTab('perf');
      else switchTab('tasks');"""
html = html.replace(js_login_old, js_login_new)

js_tab_old = """document.getElementById('nav-perf').classList.remove('active');
      
      document.getElementById('view-' + tab).classList.add('active');"""
js_tab_new = """document.getElementById('nav-perf').classList.remove('active');
      document.getElementById('nav-bre').classList.remove('active');
      document.getElementById('view-bre').classList.remove('active');
      
      document.getElementById('view-' + tab).classList.add('active');"""
html = html.replace(js_tab_old, js_tab_new)

# 5. Add BRE Logic Functions
bre_logic = """
    // --- BRE CONFIGURATION LOGIC ---
    let currentConfigProduct = 'lap';
    const defaultConfigs = {
      lap: { title: "Loan Against Property (LAP)", ltv: 65, tenure: 180, min: 500000, max: 20000000, foir: 50, cibil: 700 },
      tractor: { title: "Tractor Loan", ltv: 85, tenure: 84, min: 200000, max: 2500000, foir: 60, cibil: 650 },
      solar: { title: "Solar & Clean Energy", ltv: 90, tenure: 120, min: 100000, max: 5000000, foir: 65, cibil: 680 },
      msme: { title: "MSME Business Loan", ltv: 80, tenure: 60, min: 100000, max: 5000000, foir: 55, cibil: 700 }
    };

    function loadProductConfig(productKey) {
      currentConfigProduct = productKey;
      let storedConfig = JSON.parse(localStorage.getItem('namfin_bre_configs') || '{}');
      let config = storedConfig[productKey] || defaultConfigs[productKey];
      
      document.getElementById('bre-product-title').innerText = "Configuring: " + defaultConfigs[productKey].title;
      document.getElementById('bre-ltv').value = config.ltv;
      document.getElementById('bre-tenure').value = config.tenure;
      document.getElementById('bre-min').value = config.min;
      document.getElementById('bre-max').value = config.max;
      document.getElementById('bre-foir').value = config.foir;
      document.getElementById('bre-cibil').value = config.cibil;
    }

    function saveBREConfig() {
      let storedConfig = JSON.parse(localStorage.getItem('namfin_bre_configs') || '{}');
      storedConfig[currentConfigProduct] = {
        ltv: document.getElementById('bre-ltv').value,
        tenure: document.getElementById('bre-tenure').value,
        min: document.getElementById('bre-min').value,
        max: document.getElementById('bre-max').value,
        foir: document.getElementById('bre-foir').value,
        cibil: document.getElementById('bre-cibil').value
      };
      localStorage.setItem('namfin_bre_configs', JSON.stringify(storedConfig));
      alert("✅ Configuration for " + defaultConfigs[currentConfigProduct].title + " deployed to DEBOR Engine successfully!");
    }
"""

html = html.replace('// Populate Mock Leaderboard Data', bre_logic + '\n    // Populate Mock Leaderboard Data')

with open('namfindesk.html', 'w') as f:
    f.write(html)
