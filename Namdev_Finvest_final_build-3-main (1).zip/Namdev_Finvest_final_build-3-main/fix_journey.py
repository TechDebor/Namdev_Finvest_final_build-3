with open('index.html', 'r') as f:
    content = f.read()

import re

old_journey = r'<section id="journey".*?<!-- ==================================================================='
new_journey = """<section id="journey" class="section-stage" style="background: var(--bg-surface);">
      <div class="container">
        <div class="section-head">
          <span class="badge-quantum">ENTERPRISE ECOSYSTEM</span>
          <h2 class="section-title">The <span class="highlight">10-Minute</span> End-to-End Journey</h2>
          <p class="section-subtitle">Experience the fully automated Namfindesk ecosystem. From website application to WhatsApp sanction, powered by our DEBOR engine.</p>
        </div>

        <div class="pipeline-flow-container">
          <div class="pipeline-node">
            <div class="pipeline-step-badge">01</div>
            <h4 class="pipeline-title">Instant Web Application</h4>
            <p class="pipeline-desc">Fill out the minimal form on this website. Our system initiates your CRM record instantly.</p>
          </div>

          <div class="pipeline-node">
            <div class="pipeline-step-badge">02</div>
            <h4 class="pipeline-title">WhatsApp Soft Sanction</h4>
            <p class="pipeline-desc">Receive a simulated soft sanction letter and a secure "Continue" link directly in WhatsApp.</p>
          </div>

          <div class="pipeline-node">
            <div class="pipeline-step-badge">03</div>
            <h4 class="pipeline-title">DEBOR BRE Automation</h4>
            <p class="pipeline-desc">Our Business Rule Engine executes 14 checks (KYC, FOIR, CIBIL). Deviations route to specific departments.</p>
          </div>

          <div class="pipeline-node">
            <div class="pipeline-step-badge">04</div>
            <h4 class="pipeline-title">10-Minute Disbursal</h4>
            <p class="pipeline-desc">Once all holds are cleared by Ops & Credit, the Disbursement Officer pushes funds to your account instantly.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ==================================================================="""

content = re.sub(old_journey, new_journey, content, flags=re.DOTALL)

with open('index.html', 'w') as f:
    f.write(content)
