import re

with open('css/product.css', 'r') as f:
    content = f.read()

# Replace text colors
content = content.replace('color: var(--mono-white);', 'color: var(--text-primary);')

# Replace rgba borders and backgrounds
content = content.replace('background: rgba(255, 255, 255, 0.03);', 'background: var(--bg-surface);')
content = content.replace('border: 1px solid rgba(255, 255, 255, 0.08);', 'border: 1px solid var(--mono-border);')
content = content.replace('border-color: rgba(255, 255, 255, 0.35);', 'border-color: var(--glass-border-hover);')
content = content.replace('border-color: rgba(255, 255, 255, 0.3);', 'border-color: var(--glass-border-hover);')
content = content.replace('border: 1px solid rgba(255, 255, 255, 0.25);', 'border: 1px solid var(--mono-border);')

# In .feature-icon-box
content = content.replace('background: var(--mono-white);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: var(--mono-black);', 'background: var(--mono-dark);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: var(--bg-dark);')
# Wait, for check-icon-box
content = content.replace('background: var(--mono-white);\n  color: var(--mono-black);', 'background: var(--mono-dark);\n  color: var(--bg-dark);')

# In product-cta-banner
content = content.replace('background: var(--mono-dark);', 'background: var(--bg-elevated);')

# box-shadows that are dark
content = content.replace('box-shadow: 0 20px 40px rgba(0, 0, 0, 0.8);', 'box-shadow: var(--glass-shadow);')
content = content.replace('box-shadow: 0 15px 35px rgba(0, 0, 0, 0.8);', 'box-shadow: var(--glass-shadow);')
content = content.replace('box-shadow: 0 20px 50px rgba(0, 0, 0, 0.9);', 'box-shadow: var(--glass-shadow);')

with open('css/product.css', 'w') as f:
    f.write(content)
