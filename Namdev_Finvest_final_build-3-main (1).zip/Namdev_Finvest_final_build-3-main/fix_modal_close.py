with open('payment.html', 'r') as f:
    content = f.read()

script_to_replace = """
      if (payBtn && modal) {
        payBtn.addEventListener('click', (e) => {
          e.preventDefault();
          if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
          
          modal.classList.add('active');
          processing.style.display = 'block';
          success.style.display = 'none';
          
          setTimeout(() => {
            if (window.namfinSFX) window.namfinSFX.playClick(1000, 'triangle', 0.15);
            processing.style.display = 'none';
            success.style.display = 'block';
            txnId.innerText = Math.floor(100000000 + Math.random() * 900000000);
          }, 2000);
        });
        
        // Handle closing
        const closeBtn = modal.querySelector('.modal-close-btn');
        if (closeBtn) {
          closeBtn.addEventListener('click', () => {
             modal.classList.remove('active');
             if (window.namfinSFX) window.namfinSFX.playClick(400);
          });
        }
        
        modal.addEventListener('click', (e) => {
          if (e.target === modal) {
            modal.classList.remove('active');
          }
        });
      }
"""

import re
content = re.sub(r'if \(payBtn && modal\) \{.*?(?=\}\);)', script_to_replace.strip() + '\n      ', content, flags=re.DOTALL)

with open('payment.html', 'w') as f:
    f.write(content)

