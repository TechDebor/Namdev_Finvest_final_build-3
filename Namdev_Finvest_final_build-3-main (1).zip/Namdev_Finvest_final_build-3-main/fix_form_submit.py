with open('js/main.js', 'r') as f:
    content = f.read()

new_logic = """
  const modalForm = document.getElementById('quantumLoanForm');
  if (modalForm) {
    modalForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (window.namfinSFX) window.namfinSFX.playQuantumBeep();

      const submitBtn = modalForm.querySelector('button[type="submit"]');
      
      // Get data
      const name = document.getElementById('modalName') ? document.getElementById('modalName').value : 'Applicant';
      const mobile = document.getElementById('modalPhone') ? document.getElementById('modalPhone').value : '';
      const productSelect = document.getElementById('modalProductSelect');
      const product = productSelect ? productSelect.options[productSelect.selectedIndex].text : 'Loan';
      
      submitBtn.innerHTML = `<span class="pulse-dot"></span> ANALYZING DATA & SENDING WHATSAPP...`;
      submitBtn.disabled = true;

      setTimeout(() => {
        if (window.namfinSFX) window.namfinSFX.playClick(1000, 'triangle', 0.15);
        window.location.href = `whatsapp-simulator.html?name=${encodeURIComponent(name)}&mobile=${encodeURIComponent(mobile)}&product=${encodeURIComponent(product)}&amount=500000`;
      }, 1500);
    });
  }
"""

import re
content = re.sub(r'const modalForm = document\.getElementById\(\'quantumLoanForm\'\);.*?\}\);\n  \}', new_logic.strip(), content, flags=re.DOTALL)

with open('js/main.js', 'w') as f:
    f.write(content)
