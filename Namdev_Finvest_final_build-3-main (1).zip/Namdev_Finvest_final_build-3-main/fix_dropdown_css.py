import re

css_to_add = """
/* ==========================================================================
   DROPDOWN MENU SIMPLE FIX
   ========================================================================== */
.dropdown-menu-simple {
  position: absolute;
  top: 100%;
  left: 0;
  background: var(--bg-surface, #ffffff);
  border: 1px solid var(--border, #e2e8f0);
  border-radius: 8px;
  padding: 10px 0;
  min-width: 220px;
  opacity: 0;
  visibility: hidden;
  transform: translateY(10px);
  transition: all 0.3s ease;
  box-shadow: 0 10px 25px rgba(0,0,0,0.05);
  z-index: 100;
}
.nav-item-dropdown {
  position: relative;
}
.nav-item-dropdown:hover .dropdown-menu-simple {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
}
.dropdown-menu-simple li {
  list-style: none;
}
.dropdown-menu-simple a {
  display: block;
  padding: 8px 20px;
  color: var(--text-primary, #1a202c);
  text-decoration: none;
  font-size: 0.85rem;
  font-weight: 500;
  transition: background 0.2s, color 0.2s;
}
.dropdown-menu-simple a:hover {
  background: var(--bg, #f4f6fa);
  color: var(--brand, #5149dc);
}
"""

try:
    with open('css/style.css', 'r') as f:
        content = f.read()
        
    if "DROPDOWN MENU SIMPLE FIX" not in content:
        with open('css/style.css', 'w') as f:
            f.write(content + "\n" + css_to_add)
        print("Successfully added dropdown CSS to style.css")
    else:
        print("Dropdown CSS already in style.css")
except Exception as e:
    print(f"Error: {e}")
