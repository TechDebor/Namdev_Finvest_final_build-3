import glob
import re

# 1. Update css/style.css
css_update = """
/* ==========================================================================
   DYNAMIC DYNAMIC GRADIENT VARIABLES
   ========================================================================== */
:root {
  --grad-c1: #6366f1; /* Default Cyberpunk */
  --grad-c2: #a855f7;
  --grad-c3: #ec4899;
  
  --theme-text-grad: linear-gradient(135deg, var(--grad-c1) 0%, var(--grad-c2) 50%, var(--grad-c3) 100%);
  --theme-btn-grad: linear-gradient(135deg, var(--grad-c1) 0%, var(--grad-c2) 100%);
  --theme-btn-glow: rgba(99, 102, 241, 0.4);
}

.highlight {
  background: var(--theme-text-grad) !important;
  -webkit-background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  background-clip: text !important;
}

.btn-quantum {
  background: var(--theme-btn-grad) !important;
  box-shadow: 0 4px 15px var(--theme-btn-glow) !important;
}

.glow-orb-1 { background: radial-gradient(circle, var(--grad-c1) 0%, transparent 70%) !important; opacity: 0.15; }
.glow-orb-2 { background: radial-gradient(circle, var(--grad-c3) 0%, transparent 70%) !important; opacity: 0.15; }

/* Floating Theme Selector */
.theme-selector-widget {
  position: fixed;
  bottom: 24px;
  left: 24px;
  background: var(--bg-surface);
  border: 1px solid var(--border);
  padding: 10px 14px;
  border-radius: 50px;
  display: flex;
  gap: 10px;
  align-items: center;
  box-shadow: var(--glass-shadow);
  z-index: 1000;
  backdrop-filter: blur(10px);
}
.theme-dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  cursor: pointer;
  border: 2px solid transparent;
  transition: transform 0.2s, border-color 0.2s;
}
.theme-dot:hover {
  transform: scale(1.1);
}
.theme-dot.active {
  border-color: var(--text-primary);
  transform: scale(1.1);
}
"""

try:
    with open('css/style.css', 'r') as f:
        content = f.read()
    if "DYNAMIC DYNAMIC GRADIENT VARIABLES" not in content:
        with open('css/style.css', 'a') as f:
            f.write("\n" + css_update)
        print("Injected dynamic gradient CSS variables.")
except Exception as e:
    print(e)


# 2. Inject JS logic into js/main.js
js_logic = """
/* ==========================================================================
   DYNAMIC GRADIENT THEME SELECTOR LOGIC
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
    const gradients = {
        cyberpunk: { c1: '#6366f1', c2: '#a855f7', c3: '#ec4899', glow: 'rgba(99,102,241,0.4)' },
        emerald:   { c1: '#14b8a6', c2: '#10b981', c3: '#84cc16', glow: 'rgba(16,185,129,0.4)' },
        sunset:    { c1: '#f43f5e', c2: '#f97316', c3: '#eab308', glow: 'rgba(249,115,22,0.4)' },
        ocean:     { c1: '#06b6d4', c2: '#3b82f6', c3: '#4f46e5', glow: 'rgba(59,130,246,0.4)' }
    };

    const applyGradient = (themeId) => {
        const theme = gradients[themeId] || gradients.cyberpunk;
        document.documentElement.style.setProperty('--grad-c1', theme.c1);
        document.documentElement.style.setProperty('--grad-c2', theme.c2);
        document.documentElement.style.setProperty('--grad-c3', theme.c3);
        document.documentElement.style.setProperty('--theme-btn-glow', theme.glow);
        localStorage.setItem('namfin_gradient', themeId);
        
        document.querySelectorAll('.theme-dot').forEach(dot => {
            dot.classList.toggle('active', dot.dataset.grad === themeId);
        });
    };

    // Initialize from localStorage
    const savedGrad = localStorage.getItem('namfin_gradient') || 'cyberpunk';
    applyGradient(savedGrad);

    // Add click listeners to dots
    document.querySelectorAll('.theme-dot').forEach(dot => {
        dot.addEventListener('click', (e) => {
            applyGradient(e.target.dataset.grad);
        });
    });
});
"""

try:
    with open('js/main.js', 'r') as f:
        content = f.read()
    if "DYNAMIC GRADIENT THEME SELECTOR LOGIC" not in content:
        with open('js/main.js', 'a') as f:
            f.write("\n" + js_logic)
        print("Injected dynamic gradient JS logic.")
except Exception as e:
    print(e)


# 3. Inject the floating HTML widget into all files
html_widget = """
  <!-- FLOATING THEME GRADIENT SELECTOR -->
  <div class="theme-selector-widget">
    <span style="font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-right: 4px;">THEME</span>
    <div class="theme-dot" data-grad="cyberpunk" style="background: linear-gradient(135deg, #6366f1, #ec4899);" title="Cyberpunk"></div>
    <div class="theme-dot" data-grad="emerald" style="background: linear-gradient(135deg, #14b8a6, #84cc16);" title="Emerald"></div>
    <div class="theme-dot" data-grad="sunset" style="background: linear-gradient(135deg, #f43f5e, #eab308);" title="Sunset"></div>
    <div class="theme-dot" data-grad="ocean" style="background: linear-gradient(135deg, #06b6d4, #4f46e5);" title="Ocean"></div>
  </div>
"""

html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        if "FLOATING THEME GRADIENT SELECTOR" not in content:
            # Insert just before the closing </body> tag
            content = content.replace('</body>', html_widget + '\n</body>')
            with open(file, 'w') as f:
                f.write(content)
            print(f"Added theme widget to {file}")
    except Exception as e:
        print(f"Error modifying {file}: {e}")

