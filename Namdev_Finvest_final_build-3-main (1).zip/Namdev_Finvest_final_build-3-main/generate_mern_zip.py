import os
import shutil

APP_DIR = "Namdev_MERN_Stack_App"

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)

if os.path.exists(APP_DIR):
    shutil.rmtree(APP_DIR)

# ==========================================
# BACKEND (Node.js / Express / Mongoose)
# ==========================================

create_file(f"{APP_DIR}/backend/package.json", """{
  "name": "namdev-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": { "start": "node server.js", "dev": "nodemon server.js" },
  "dependencies": { "cors": "^2.8.5", "dotenv": "^16.3.1", "express": "^4.18.2", "mongoose": "^7.5.0" }
}""")

create_file(f"{APP_DIR}/backend/server.js", """
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

// In a real app, you would connect to MongoDB here
// mongoose.connect(process.env.MONGO_URI);

let applications = [];
let tasks = [
    { id: 'DEV-1001', loan: 'LN-260901', name: 'Rahul Sharma', product: 'MSME', rule: 'FOIR exceeds permitted threshold', dept: 'Credit', priority: 'High', status: 'Open' },
    { id: 'DEV-1002', loan: 'LN-260902', name: 'Priya Meena', product: 'LAP', rule: 'Aadhaar / PAN name mismatch', dept: 'KYC', priority: 'High', status: 'Open' }
];

app.get('/api/health', (req, res) => res.json({ status: 'ok', engine: 'DEBOR' }));

app.post('/api/applications', (req, res) => {
    const appData = { id: 'APP-' + Date.now(), ...req.body, status: 'Processing' };
    applications.push(appData);
    res.json(appData);
});

app.get('/api/tasks', (req, res) => {
    res.json(tasks);
});

app.post('/api/tasks/:id/resolve', (req, res) => {
    const { id } = req.params;
    tasks = tasks.map(t => t.id === id ? { ...t, status: 'Resolved' } : t);
    res.json({ success: true });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
""")

# ==========================================
# FRONTEND (React + Vite + Tailwind CSS)
# ==========================================

create_file(f"{APP_DIR}/frontend/package.json", """{
  "name": "namdev-frontend",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
  "dependencies": { "react": "^18.2.0", "react-dom": "^18.2.0", "react-router-dom": "^6.15.0" },
  "devDependencies": { "@vitejs/plugin-react": "^4.0.3", "autoprefixer": "^10.4.14", "postcss": "^8.4.27", "tailwindcss": "^3.3.3", "vite": "^4.4.5" }
}""")

create_file(f"{APP_DIR}/frontend/vite.config.js", """
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({ plugins: [react()] })
""")

create_file(f"{APP_DIR}/frontend/tailwind.config.js", """
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { brand: '#4b47df', ink: '#15233d', bgLight: '#f5f7fb' } } },
  plugins: [],
}""")

create_file(f"{APP_DIR}/frontend/postcss.config.js", """
export default { plugins: { tailwindcss: {}, autoprefixer: {} } }
""")

create_file(f"{APP_DIR}/frontend/index.html", """
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Namdev Finvest MERN</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
""")

create_file(f"{APP_DIR}/frontend/src/index.css", """
@tailwind base;
@tailwind components;
@tailwind utilities;

body { background-color: #f5f7fb; color: #15233d; font-family: 'Inter', sans-serif; }
""")

create_file(f"{APP_DIR}/frontend/src/main.jsx", """
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>,
)
""")

create_file(f"{APP_DIR}/frontend/src/App.jsx", """
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import BREEngine from './pages/BREEngine';
import CRMWorkbench from './pages/CRMWorkbench';

export default function App() {
  return (
    <BrowserRouter>
      <nav className="bg-ink text-white p-4 flex justify-between items-center shadow-lg">
        <div className="font-black text-xl tracking-tight">NAMDEV <span className="text-brand">FINVEST</span></div>
        <div className="flex gap-6 text-sm font-bold text-gray-300">
          <Link to="/" className="hover:text-white transition">Home</Link>
          <Link to="/apply" className="hover:text-white transition">BRE Decision Engine</Link>
          <Link to="/crm" className="hover:text-white transition">Deviation CRM Workbench</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/apply" element={<BREEngine />} />
        <Route path="/crm" element={<CRMWorkbench />} />
      </Routes>
    </BrowserRouter>
  );
}
""")

create_file(f"{APP_DIR}/frontend/src/pages/LandingPage.jsx", """
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function LandingPage() {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand rounded-full mix-blend-screen filter blur-[120px] opacity-20"></div>
      
      <div className="z-10 text-center max-w-3xl">
        <div className="mb-6 flex justify-center gap-4">
          <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-bold tracking-wider">RBI REGISTERED NBFC</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter leading-tight">Minimalist Financing for <span className="text-gray-400">Bharat's Visionaries.</span></h1>
        <p className="text-lg text-gray-400 mb-10 leading-relaxed">
          Empowering grassroots entrepreneurs, rural farmers, clean energy adopters, and transport fleets with instant underwriting and high-contrast simplicity.
        </p>
        <button 
          onClick={() => navigate('/apply')} 
          className="bg-white text-black px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-200 hover:scale-105 transition transform shadow-[0_0_40px_rgba(255,255,255,0.3)]">
          Instant Apply (10 Min Flow) ->
        </button>
      </div>
    </div>
  );
}
""")

create_file(f"{APP_DIR}/frontend/src/pages/BREEngine.jsx", """
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function BREEngine() {
  const navigate = useNavigate();
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const startEngine = () => {
    setRunning(true);
    let p = 0;
    const interval = setInterval(() => {
      p += 15;
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
      }
    }, 500);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-bgLight p-8">
      <div className="max-w-5xl mx-auto">
        
        <div className="flex justify-between items-start mb-8">
          <div>
            <div className="text-xs font-bold text-brand tracking-widest mb-2">ORIGINATION / DECISION INTELLIGENCE</div>
            <h1 className="text-3xl font-black tracking-tight text-ink">Smart Loan Decision Engine ✧</h1>
            <p className="text-gray-500 mt-1">Capture minimum information. Automate verification. Route exceptions.</p>
          </div>
          <div className="px-4 py-2 bg-white border rounded-full text-xs font-bold shadow-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span> ENGINE ONLINE
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Form Panel */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 className="text-lg font-bold mb-1">01. Minimal Applicant Intake</h2>
            <p className="text-xs text-gray-500 mb-6">Enter the core KYC details to initiate the journey.</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-600 mb-1">Applicant Name</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" defaultValue="Aarav Sharma" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Mobile Number</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" defaultValue="9876543210" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">PAN Number</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand uppercase" defaultValue="ABCDE1234F" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Loan Product</label>
                <select className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand">
                  <option>MSME Loan</option>
                  <option>LAP</option>
                  <option>Solar Loan</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">Amount (₹)</label>
                <input className="w-full border rounded-lg p-3 text-sm outline-none focus:border-brand" type="number" defaultValue="350000" />
              </div>
            </div>
            
            <button onClick={startEngine} disabled={running} className="w-full bg-brand text-white py-3 rounded-lg font-bold shadow-lg shadow-brand/30 hover:bg-blue-700 transition disabled:opacity-50">
              ✧ Run Intelligent Assessment
            </button>
          </div>

          {/* Execution Panel */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex flex-col">
            <h2 className="text-lg font-bold mb-1">02. Live Decision Execution</h2>
            <p className="text-xs text-gray-500 mb-6">Transparent checks, logs and exception traceability.</p>
            
            <div className="flex-1 bg-gray-50 rounded-xl p-5 border border-gray-100 flex flex-col justify-center">
              {!running ? (
                <div className="text-center text-gray-400 font-medium">Awaiting assessment start...</div>
              ) : (
                <>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-bold text-ink">Executing BRE Checks...</span>
                    <span className="text-xs font-bold text-brand">{Math.min(progress, 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-6 overflow-hidden">
                    <div className="bg-brand h-2 rounded-full transition-all duration-300" style={{width: `${progress}%`}}></div>
                  </div>
                  
                  {progress >= 100 && (
                    <div className="mt-auto bg-red-50 border border-red-100 p-4 rounded-lg">
                      <h3 className="text-red-700 font-bold text-sm mb-1">Exceptions Routed</h3>
                      <p className="text-red-600/80 text-xs mb-3">Tasks assigned to specific department owners. Review required before disbursement.</p>
                      <button onClick={() => navigate('/crm')} className="bg-white border border-red-200 text-red-700 px-4 py-2 rounded font-bold text-xs shadow-sm w-full">
                        Open Deviation Command Centre ->
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
""")

create_file(f"{APP_DIR}/frontend/src/pages/CRMWorkbench.jsx", """
import React, { useState, useEffect } from 'react';

export default function CRMWorkbench() {
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);

  useEffect(() => {
    // In a real app, fetch from backend: fetch('http://localhost:5000/api/tasks')
    setTasks([
      { id: 'DEV-1001', name: 'Aarav Sharma', product: 'MSME', rule: 'FOIR exceeds permitted threshold', dept: 'Credit', priority: 'High', status: 'Open' },
      { id: 'DEV-1002', name: 'Aarav Sharma', product: 'MSME', rule: 'Aadhaar / PAN name mismatch', dept: 'KYC', priority: 'High', status: 'Open' }
    ]);
  }, []);

  const resolveTask = () => {
    setTasks(tasks.map(t => t.id === selectedTask.id ? { ...t, status: 'Resolved' } : t));
    setSelectedTask(null);
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-bgLight">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r flex flex-col">
        <div className="p-6 border-b">
          <div className="font-black text-ink text-lg tracking-tight">DEBOR <span className="text-brand font-normal">BRE OS</span></div>
          <div className="text-[10px] bg-blue-50 text-brand px-2 py-1 rounded inline-block mt-1 font-bold">LENDING INTELLIGENCE</div>
        </div>
        <div className="p-4 flex-1">
          <div className="text-[10px] font-bold text-gray-400 tracking-wider mb-3 px-3">WORKSPACE</div>
          <div className="px-3 py-2 bg-blue-50 text-brand rounded-lg font-bold text-sm mb-1">Command Centre</div>
          <div className="px-3 py-2 text-gray-500 hover:bg-gray-50 rounded-lg text-sm mb-1 cursor-pointer font-medium">My Task Workspace</div>
          <div className="px-3 py-2 text-gray-500 hover:bg-gray-50 rounded-lg text-sm mb-1 cursor-pointer font-medium">All Deviations</div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-auto">
        <div className="flex justify-between items-start mb-8">
          <div>
            <div className="text-[11px] font-bold text-brand tracking-widest mb-1">BRE EXCEPTION MANAGEMENT</div>
            <h1 className="text-2xl font-black text-ink tracking-tight mb-1">Deviation Command Centre</h1>
            <p className="text-gray-500 text-sm">Your live queue of credit policy exceptions, obligations and BRE failures.</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-500">Viewing as</span>
            <select className="border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-ink bg-white shadow-sm outline-none">
              <option>Credit Manager</option>
              <option>KYC Officer</option>
              <option>Disbursement Officer</option>
            </select>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Assigned Deviations', value: tasks.length },
            { label: 'New Tasks', value: tasks.filter(t=>t.status==='Open').length },
            { label: 'SLA Breaches', value: '0' },
            { label: 'Resolved', value: tasks.filter(t=>t.status==='Resolved').length }
          ].map((s, i) => (
            <div key={i} className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden">
              <div className="text-xs font-bold text-gray-400 mb-2">{s.label}</div>
              <div className="text-3xl font-black text-ink tracking-tight">{s.value}</div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex justify-between items-center">
            <h2 className="font-bold text-ink">Assigned Deviation Queue</h2>
            <span className="text-xs bg-gray-100 px-3 py-1 rounded-full text-gray-500 font-bold">{tasks.length} OPEN</span>
          </div>
          <table className="w-full text-left">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Case / Customer</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">BRE Deviation</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Department</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Status</th>
                <th className="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => (
                <tr key={t.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">
                  <td className="p-4">
                    <div className="font-bold text-ink text-sm">{t.name}</div>
                    <div className="text-xs text-gray-400 mt-1">{t.id} · {t.product}</div>
                  </td>
                  <td className="p-4 text-sm font-bold text-ink">{t.rule}</td>
                  <td className="p-4 text-sm text-gray-600">{t.dept}</td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide ${t.status === 'Open' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-green-50 text-green-600 border border-green-100'}`}>
                      {t.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <button 
                      onClick={() => setSelectedTask(t)} 
                      disabled={t.status === 'Resolved'} 
                      className="text-brand font-bold text-xs bg-blue-50 px-3 py-2 rounded-lg hover:bg-blue-100 transition disabled:opacity-50 disabled:grayscale">
                      Review Case ->
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Resolution Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-ink/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 w-full max-w-lg shadow-2xl">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-xl font-black text-ink mb-1">Resolve Exception</h2>
                <p className="text-sm text-gray-500">{selectedTask.id}: {selectedTask.rule}</p>
              </div>
              <button onClick={() => setSelectedTask(null)} className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-500">✕</button>
            </div>
            
            <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl mb-6 text-sm text-orange-800">
              Assigned to: <strong>{selectedTask.dept}</strong>. Only authorized officers can resolve this deviation.
            </div>

            <div className="mb-6">
              <label className="block text-xs font-bold text-gray-600 mb-2">Resolution Notes / Evidence Reference *</label>
              <textarea className="w-full border border-gray-200 rounded-xl p-3 text-sm outline-none focus:border-brand resize-none" rows="4" placeholder="Add supporting remarks, verification logs, or evidence reference IDs..."></textarea>
            </div>
            
            <div className="flex justify-end gap-3">
              <button onClick={() => setSelectedTask(null)} className="px-5 py-2.5 rounded-xl font-bold text-gray-600 hover:bg-gray-100 transition">Cancel</button>
              <button onClick={resolveTask} className="px-5 py-2.5 bg-brand text-white rounded-xl font-bold shadow-lg shadow-brand/30 hover:bg-blue-700 transition">✓ Mark Resolved</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
""")

import zipfile
def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file), 
                       os.path.relpath(os.path.join(root, file), 
                                       os.path.join(path, '..')))

print("Zipping application...")
with zipfile.ZipFile(APP_DIR + '.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(APP_DIR, zipf)
print("Done!")
