import glob
import re
import time

# 1. Add the translation logic to js/main.js
translation_js = """
/* ==========================================================================
   DYNAMIC MULTILINGUAL TRANSLATION ENGINE (GOOGLE TRANSLATE)
   ========================================================================== */
function switchLanguage(langCode) {
    // Set Google Translate cookies
    document.cookie = "googtrans=/en/" + langCode + "; path=/;";
    document.cookie = "googtrans=/en/" + langCode + "; path=/; domain=" + location.hostname;
    
    // Create the Google Translate element if it doesn't exist
    if (!document.getElementById('google_translate_element')) {
        let gtEl = document.createElement('div');
        gtEl.id = 'google_translate_element';
        gtEl.style.display = 'none';
        document.body.appendChild(gtEl);
        
        let gtScript = document.createElement('script');
        gtScript.type = 'text/javascript';
        gtScript.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
        document.body.appendChild(gtScript);
        
        window.googleTranslateElementInit = function() {
            new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element');
        };
    }
    
    // Reload the page to apply the translation immediately
    setTimeout(() => {
        window.location.reload();
    }, 300);
}

// Ensure Google Translate is initialized on load if a language is selected
document.addEventListener('DOMContentLoaded', () => {
    if (document.cookie.includes('googtrans=') && !document.cookie.includes('/en/en')) {
        let gtEl = document.createElement('div');
        gtEl.id = 'google_translate_element';
        gtEl.style.display = 'none';
        document.body.appendChild(gtEl);
        
        let gtScript = document.createElement('script');
        gtScript.type = 'text/javascript';
        gtScript.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
        document.body.appendChild(gtScript);
        
        window.googleTranslateElementInit = function() {
            new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element');
        };
    }
});
"""

try:
    with open('js/main.js', 'r') as f:
        js_content = f.read()
    if "DYNAMIC MULTILINGUAL TRANSLATION ENGINE" not in js_content:
        with open('js/main.js', 'a') as f:
            f.write("\n" + translation_js)
        print("Translation JS added to main.js")
except Exception as e:
    print(f"JS Error: {e}")

# 2. Update the dropdown links in all HTML files
html_files = glob.glob('*.html')
timestamp = str(int(time.time()))

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Replace alerts with actual switchLanguage calls
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>English</a>', 'onclick="switchLanguage(\'en\'); return false;">English</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>हिंदी \(Hindi\)</a>', 'onclick="switchLanguage(\'hi\'); return false;">हिंदी (Hindi)</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>मराठी \(Marathi\)</a>', 'onclick="switchLanguage(\'mr\'); return false;">मराठी (Marathi)</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>ગુજરાતી \(Gujarati\)</a>', 'onclick="switchLanguage(\'gu\'); return false;">ગુજરાતી (Gujarati)</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>اردو \(Urdu\)</a>', 'onclick="switchLanguage(\'ur\'); return false;">اردو (Urdu)</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>ਪੰਜਾਬੀ \(Punjabi\)</a>', 'onclick="switchLanguage(\'pa\'); return false;">ਪੰਜਾਬੀ (Punjabi)</a>', content)
        content = re.sub(r'onclick="alert\([^)]+\);\s*return false;"[^>]*>ଓଡ଼ିଆ \(Odia\)</a>', 'onclick="switchLanguage(\'or\'); return false;">ଓଡ଼ିଆ (Odia)</a>', content)
        
        # Hide the default Google Translate top banner in CSS
        if '<head>' in content and 'goog-te-banner-frame' not in content:
            style_inject = """
    <style>
      /* Hide Google Translate Top Banner and Tooltips */
      .goog-te-banner-frame.skiptranslate, .goog-te-gadget-icon { display: none !important; }
      body { top: 0px !important; }
      #goog-gt-tt, .goog-te-balloon-frame { display: none !important; }
      .goog-text-highlight { background: none !important; box-shadow: none !important; }
    </style>
"""
            content = content.replace('</head>', style_inject + '</head>')
            
        # Bust cache
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'src="js/main\.js\?v=\d+"', f'src="js/main.js?v={timestamp}"', content)
        content = re.sub(r'src="js/main\.js"', f'src="js/main.js?v={timestamp}"', content)

        with open(file, 'w') as f:
            f.write(content)
            
    except Exception as e:
        print(f"Error modifying {file}: {e}")

print("HTML files updated with live translation hooks.")
