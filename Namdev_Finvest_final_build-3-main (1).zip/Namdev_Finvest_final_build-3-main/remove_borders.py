import re
import time

try:
    with open('apply.html', 'r') as f:
        content = f.read()

    # We will append an ultra-premium borderless CSS override to the <style> block
    borderless_css = """
  /* ==========================================================================
     PREMIUM BORDERLESS UI (NO BLACK STROKES)
     ========================================================================== */
  .screen, .section, .verify-tile, .entry, dialog, .toast, .eyebrow {
    border: none !important;
  }
  
  /* Main Glass Panel Edge (Very faint light edge, no dark strokes) */
  .screen {
    box-shadow: 0 40px 80px rgba(0,0,0,0.1), inset 0 1px 1px rgba(255,255,255,0.15) !important;
  }
  
  /* Sections & Tiles - Soft floating look instead of borders */
  .section, .verify-tile {
    background: rgba(128, 128, 128, 0.04) !important;
    box-shadow: 0 8px 24px rgba(0,0,0,0.02) !important;
    border-radius: 16px !important;
  }
  
  /* Inputs (Fill in the blanks) - Neumorphic / Inner Shadow */
  .entry {
    background: rgba(128, 128, 128, 0.06) !important;
    box-shadow: inset 0 2px 6px rgba(0,0,0,0.04) !important;
    border-radius: 12px !important;
    transition: all 0.3s ease !important;
  }
  
  [data-theme="dark"] .entry {
    background: rgba(0, 0, 0, 0.2) !important;
    box-shadow: inset 0 2px 6px rgba(0,0,0,0.2) !important;
  }
  
  .entry:focus-within {
    background: rgba(128, 128, 128, 0.08) !important;
    box-shadow: 0 0 0 2px rgba(var(--grad-c1-rgb, 99, 102, 241), 0.4), inset 0 2px 6px rgba(0,0,0,0.02) !important;
  }
  
  /* Upload Box */
  .upload-box {
    border: 2px dashed rgba(128, 128, 128, 0.15) !important; /* Soft, not black/harsh */
    border-radius: 14px !important;
  }
  
  /* Section Heads */
  .section-head {
    border-bottom: none !important;
    background: transparent !important;
  }
  
  /* Dialog & Modals */
  dialog {
    box-shadow: 0 30px 90px rgba(0,0,0,0.15), inset 0 1px 1px rgba(255,255,255,0.1) !important;
  }
"""

    if 'PREMIUM BORDERLESS UI' not in content:
        content = content.replace('</style>', borderless_css + '\n</style>')

    # Cache bust
    timestamp = str(int(time.time()))
    content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
    
    with open('apply.html', 'w') as f:
        f.write(content)
        
    print("Removed all black strokes and added premium soft shadows.")
except Exception as e:
    print(e)
