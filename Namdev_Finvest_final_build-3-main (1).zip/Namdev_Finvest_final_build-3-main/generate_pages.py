import os
import glob

# The exact Minimalist Theme Header & Head
head_nav = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Namdev Finvest | {TITLE}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;800&family=Space+Grotesk:wght@400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/components.css">
  <style>
    /* Simple Dropdown for Corporate Tabs */
    .dropdown-menu-simple { position: absolute; top: 100%; left: 0; background: var(--bg-surface, #ffffff); border: 1px solid var(--border, #e2e8f0); border-radius: 8px; padding: 10px 0; min-width: 220px; opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.3s ease; box-shadow: 0 10px 25px rgba(0,0,0,0.05); z-index: 100; }
    .nav-item-dropdown:hover .dropdown-menu-simple { opacity: 1; visibility: visible; transform: translateY(0); }
    .dropdown-menu-simple li { list-style: none; }
    .dropdown-menu-simple a { display: block; padding: 8px 20px; color: var(--text-primary, #1a202c); text-decoration: none; font-size: 0.85rem; font-weight: 500; transition: background 0.2s, color 0.2s; }
    .dropdown-menu-simple a:hover { background: var(--bg, #f4f6fa); color: var(--brand, #5149dc); }
    
    .hero-quantum { padding: 160px 20px 80px; text-align: center; }
    .hero-quantum h1 { font-family: 'Syne', sans-serif; font-size: 3.5rem; font-weight: 800; margin-bottom: 20px; letter-spacing: -0.05em; }
    .hero-quantum p { font-family: 'Space Grotesk', sans-serif; font-size: 1.2rem; color: var(--text-muted); max-width: 800px; margin: 0 auto; }
    .section-stage { padding: 80px 20px; }
    .content-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; max-width: 1200px; margin: 0 auto; }
    .info-card { background: var(--bg-surface); border: 1px solid var(--border); padding: 30px; border-radius: 12px; transition: transform 0.3s; }
    .info-card:hover { transform: translateY(-5px); border-color: var(--brand); }
  </style>
</head>
<body>
  <div class="ambient-glow-layer"><div class="glow-orb glow-orb-1"></div><div class="glow-orb glow-orb-2"></div></div>
  <div class="cyber-grid-bg"></div>

  <div class="app-container">
    <header class="quantum-nav">
      <div class="container">
        <div class="nav-inner">
          <a href="index.html" class="brand-quantum">
            <div class="brand-emblem">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>
              </svg>
            </div>
            <div class="brand-text"><span class="brand-title">NAMDEV FINVEST</span><span class="brand-sub">NBFC // RBI REGISTERED</span></div>
          </a>
          <nav>
            <ul class="nav-menu">
              <li class="nav-item-dropdown">
                <a href="about.html" class="nav-link">About <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="about.html#who-we-are">Get to Know Us</a></li>
                  <li><a href="about.html#board">Board of Directors</a></li>
                  <li><a href="about.html#management">Management Team</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="index.html#products" class="nav-link">Products <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-quantum">
                  <li><a href="msme.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">MSME Business Loans</span></div></a></li>
                  <li><a href="two-wheeler.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Two Wheeler Loans</span></div></a></li>
                  <li><a href="lap.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Loan Against Property (LAP)</span></div></a></li>
                  <li><a href="solar.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Solar & Clean Energy</span></div></a></li>
                  <li><a href="tractor.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Tractor & Agri Loans</span></div></a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="investor.html" class="nav-link" style="color: #ff4757;">Investor <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="investor.html#partners">Growth Partners</a></li>
                  <li><a href="investor.html#policies">Codes and Policies</a></li>
                  <li><a href="investor.html#reports">Annual Report</a></li>
                  <li><a href="investor.html#esg">ESG</a></li>
                  <li><a href="investor.html#rta">Registrar & Transfer Agent</a></li>
                  <li><a href="investor.html#disclosures">Disclosure Under Regulation 62...</a></li>
                  <li><a href="investor.html#financials">Financial Performance</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="team.html" class="nav-link">Our Team <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="team.html#culture">Life at Namdev</a></li>
                  <li><a href="team.html#gallery">Gallery</a></li>
                  <li><a href="team.html#careers">Career - Apply for positions</a></li>
                </ul>
              </li>
              <li><a href="contact.html" class="nav-link">Contact</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
"""

footer = """
    <footer class="quantum-footer">
      <div class="container">
        <div class="footer-bottom-bar" style="border: none; padding-top: 0;">
          <div>© 2026 Namdev Finvest Limited • CIN: U65921RJ1997PLC047090</div>
          <div class="status-indicator-strip"><span class="pulse-dot"></span> 137+ BRANCHES ACTIVE</div>
        </div>
      </div>
    </footer>
  </div>
</body>
</html>
"""

# 1. ABOUT PAGE
about_content = head_nav.replace("{TITLE}", "About Us") + """
    <section class="hero-quantum" id="who-we-are">
      <span class="badge-quantum">ESTABLISHED 2013</span>
      <h1>Empowering Rural Bharat.</h1>
      <p>Namdev Finvest Limited (Formerly Known as Namdev Finvest Private Limited) is a fast-growing RBI-registered NBFC dedicated to driving financial inclusion across India's underbanked sectors. With AUM crossing ₹1,200 Cr, we specialize in MSME, Green Finance, and Asset-backed lending.</p>
    </section>

    <section class="section-stage" id="board">
      <div class="container">
        <h2 style="text-align:center; font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px;">Board of Directors & Management</h2>
        <div class="content-grid">
          <div class="info-card">
            <h3>Jitendra Tanwar</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Managing Director & CEO</p>
            <p style="margin-top: 15px;">A visionary leader driving Namdev Finvest's mission to bridge the credit gap in semi-urban and rural geographies through innovative underwriting.</p>
          </div>
          <div class="info-card">
            <h3>Independent Directors</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Corporate Governance</p>
            <p style="margin-top: 15px;">Our board comprises distinguished veterans from the banking, finance, and regulatory sectors ensuring the highest standards of ESG and governance.</p>
          </div>
          <div class="info-card">
            <h3>Core Management</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Execution Leaders</p>
            <p style="margin-top: 15px;">A robust team of domain experts leading Credit, Operations, Compliance, and Technology, delivering a seamless 10-minute digital lending experience.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer

with open('about.html', 'w') as f: f.write(about_content)


# 2. INVESTOR PAGE
investor_content = head_nav.replace("{TITLE}", "Investor Relations") + """
    <section class="hero-quantum" id="partners">
      <span class="badge-quantum">CAPITAL PARTNERS</span>
      <h1>Growth & Investors.</h1>
      <p>Namdev Finvest is backed by globally respected institutional investors and development finance institutions. We recently raised $19 Million in Pre-Series C funding led by Maj Invest to deepen our presence in rural India.</p>
    </section>

    <section class="section-stage" style="background: var(--bg-surface);">
      <div class="container">
        <div class="content-grid">
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Maj Invest</h3>
            <p>Lead Investor - Pre-Series C</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Incofin</h3>
            <p>Global Impact Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">BII</h3>
            <p>British International Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">FMO & IIX</h3>
            <p>Development Finance Partners</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section-stage" id="disclosures">
      <div class="container">
        <h2 style="font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px;">Disclosures & ESG</h2>
        <div class="content-grid">
          <div class="info-card" id="esg">
            <h3>ESG Commitment</h3>
            <p style="margin-top: 10px;">Namdev Finvest Pvt. Ltd. earned the GOLD-level Client Protection certification from MFR for its high standards in social and environmental performance.</p>
          </div>
          <div class="info-card" id="financials">
            <h3>Financial Performance</h3>
            <p style="margin-top: 10px;">AUM crossed ₹1,200 Cr mark in FY24. Successfully raised USD 37 million (324 crore) from globally respected partners through listed NCDs and ECB structures.</p>
          </div>
          <div class="info-card" id="rta">
            <h3>RTA, DT & GRO</h3>
            <p style="margin-top: 10px;">Access official documentation regarding Registrar & Transfer Agent details, Debenture Trustees, and Grievance Redressal Officers.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer

with open('investor.html', 'w') as f: f.write(investor_content)


# 3. TEAM PAGE
team_content = head_nav.replace("{TITLE}", "Our Team & Careers") + """
    <section class="hero-quantum" id="culture">
      <span class="badge-quantum">LIFE AT NAMDEV</span>
      <h1>Build the Future of Finance.</h1>
      <p>Join a dynamic team of over 1,000+ professionals spread across 137+ branches in Rajasthan, Gujarat, MP, Punjab, and Delhi NCR. We are mechanizing Bharat and funding green transitions.</p>
    </section>

    <section class="section-stage" id="careers">
      <div class="container">
        <div class="content-grid">
          <div class="info-card">
            <h3>Careers at Namdev</h3>
            <p style="margin-top: 15px; margin-bottom: 20px;">We are always looking for ambitious Credit Managers, Branch Managers, and Technology experts.</p>
            <a href="https://namdevcareers.peoplestrong.com/" target="_blank" class="btn-quantum" style="text-decoration:none; padding:10px 20px; font-size:0.9rem;">View Open Roles</a>
          </div>
          <div class="info-card" id="gallery">
            <h3>Gallery & Culture</h3>
            <p style="margin-top: 15px;">Experience our vibrant branch culture, offsites, and the impact we create on the ground with our MSME partners and Solar adopters.</p>
          </div>
          <div class="info-card">
            <h3>Employee Testimonials</h3>
            <p style="margin-top: 15px;">Hear directly from our branch leaders and credit officers about their rapid career growth journeys within Namdev Finvest.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer

with open('team.html', 'w') as f: f.write(team_content)


# 4. CONTACT PAGE
contact_content = head_nav.replace("{TITLE}", "Contact Us") + """
    <section class="hero-quantum">
      <span class="badge-quantum">24/7 SUPPORT</span>
      <h1>Contact Us.</h1>
      <p>Whether you need a new loan, support with your EMI, or want to locate your nearest branch, our team is ready to assist you.</p>
    </section>

    <section class="section-stage">
      <div class="container">
        <div class="content-grid" style="grid-template-columns: 1fr 1fr;">
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Corporate Headquarters</h3>
            <p style="font-size: 1.1rem; color: var(--text-muted); margin-bottom: 10px;">"Namdev House", Plot No. 21</p>
            <p style="font-size: 1.1rem; color: var(--text-muted); margin-bottom: 10px;">Neer Sagar-A, Bhankrota</p>
            <p style="font-size: 1.1rem; color: var(--text-muted); margin-bottom: 30px;">Jaipur, Rajasthan - 302026</p>
            
            <h4 style="color: var(--brand); margin-bottom: 5px;">Toll Free</h4>
            <p style="font-size: 1.5rem; font-weight: bold; margin-bottom: 20px;">1800-103-5800</p>
            
            <h4 style="color: var(--brand); margin-bottom: 5px;">Email</h4>
            <p style="font-size: 1.2rem; font-weight: bold;">info@namfin.in</p>
          </div>
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">137+ Branches Across India</h3>
            <p style="color: var(--text-muted); margin-bottom: 20px;">We are expanding rapidly to serve you better. Find us in:</p>
            <ul style="color: var(--text-primary); font-size: 1.1rem; line-height: 2; padding-left: 20px; font-weight: 600;">
              <li>Rajasthan</li>
              <li>Gujarat</li>
              <li>Madhya Pradesh</li>
              <li>Punjab</li>
              <li>Haryana</li>
              <li>Delhi NCR</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
""" + footer

with open('contact.html', 'w') as f: f.write(contact_content)


# 5. UPDATE EXISTING FILES TO USE THE PROPER NAV LINKS
html_files = glob.glob('*.html')
nav_replacement_pattern = r'<ul class="nav-menu">.*?</nav>'

# Extract the new nav from our generated head_nav
start_idx = head_nav.find('<ul class="nav-menu">')
end_idx = head_nav.find('</nav>', start_idx)
correct_nav = head_nav[start_idx:end_idx] + '</nav>'

for file in html_files:
    if file in ['about.html', 'investor.html', 'team.html', 'contact.html']:
        continue # already have correct nav
        
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        s_idx = content.find('<ul class="nav-menu">')
        if s_idx != -1:
            e_idx = content.find('</nav>', s_idx)
            if e_idx != -1:
                content = content[:s_idx] + correct_nav + content[e_idx+6:]
                
        with open(file, 'w') as f:
            f.write(content)
        print(f"Updated nav links in {file}")
    except Exception as e:
        print(f"Failed to update nav in {file}: {e}")

