import re
import time

# 1. Read the original HTML provided by the user
with open('temp_apply.html', 'r', encoding='utf-8') as f:
    original = f.read()

# Extract Style, Body content, and Script
style_match = re.search(r'<style>(.*?)</style>', original, re.DOTALL)
script_match = re.search(r'<script>(.*?)</script>', original, re.DOTALL)
# Extract everything inside <body> except the body tags themselves
body_match = re.search(r'<body>(.*?)</body>', original, re.DOTALL)

if not (style_match and script_match and body_match):
    print("Failed to extract blocks from original HTML.")
    exit(1)

original_css = style_match.group(1)
original_js = script_match.group(1)
original_html = body_match.group(1)

# 2. Adapt the CSS to match Namdev Theme (Glassmorphism + Dark Mode)
adapted_css = original_css.replace(
    ':root{--ink:#0c1e43;--soft:#556c8e;--line:#dbe4f2;--purple:#6d56ed;--rose:#da3476;--green:#29ab6b;--input:#f7f9fd;--card:#fff;--header:#f4f7fc}',
    ':root{--ink:var(--text-primary);--soft:var(--text-secondary);--line:var(--border);--purple:var(--grad-c1);--rose:var(--grad-c3);--green:#29ab6b;--input:transparent;--card:transparent;--header:transparent;}'
)
# Remove the weird body background and padding, we will handle that in a wrapper
adapted_css = re.sub(r'body\{[^}]+\}', 'body { margin: 0; min-height: 100vh; }', adapted_css)

# Update `.screen` to look like `.apply-glass-panel`
adapted_css = adapted_css.replace(
    '.screen{max-width:1480px;margin:auto;background:rgba(255,255,255,.987);border:1px solid #e8edf6;border-radius:18px;box-shadow:0 16px 60px #59331625;padding:26px 28px 18px 28px;min-height:calc(100vh - 36px);position:relative;overflow:hidden}',
    '.screen{max-width:1200px;margin: 140px auto 60px auto; background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.05); backdrop-filter: blur(32px); -webkit-backdrop-filter: blur(32px); border: 1px solid rgba(128,128,128,0.2); border-radius: 28px; box-shadow: 0 40px 80px rgba(0,0,0,0.15); padding: 40px; position:relative; overflow:hidden;}'
)

# Dark mode overrides for inputs and tiles
adapted_css += """
[data-theme="dark"] .screen { background: rgba(9, 9, 11, 0.55); border: 1px solid rgba(255,255,255,0.08); }
[data-theme="light"] .screen { background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(0,0,0,0.06); }
.section, .verify-tile { background: rgba(128,128,128,0.05) !important; border-color: var(--line) !important; }
.section-head { background: rgba(128,128,128,0.05) !important; border-bottom: 1px solid var(--line); }
.entry { background: rgba(128,128,128,0.1) !important; border-color: rgba(128,128,128,0.2) !important; color: var(--ink) !important; }
.entry input, .entry select { color: var(--ink) !important; }
.entry:focus-within { border-color: var(--purple) !important; box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1) !important; }
dialog { background: var(--bg-card) !important; color: var(--ink) !important; border-color: var(--line) !important; }
.toast { background: var(--bg-card) !important; color: var(--ink) !important; border-color: var(--line) !important; }
.eyebrow { background: var(--bg-surface) !important; border-color: var(--line) !important; color: var(--ink) !important; }
h1, h2, h3, h4, p, label { color: var(--ink) !important; }
.subtitle, .section-head p { color: var(--soft) !important; }
"""

# 3. Wrap it in our global ecosystem
with open('index.html', 'r') as f:
    idx = f.read()

header_match = re.search(r'(.*?)<section class="hero-quantum"', idx, re.DOTALL)
footer_match = re.search(r'(<footer class="quantum-footer">.*)', idx, re.DOTALL)

header = header_match.group(1)
footer = footer_match.group(1)

# Ensure title is correct
header = re.sub(r'<title>.*?</title>', '<title>Instant Loan Apply | Namdev Finvest</title>', header)

# Remove the close application button from original HTML as we have global nav now
original_html = re.sub(r'<button class="close-application".*?</button>', '', original_html)

# Add our background orbs wrapper
full_body = f"""
<style>
  .apply-container-cyber {{
    min-height: 100vh;
    position: relative;
    background: var(--bg-dark);
    overflow-x: hidden;
  }}
  .cyber-orb {{
    position: absolute;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.4;
    z-index: 0;
    animation: floatOrb 15s infinite alternate ease-in-out;
  }}
  .orb-pink {{ width: 500px; height: 500px; background: var(--grad-c3); top: -100px; left: -100px; }}
  .orb-blue {{ width: 600px; height: 600px; background: var(--grad-c1); bottom: -150px; right: -100px; }}
  
  /* Original Extracted CSS (Adapted) */
  {adapted_css}
</style>

<div class="apply-container-cyber">
  <div class="cyber-orb orb-pink"></div>
  <div class="cyber-orb orb-blue"></div>
  {original_html}
</div>

<script>
  {original_js}
</script>
"""

timestamp = str(int(time.time()))
header = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', header)
header = re.sub(r'src="js/main\.js\?v=\d+"', f'src="js/main.js?v={timestamp}"', header)

with open('apply.html', 'w') as f:
    f.write(header + full_body + footer)

print("apply.html 100% functionally restored with original JS/CSS embedded into Namdev theme.")
