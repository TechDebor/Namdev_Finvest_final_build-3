import re
import time

# Extract header and footer from index.html
with open('index.html', 'r') as f:
    idx = f.read()

header_match = re.search(r'(.*?)<section class="hero-quantum"', idx, re.DOTALL)
footer_match = re.search(r'(<footer class="quantum-footer">.*)', idx, re.DOTALL)

if header_match and footer_match:
    header = header_match.group(1)
    footer = footer_match.group(1)
    
    # Update title
    header = re.sub(r'<title>.*?</title>', '<title>Instant Loan Apply | Namdev Finvest</title>', header)
    
    apply_body = """
    <style>
      .apply-container-cyber {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        background: var(--bg-dark);
        padding: 120px 20px 60px 20px;
      }
      .cyber-orb {
        position: absolute;
        border-radius: 50%;
        filter: blur(100px);
        opacity: 0.4;
        z-index: 0;
        animation: floatOrb 15s infinite alternate ease-in-out;
      }
      .orb-pink { width: 500px; height: 500px; background: var(--grad-c3); top: -100px; left: -100px; }
      .orb-blue { width: 600px; height: 600px; background: var(--grad-c1); bottom: -150px; right: -100px; }
      
      .apply-glass-panel {
        position: relative;
        z-index: 10;
        width: 100%;
        max-width: 1000px;
        background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.05);
        backdrop-filter: blur(32px);
        -webkit-backdrop-filter: blur(32px);
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 28px;
        padding: 40px;
        box-shadow: 0 40px 80px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.2);
      }
      
      [data-theme="dark"] .apply-glass-panel {
        background: rgba(9, 9, 11, 0.55);
        border: 1px solid rgba(255,255,255,0.08);
      }
      [data-theme="light"] .apply-glass-panel {
        background: rgba(255, 255, 255, 0.75);
        border: 1px solid rgba(0,0,0,0.06);
      }

      .section-cyber {
        background: rgba(128,128,128,0.05);
        border: 1px solid rgba(128,128,128,0.1);
        border-radius: 20px;
        padding: 24px;
        margin-bottom: 24px;
      }

      .apply-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
      .apply-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
      
      @media (max-width: 768px) {
        .apply-grid-2, .apply-grid-3 { grid-template-columns: 1fr; }
        .apply-glass-panel { padding: 24px; }
      }

      .input-cyber {
        width: 100%;
        padding: 14px 16px;
        border-radius: 12px;
        background: rgba(128,128,128,0.1);
        border: 1px solid rgba(128,128,128,0.2);
        color: var(--text-primary);
        font-family: var(--font-sans);
        font-size: 0.95rem;
        outline: none;
        transition: all 0.3s;
      }
      .input-cyber:focus {
        border-color: var(--grad-c1);
        background: rgba(128,128,128,0.15);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
      }
      .cyber-label {
        display: block;
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 8px;
        color: var(--text-secondary);
      }
      
      .btn-cyber-submit {
        width: 100%;
        padding: 18px;
        border-radius: 16px;
        border: none;
        background: var(--theme-btn-grad);
        color: #fff;
        font-size: 1.15rem;
        font-weight: 800;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
        box-shadow: 0 8px 25px var(--theme-btn-glow);
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 12px;
      }
      .btn-cyber-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px var(--theme-btn-glow);
      }
      
      .doc-verify-row {
        display: flex;
        gap: 10px;
      }
      .doc-verify-btn {
        flex: 0 0 100px;
        background: rgba(var(--grad-c1-rgb, 99, 102, 241), 0.1);
        color: var(--grad-c1, #6366f1);
        border: 1px solid rgba(var(--grad-c1-rgb, 99, 102, 241), 0.3);
        border-radius: 12px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s;
      }
      .doc-verify-btn:hover {
        background: rgba(var(--grad-c1-rgb, 99, 102, 241), 0.2);
      }
      .doc-verify-btn.verified {
        background: rgba(36, 169, 103, 0.1);
        color: #24a967;
        border-color: rgba(36, 169, 103, 0.3);
      }
    </style>

    <div class="apply-container-cyber">
      <div class="cyber-orb orb-pink"></div>
      <div class="cyber-orb orb-blue"></div>
      
      <div class="apply-glass-panel">
        
        <div style="text-align: center; margin-bottom: 40px;">
          <h1 style="font-family: 'Syne', sans-serif; font-size: 2.5rem; margin-bottom: 8px;">Instant Pre-Approval</h1>
          <p style="color: var(--text-muted); font-size: 1.05rem;">Experience 15-minute underwriting with our AI-powered BRE engine.</p>
        </div>
        
        <form onsubmit="submitApplication(event)">
          
          <!-- Identity Section -->
          <div class="section-cyber">
            <h3 style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--grad-c1);"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              Applicant Identity
            </h3>
            
            <div class="apply-grid-2">
              <div>
                <label class="cyber-label">Aadhaar Number <span style="color: #ed6083;">*</span></label>
                <div class="doc-verify-row">
                  <input type="text" id="aadhaar" class="input-cyber" placeholder="Enter 12-digit Aadhaar" maxlength="12" required>
                  <button type="button" class="doc-verify-btn" onclick="verifyDoc(this, 'aadhaar')">Verify</button>
                </div>
              </div>
              <div>
                <label class="cyber-label">PAN Number <span style="color: #ed6083;">*</span></label>
                <div class="doc-verify-row">
                  <input type="text" id="pan" class="input-cyber" placeholder="Enter 10-digit PAN" maxlength="10" style="text-transform: uppercase;" required>
                  <button type="button" class="doc-verify-btn" onclick="verifyDoc(this, 'pan')">Verify</button>
                </div>
              </div>
            </div>
            
            <div class="apply-grid-3" style="margin-top: 20px;">
              <div>
                <label class="cyber-label">Full Name</label>
                <input type="text" class="input-cyber" placeholder="As per Aadhaar" required>
              </div>
              <div>
                <label class="cyber-label">Date of Birth</label>
                <input type="date" class="input-cyber" required>
              </div>
              <div>
                <label class="cyber-label">Gender</label>
                <select class="input-cyber" required>
                  <option value="" disabled selected>Select</option>
                  <option value="M">Male</option>
                  <option value="F">Female</option>
                  <option value="O">Other</option>
                </select>
              </div>
            </div>
          </div>
          
          <!-- Business Section -->
          <div class="section-cyber">
            <h3 style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--grad-c3);"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
              Business Credentials
            </h3>
            
            <div class="apply-grid-2">
              <div>
                <label class="cyber-label">Udyam Registration</label>
                <div class="doc-verify-row">
                  <input type="text" class="input-cyber" placeholder="UDYAM-XX-00-0000000">
                  <button type="button" class="doc-verify-btn" onclick="verifyDoc(this, 'udyam')">Fetch</button>
                </div>
              </div>
              <div>
                <label class="cyber-label">GST Number (Optional)</label>
                <div class="doc-verify-row">
                  <input type="text" class="input-cyber" placeholder="22AAAAA0000A1Z5">
                  <button type="button" class="doc-verify-btn" onclick="verifyDoc(this, 'gst')">Fetch</button>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Loan Details -->
          <div class="section-cyber">
            <h3 style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: #24a967;"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
              Loan Requirements
            </h3>
            
            <div class="apply-grid-3">
              <div>
                <label class="cyber-label">Required Amount (₹)</label>
                <input type="number" class="input-cyber" placeholder="e.g. 500000" required>
              </div>
              <div>
                <label class="cyber-label">Tenure (Months)</label>
                <select class="input-cyber" required>
                  <option value="12">12 Months</option>
                  <option value="24">24 Months</option>
                  <option value="36" selected>36 Months</option>
                  <option value="48">48 Months</option>
                  <option value="60">60 Months</option>
                </select>
              </div>
              <div>
                <label class="cyber-label">Loan Product</label>
                <select class="input-cyber" required>
                  <option value="MSME">MSME Business Loan</option>
                  <option value="LAP">Loan Against Property</option>
                  <option value="TWO_WHEELER">Two Wheeler</option>
                  <option value="TRACTOR">Tractor & Agri</option>
                  <option value="SOLAR">Solar Finance</option>
                </select>
              </div>
            </div>
          </div>
          
          <button type="submit" id="btnSubmitApply" class="btn-cyber-submit">
            <span>Initiate Pre-Approval</span>
            <svg id="spinnerApply" style="display: none; animation: spin 1s linear infinite;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
          </button>
          
          <div style="text-align: center; margin-top: 20px; font-size: 0.8rem; color: var(--text-muted);">
            By continuing, you authorize Namdev Finvest to fetch your credit profile via CIBIL.
          </div>
        </form>
        
      </div>
    </div>

    <script>
      function verifyDoc(btn, type) {
        let input = btn.previousElementSibling;
        if (!input.value) return;
        
        btn.innerHTML = '<svg style="animation: spin 1s linear infinite;" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>';
        
        setTimeout(() => {
          btn.classList.add('verified');
          btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg> Verified';
          
          // Auto-fill mock data based on type
          if(type === 'aadhaar') {
             let fields = document.querySelectorAll('.apply-grid-3 .input-cyber');
             fields[0].value = 'Ramesh Kumar';
             fields[1].value = '1985-10-12';
             fields[2].value = 'M';
          }
        }, 1200);
      }
      
      function submitApplication(e) {
        e.preventDefault();
        const btn = document.getElementById('btnSubmitApply');
        const spinner = document.getElementById('spinnerApply');
        
        btn.querySelector('span').style.opacity = '0.5';
        spinner.style.display = 'block';
        
        setTimeout(() => {
          alert('Application successfully routed to LOS / BRE Engine. Reference ID: NMDV-94921X');
          window.location.href = 'bre-dashboard.html';
        }, 2000);
      }
    </script>
    """
    
    timestamp = str(int(time.time()))
    header = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', header)
    
    with open('apply.html', 'w') as f:
        f.write(header + apply_body + footer)
    print("Created apply.html integrated into the ecosystem.")
