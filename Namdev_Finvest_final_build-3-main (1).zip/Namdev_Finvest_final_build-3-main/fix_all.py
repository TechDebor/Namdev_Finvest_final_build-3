import glob

# 1. Fix Layouts in the generated pages
pages_to_fix = ['about.html', 'investor.html', 'team.html', 'contact.html']

for page in pages_to_fix:
    try:
        with open(page, 'r') as f:
            content = f.read()
            
        # The issue is <section class="hero-quantum" id="...">
        # We need to wrap its immediate children in a div so flex row doesn't tear them apart.
        # Actually, let's just override .hero-quantum style for these pages inline.
        css_fix = """
    .hero-quantum { flex-direction: column; justify-content: center; text-align: center; padding-top: 180px; min-height: 60vh; }
    .hero-quantum > * { width: 100%; max-width: 800px; margin-left: auto; margin-right: auto; }
"""
        if "flex-direction: column" not in content:
            content = content.replace("</style>", css_fix + "</style>")
            
        with open(page, 'w') as f:
            f.write(content)
        print(f"Fixed layout in {page}")
    except Exception as e:
        print(f"Error fixing {page}: {e}")

# 2. Add Pay EMI button to the navigation
all_html_files = glob.glob('*.html')

pay_emi_html = """
              <li><a href="contact.html" class="nav-link">Contact</a></li>
              <li style="margin-left: 15px;"><a href="payment.html" class="btn-quantum" style="padding: 8px 16px; font-size: 0.85rem; text-decoration: none;">Pay EMI</a></li>
"""

for file in all_html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        if "Pay EMI" not in content and '<li><a href="contact.html" class="nav-link">Contact</a></li>' in content:
            content = content.replace(
                '<li><a href="contact.html" class="nav-link">Contact</a></li>', 
                pay_emi_html
            )
            with open(file, 'w') as f:
                f.write(content)
            print(f"Added Pay EMI to {file}")
    except Exception as e:
        print(f"Error adding Pay EMI to {file}: {e}")

