import re

with open('payment.html', 'r') as f:
    content = f.read()

# Replace onclick alert
content = content.replace(
    '''onclick="alert('Redirecting to secure payment gateway...')"''',
    '''id="payBtn"'''
)

# Replace the modal HTML
modal_start = content.find('<!-- MODAL -->')
modal_end = content.find('<script src="js/main.js"></script>')

new_modal = """<!-- MODAL -->
  <div id="quantumModal" class="modal-backdrop-quantum">
    <div class="modal-card-quantum" style="text-align: center; padding: 40px;">
      <button class="modal-close-btn" aria-label="Close Dialog"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
      
      <div id="paymentProcessing" style="display: none;">
        <div class="pulse-dot" style="width: 48px; height: 48px; margin: 0 auto 20px;"></div>
        <h3 class="modal-title" style="font-size: 1.5rem;">Processing Payment...</h3>
        <p class="modal-sub">Please do not close this window.</p>
      </div>

      <div id="paymentSuccess" style="display: none;">
        <div style="width: 64px; height: 64px; border-radius: 50%; background: var(--text-primary); color: var(--bg-card); display: flex; align-items: center; justify-content: center; margin: 0 auto 24px;">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>
        <h3 class="modal-title" style="font-size: 1.8rem; margin-bottom: 10px;">Payment Successful</h3>
        <p class="modal-sub" style="margin-bottom: 24px;">Your EMI has been credited successfully. A receipt has been sent to your registered email.</p>
        <div style="font-family: var(--font-mono); font-size: 0.85rem; color: var(--text-secondary); padding: 12px; background: var(--bg-surface); border-radius: var(--radius-sm); border: 1px solid var(--mono-border);">
          TXN ID: #NAM<span id="txnId"></span>
        </div>
      </div>

    </div>
  </div>

"""

if modal_start != -1 and modal_end != -1:
    content = content[:modal_start] + new_modal + content[modal_end:]

# Add script at the end
script_to_add = """
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const payBtn = document.getElementById('payBtn');
      const modal = document.getElementById('quantumModal');
      const processing = document.getElementById('paymentProcessing');
      const success = document.getElementById('paymentSuccess');
      const txnId = document.getElementById('txnId');
      
      if (payBtn && modal) {
        payBtn.addEventListener('click', (e) => {
          e.preventDefault();
          if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
          
          modal.classList.add('active');
          processing.style.display = 'block';
          success.style.display = 'none';
          
          setTimeout(() => {
            if (window.namfinSFX) window.namfinSFX.playClick(1000, 'triangle', 0.15);
            processing.style.display = 'none';
            success.style.display = 'block';
            txnId.innerText = Math.floor(100000000 + Math.random() * 900000000);
          }, 2000);
        });
      }
    });
  </script>
</body>
"""

content = content.replace('</body>', script_to_add)

with open('payment.html', 'w') as f:
    f.write(content)

