import glob

nav_erickshaw = """                  <li><a href="e-rickshaw.html" class="dropdown-link-quantum"><div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"></rect><path d="M12 11V3"></path></svg></div><div class="dropdown-info"><span class="dropdown-name">E-Rickshaw Loans</span><span class="dropdown-sub">Commercial EVs & Loaders</span></div></a></li>"""

for f in glob.glob('*.html'):
    with open(f, 'r') as file:
        content = file.read()
    
    if 'e-rickshaw.html' not in content:
        # Add after solar.html
        content = content.replace(
            '<li><a href="solar.html" class="dropdown-link-quantum">',
            nav_erickshaw + '\n                  <li><a href="solar.html" class="dropdown-link-quantum">'
        )
        
        # Add to mobile drawer
        content = content.replace(
            '<li><a href="solar.html" class="mobile-link">',
            '<li><a href="e-rickshaw.html" class="mobile-link">E-Rickshaw Loans</a></li>\n        <li><a href="solar.html" class="mobile-link">'
        )
        
        with open(f, 'w') as file:
            file.write(content)

print("Added E-Rickshaw to nav.")
