import re
import glob

# 1. Fix css/style.css so the scrolled navbar respects dark mode
try:
    with open('css/style.css', 'r') as f:
        css = f.read()
        
    if '[data-theme="dark"] .quantum-nav.scrolled' not in css:
        dark_nav_css = """
[data-theme="dark"] .quantum-nav.scrolled {
  background: rgba(9, 9, 11, 0.9) !important;
  border-bottom: 1px solid var(--mono-border) !important;
}
"""
        with open('css/style.css', 'w') as f:
            f.write(css + dark_nav_css)
        print("Fixed navbar background in dark mode.")
except Exception as e:
    print(f"CSS Fix Error: {e}")

# 2. Fix the invisible Investor tab (remove var(--brand) which might be white or undefined)
html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # Replace the hardcoded style="color: var(--brand);" with a generic highlight color or remove it
        if 'style="color: var(--brand);"' in content:
            content = content.replace('style="color: var(--brand);"', 'style="color: #ff4757;"')
            with open(file, 'w') as f:
                f.write(content)
            print(f"Fixed Investor tab color in {file}")
            
    except Exception as e:
        print(f"HTML Fix Error on {file}: {e}")

