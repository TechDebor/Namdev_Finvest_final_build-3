with open('e-rickshaw.html', 'r') as f:
    content = f.read()

content = content.replace('Two-Wheeler loans', 'E-Rickshaw loans')
content = content.replace('Two Wheeler Loans', 'E-Rickshaw Loans')
content = content.replace('Two Wheeler', 'E-Rickshaw')
content = content.replace('two wheeler', 'e-rickshaw')
content = content.replace('ICE & Smart EV Bikes', 'Commercial EVs & Loaders')
content = content.replace('Drive Your Dreams Today', 'Power Your Green Transport Business')
content = content.replace('Fast-track your commute', 'Fast-track your logistics and passenger transport business')
content = content.replace('two-wheeler', 'e-rickshaw')
content = content.replace('twPriceSlider', 'twPriceSlider') # keep IDs same so products.js works
content = content.replace('twDownPaymentSlider', 'twDownPaymentSlider')
content = content.replace('₹1,20,000', '₹1,80,000') # E-Rickshaw usually more expensive

with open('e-rickshaw.html', 'w') as f:
    f.write(content)
