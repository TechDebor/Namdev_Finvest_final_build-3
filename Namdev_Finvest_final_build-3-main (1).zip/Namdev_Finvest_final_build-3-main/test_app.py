import glob
import re
import os

html_files = glob.glob('*.html')
errors = 0

for file in html_files:
    with open(file, 'r') as f:
        content = f.read()
        
    # 1. Check for dangling inline styles on Login
    if 'style="margin-right: 20px' in content or 'style="margin-right: 15px' in content:
        print(f"ERROR: {file} has lingering margin-right inline styles!")
        errors += 1
        
    # 2. Check for missing nav-inner
    if '<div class="nav-inner">' not in content:
        print(f"ERROR: {file} is missing nav-inner container!")
        errors += 1
        
    # 3. Check for broken links (internal)
    links = re.findall(r'href="([^"]+\.html)(#[^"]+)?"', content)
    for link_tuple in links:
        target_file = link_tuple[0]
        if not os.path.exists(target_file):
            print(f"ERROR: {file} has broken link to {target_file}")
            errors += 1
            
    # 4. Ensure white-space inline is completely stripped
    if 'style="white-space: nowrap' in content:
        print(f"WARNING: {file} still has inline white-space styling. (Could be normal, but we tried to strip it)")

if errors == 0:
    print("TEST PASSED: Application is fully internally consistent.")
else:
    print(f"TEST FAILED: Found {errors} errors.")
