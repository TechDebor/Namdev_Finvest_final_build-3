import re

css_to_add = """
/* ==========================================================================
   ANTIGRAVITY GRADIENT THEME UPGRADE
   ========================================================================== */

/* 1. Global Background Gradient (Dark Mode) */
[data-theme="dark"] body {
  background: linear-gradient(180deg, #050505 0%, #0a0a0f 50%, #050505 100%);
}

/* 2. Brand Title Text Gradient */
.brand-title {
  background: linear-gradient(135deg, var(--text-primary) 0%, var(--text-muted) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

[data-theme="dark"] .brand-title {
  background: linear-gradient(135deg, #ffffff 0%, #a0aec0 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* 3. Highlighted Text Gradient (For <h1> highlights) */
.highlight {
  background: linear-gradient(135deg, #6366f1 0%, #a855f7 50%, #ec4899 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-weight: 800;
}

/* 4. Quantum Button Gradient */
.btn-quantum {
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
  color: #ffffff !important;
  border: none;
  box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.btn-quantum:hover {
  background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(99, 102, 241, 0.6);
}

/* 5. Ambient Glow Orbs (More vibrant gradient) */
.glow-orb-1 {
  background: radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%);
}
.glow-orb-2 {
  background: radial-gradient(circle, rgba(168,85,247,0.15) 0%, transparent 70%);
}
"""

try:
    with open('css/style.css', 'r') as f:
        content = f.read()
        
    if "ANTIGRAVITY GRADIENT THEME UPGRADE" not in content:
        with open('css/style.css', 'a') as f:
            f.write("\n" + css_to_add)
        print("Gradient theme successfully injected!")
except Exception as e:
    print(f"Error: {e}")

