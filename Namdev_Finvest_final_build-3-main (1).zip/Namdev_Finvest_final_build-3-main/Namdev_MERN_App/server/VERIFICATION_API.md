# Verification API integration

The browser calls the Namdev backend; it never receives the APITxT Auth Key. Set
`APITXT_AUTHKEY` in the backend `.env` file before using a provider-backed action.
Optional unified mobile OTP delivery settings are listed in `.env.example`.

## Local application endpoints

| Method | Route | Purpose |
| --- | --- | --- |
| POST | `/api/aadhaar/send-otp` | Send Aadhaar-linked OTP through the Aadhaar provider endpoint. |
| POST | `/api/aadhaar/verify-otp` | Verify the OTP and return the allowlisted KYC fields and photo only after provider confirmation. |
| POST | `/api/mobile/send-otp` | Generate a one-time code on the backend and deliver through APITxT Unified OTP. |
| POST | `/api/mobile/verify-otp` | Verify the transient code; expires after five minutes and is single-use. |
| POST | `/api/pan/advance-verify` | Perform a PAN 360 lookup. Body: `{ "pan": "ABCDE1234F", "name": "Optional Name" }`. |
| POST | `/api/udyam/verify` | Verify an Udyam number. Body: `{ "udyam": "UDYAM-RJ-30-0001853" }`. |
| POST | `/api/udyam/certificate/view` | Proxy the Udyam certificate as an inline PDF. |
| POST | `/api/udyam/certificate/download` | Proxy the Udyam certificate as a PDF attachment. |
| POST | `/api/gst/:gstin` | Verify GSTIN; body may specify `{ "action": "verify" }`. |
| POST | `/api/gst/:gstin?action=download` | Proxy the GST certificate as a PDF attachment. |

Certificate routes proxy the binary response and do not return the provider's
signed URL. JSON routes return only documented fields rather than forwarding
arbitrary provider response properties. Provider calls are not automatically
retried because they may consume wallet credits.

The backend retains successful Aadhaar verification state in memory to prevent
duplicate billable requests. The returned profile is held only briefly in memory;
browser-side KYC data is not written to local storage. Mobile OTP challenges are
held in memory for five minutes, are single-use, and allow at most five failed
verification attempts. The Unified OTP send route enforces three sends per
mobile number per minute in addition to APITxT's own limit.

Provider-backed calls may incur charges. Use only with the required customer
notice, consent, authorized provider account, and applicable compliance controls.
The surrounding loan application remains a local prototype and is not submitted
to a lender by these verification integrations.

The public `login.html` mobile-code screen uses the two `/api/mobile/*` routes:
the server generates and sends the code, and the UI accepts continuation only
after server-side verification. This verifies control of the supplied phone
number; it does not create an authenticated user session or check an account
against an authoritative user directory. The linked Namfindesk screen remains a
separate demo and must not be treated as a production-secured employee portal.
