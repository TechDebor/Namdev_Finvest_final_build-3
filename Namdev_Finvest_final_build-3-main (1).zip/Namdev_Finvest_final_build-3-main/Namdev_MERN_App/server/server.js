'use strict';

const path = require('node:path');
const { randomInt, timingSafeEqual } = require('node:crypto');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');

const AADHAAR_OTP_URL = 'https://apitxt.com/api/aadhaarSendOTP';
const AADHAAR_VERIFY_OTP_URL = 'https://apitxt.com/api/aadhaarVerifyOTP';
const UDYAM_VERIFY_URL = 'https://apitxt.com/api/udyamVerify';
const PAN_ADVANCE_VERIFY_URL = 'https://apitxt.com/api/panAdvanceVerify';
const GST_VERIFY_URL = 'https://apitxt.com/api/gst';
const SEND_OTP_URL = 'https://apitxt.com/api/sendOTP';
const PROVIDER_TIMEOUT_MS = 15000;
const MAX_CERTIFICATE_BYTES = 12 * 1024 * 1024;
const OTP_TTL_MS = 5 * 60 * 1000;
const OTP_RATE_WINDOW_MS = 60 * 1000;
const ALLOWED_ORIGINS = new Set([
    'http://localhost:8000',
    'http://127.0.0.1:8000'
]);

function sendError(res, status, code, message) {
    return res.status(status).json({ success: false, code, message });
}

function providerFailureCode(payload, status) {
    const message = [
        typeof payload?.message === 'string' ? payload.message : '',
        typeof payload?.error === 'string' ? payload.error : ''
    ].join(' ').toLowerCase();

    if (payload?.status === 301 || /(insufficient|low|no)\s+\w*\s*(credit|wallet|balance)|(credit|wallet|balance)/.test(message)) {
        return 'INSUFFICIENT_CREDITS';
    }
    if (payload?.status === 203 || /invalid.{0,24}aadhaar|aadhaar.{0,24}invalid/.test(message)) {
        return 'INVALID_AADHAAR';
    }
    if (payload?.status === 204 || /\binvalid.{0,16}otp\b|\botp.{0,16}invalid\b/.test(message)) {
        return 'INVALID_OTP';
    }
    if (payload?.status === 304 || /\b(ip|whitelist|allowlist|access denied)\b/.test(message) || status === 403) {
        return 'PROVIDER_ACCESS_RESTRICTED';
    }
    if (/\b(auth(?:key)?|credential|api.?key|unauthori[sz]ed)\b/.test(message) || status === 401) {
        return 'INVALID_CREDENTIALS';
    }
    if (status === 408 || status === 504) {
        return 'PROVIDER_TIMEOUT';
    }
    return 'PROVIDER_ERROR';
}

function safeProviderText(value, authKey, aadhaarNumber) {
    if (typeof value !== 'string') {
        return '';
    }
    let safe = value;
    for (const secret of [authKey, aadhaarNumber]) {
        if (typeof secret === 'string' && secret.length > 0) {
            const escapedSecret = secret.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            safe = safe.replace(new RegExp(escapedSecret, 'gi'), '[redacted]');
        }
    }
    return safe
        .replace(/\b(?:auth(?:key)?|api[_ -]?key|otp|token|reference[_ -]?id)\s*[:=]\s*[^\s,;]+/gi, '[redacted]')
        .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[redacted]')
        .replace(/\d(?:[\s-]*\d){3,}/g, '[redacted]')
        .replace(/[\r\n\t]+/g, ' ')
        .slice(0, 240);
}

function safeKeys(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return [];
    }
    return Object.keys(value)
        .filter(key => /^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key))
        .slice(0, 30);
}

function providerResponseShape(payload) {
    const data = payload?.data;
    return {
        topLevelKeys: safeKeys(payload),
        dataType: data === null ? 'null' : Array.isArray(data) ? 'array' : typeof data,
        dataKeys: safeKeys(data)
    };
}

function sanitizedProviderBody(payload, authKey, aadhaarNumber) {
    const providerStatus = payload?.status;
    const normalizedStatus = typeof providerStatus === 'string' ? providerStatus.trim().toLowerCase() : '';
    const safeStatus = ['success', 'error', 'failed', 'failure', 'pending'].includes(normalizedStatus)
        ? normalizedStatus
        : Number.isInteger(providerStatus) && providerStatus >= 0 && providerStatus <= 999
            ? providerStatus
        : typeof providerStatus === 'boolean'
            ? String(providerStatus)
            : 'missing_or_unsupported';
    const providerMessage = typeof payload?.message === 'string'
        ? payload.message
        : typeof payload?.error === 'string'
            ? payload.error
            : '';
    return {
        status: safeStatus,
        statusType: providerStatus === null ? 'null' : typeof providerStatus,
        message: safeProviderText(providerMessage, authKey, aadhaarNumber),
        responseShape: providerResponseShape(payload),
        hasReferenceId: typeof payload?.data?.reference_id === 'string'
    };
}

function isProviderSuccess(payload) {
    return payload?.status === 200
        && typeof payload.message === 'string'
        && payload.message.trim().toLowerCase() === 'success';
}

function safeProviderValue(value, maxLength = 500) {
    if (typeof value === 'string') {
        return value.trim().slice(0, maxLength);
    }
    if (typeof value === 'number' && Number.isFinite(value)) {
        return value;
    }
    if (typeof value === 'boolean') {
        return value;
    }
    return null;
}

function pickProviderFields(source, fields) {
    if (!source || typeof source !== 'object' || Array.isArray(source)) {
        return {};
    }
    return Object.fromEntries(fields
        .filter(field => Object.hasOwn(source, field))
        .map(field => [field, safeProviderValue(source[field])])
        .filter(([, value]) => value !== null));
}

function sanitizeAadhaarProfile(data) {
    const result = {
        verified: data?.verified === true
    };
    for (const field of ['name', 'date_of_birth', 'gender', 'care_of', 'full_address']) {
        const value = safeProviderValue(data?.[field], 300);
        if (typeof value === 'string' && value) {
            result[field] = value;
        }
    }
    const address = pickProviderFields(data?.address, ['house', 'street', 'district', 'state', 'pincode']);
    if (Object.keys(address).length) {
        result.address = address;
    }
    if (typeof data?.has_photo === 'boolean') {
        result.has_photo = data.has_photo;
    }
    if (typeof data?.photo === 'string' && data.photo.length <= 5 * 1024 * 1024
        && /^(?:data:image\/jpeg;base64,)?[A-Za-z0-9+/]+={0,2}$/.test(data.photo)) {
        result.photo = data.photo.replace(/^data:image\/jpeg;base64,/, '');
    }
    return result;
}

function sanitizePanProfile(data) {
    const result = pickProviderFields(data, [
        'status', 'message', 'reference_id', 'verification_id', 'name_provided',
        'pan', 'registered_name', 'name_pan_card', 'first_name', 'last_name',
        'type', 'gender', 'date_of_birth', 'masked_aadhaar_number', 'email',
        'mobile_number', 'aadhaar_linked'
    ]);
    const address = pickProviderFields(data?.address, [
        'full_address', 'street', 'city', 'state', 'pincode', 'country'
    ]);
    if (Object.keys(address).length) {
        result.address = address;
    }
    return result;
}

function sanitizeUdyamProfile(data) {
    const result = pickProviderFields(data, [
        'verification_id', 'reference_id', 'status', 'udyam_number',
        'enterprise_name', 'organization_type', 'major_activity', 'social_category',
        'date_of_incorporation', 'date_of_commencement', 'date_of_udyam_registration',
        'enterprise_type', 'classification_year', 'classification_date', 'dic', 'msme_di'
    ]);
    const historyFields = ['serial_number', 'classification_year', 'enterprise_type', 'classification_date'];
    if (Array.isArray(data?.classification_history)) {
        result.classification_history = data.classification_history.slice(0, 100)
            .map(item => pickProviderFields(item, historyFields));
    }
    const address = pickProviderFields(data?.split_address, [
        'flat', 'building', 'village', 'block', 'street', 'city', 'district',
        'state', 'pincode', 'mobile', 'email'
    ]);
    if (Object.keys(address).length) {
        result.split_address = address;
    }
    for (const [key, fields] of [
        ['unit_locations', ['serial_number', 'unit_name', 'city', 'district', 'state', 'pincode']],
        ['nic_codes', ['serial_number', 'nic_2_digit', 'nic_2_description', 'nic_4_digit', 'nic_5_digit', 'activity', 'date']]
    ]) {
        if (Array.isArray(data?.[key])) {
            result[key] = data[key].slice(0, 100).map(item => pickProviderFields(item, fields));
        }
    }
    return result;
}

function sanitizeGstProfile(data) {
    return pickProviderFields(data, [
        'gstin', 'verified', 'status', 'legal_name', 'trade_name', 'business_type',
        'registration_date', 'address', 'state', 'district', 'pincode'
    ]);
}

function validUdyam(value) {
    return typeof value === 'string' && /^UDYAM-[A-Z]{2}-\d{2}-\d{7}$/i.test(value.trim());
}

function validPan(value) {
    return typeof value === 'string' && /^[A-Z]{5}\d{4}[A-Z]$/i.test(value.trim());
}

function validGstin(value) {
    return typeof value === 'string' && /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/i.test(value.trim());
}

async function readCertificateBody(response) {
    if (!response.body?.getReader) {
        return Buffer.from(await response.arrayBuffer());
    }
    const reader = response.body.getReader();
    const chunks = [];
    let totalBytes = 0;
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            totalBytes += value.byteLength;
            if (totalBytes > MAX_CERTIFICATE_BYTES) {
                await reader.cancel();
                return null;
            }
            chunks.push(Buffer.from(value));
        }
    } finally {
        reader.releaseLock();
    }
    return Buffer.concat(chunks, totalBytes);
}

async function proxyCertificate({
    res, fetchImpl, timeoutMs, url, body, filename, disposition = 'attachment', logger, label
}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    let providerResponse;
    try {
        providerResponse = await fetchImpl(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: controller.signal
        });
        const contentType = providerResponse.headers?.get?.('content-type') || '';
        if (!providerResponse.ok || !contentType.toLowerCase().includes('application/pdf')) {
            let payload;
            try {
                payload = await providerResponse.json();
            } catch {
                payload = null;
            }
            const code = payload?.status === 205 && label === 'GST'
                ? 'GST_INACTIVE'
                : payload ? providerFailureCode(payload, providerResponse.status) : 'PROVIDER_ERROR';
            logger.warn(`[APITxT ${label} certificate rejected]`, {
                httpStatus: providerResponse.status,
                classification: code,
                responseShape: providerResponseShape(payload)
            });
            const status = code === 'INSUFFICIENT_CREDITS' ? 402 : code === 'GST_INACTIVE' ? 409 : 502;
            const message = code === 'GST_INACTIVE'
                ? 'The GST registration is inactive; a certificate is unavailable.'
                : `APITxT could not provide the ${label} certificate.`;
            return sendError(res, status, code, message);
        }
        const declaredLength = Number(providerResponse.headers?.get?.('content-length'));
        if (Number.isFinite(declaredLength) && declaredLength > MAX_CERTIFICATE_BYTES) {
            return sendError(res, 502, 'CERTIFICATE_TOO_LARGE', 'The certificate response exceeded the allowed size.');
        }
        const pdf = await readCertificateBody(providerResponse);
        if (!pdf) {
            return sendError(res, 502, 'CERTIFICATE_TOO_LARGE', 'The certificate response exceeded the allowed size.');
        }
        if (pdf.length > MAX_CERTIFICATE_BYTES || pdf.length < 5 || pdf.subarray(0, 5).toString('ascii') !== '%PDF-') {
            logger.warn(`[APITxT ${label} certificate invalid binary response]`, {
                httpStatus: providerResponse.status,
                byteLength: pdf.length
            });
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid certificate response.');
        }
        res.set({
            'Content-Type': 'application/pdf',
            'Content-Disposition': `${disposition}; filename="${filename}"`,
            'Content-Length': String(pdf.length),
            'X-Content-Type-Options': 'nosniff',
            'Cache-Control': 'no-store'
        });
        return res.status(200).send(pdf);
    } catch (error) {
        const timedOut = controller.signal.aborted || error.name === 'AbortError';
        logger.warn(`[APITxT ${label} certificate transport failure]`, {
            category: timedOut ? 'timeout' : 'network_error'
        });
        return sendError(res, timedOut ? 504 : 502, timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
            timedOut ? `APITxT timed out while fetching the ${label} certificate.` : `Could not reach APITxT for the ${label} certificate.`);
    } finally {
        clearTimeout(timeout);
    }
}

function isValidReferenceId(value) {
    return typeof value === 'string' && value.trim().length > 0 && value.length <= 200;
}

function safeMaskedAadhaar(value) {
    if (typeof value !== 'string' || value.length > 40 || !/^[\dXx* -]+$/.test(value)) {
        return null;
    }
    return value.replace(/\D/g, '').length <= 4 ? value.trim() : null;
}

function createApp({
    authKey = process.env.APITXT_AUTHKEY,
    otpChannel = process.env.APITXT_OTP_CHANNEL || 'sms',
    otpTemplateId = process.env.APITXT_OTP_TEMPLATE_ID,
    otpTemplateName = process.env.APITXT_OTP_TEMPLATE_NAME,
    otpProjectRefId = process.env.APITXT_OTP_PROJECT_REF_ID,
    fetchImpl = globalThis.fetch,
    timeoutMs = PROVIDER_TIMEOUT_MS,
    logger = console
} = {}) {
    const app = express();
    app.use(cors({
        origin(origin, callback) {
            callback(null, !origin || ALLOWED_ORIGINS.has(origin));
        }
    }));
    app.use(express.json({ limit: '16kb' }));

    let applications = [];
    let tasks = [];
    const verificationTransactions = new Map();
    const mobileOtpChallenges = new Map();
    const mobileOtpRateLimits = new Map();

    app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

    app.post('/api/aadhaar/send-otp', async (req, res) => {
        const aadhaarNumber = req.body?.aadhaar_number;
        if (typeof aadhaarNumber !== 'string' || !/^\d{12}$/.test(aadhaarNumber)) {
            return sendError(res, 400, 'INVALID_AADHAAR', 'Enter a valid 12-digit Aadhaar number.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'Aadhaar OTP service is not configured.');
        }

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        let providerResponse;
        let providerPayload;
        let malformedJson = false;

        try {
            providerResponse = await fetchImpl(AADHAAR_OTP_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    authkey: authKey,
                    aadhaar_number: aadhaarNumber
                }),
                signal: controller.signal
            });
            try {
                providerPayload = await providerResponse.json();
            } catch (error) {
                if (controller.signal.aborted || error.name === 'AbortError') {
                    throw error;
                }
                malformedJson = true;
            }
        } catch (error) {
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            logger.warn('[APITxT Aadhaar send-OTP transport failure]', {
                category: timedOut ? 'timeout' : 'network_error'
            });
            return sendError(
                res,
                timedOut ? 504 : 502,
                timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
                timedOut
                    ? 'APITxT timed out. The request may have been accepted; check with the provider before retrying.'
                    : 'Could not reach APITxT.'
            );
        } finally {
            clearTimeout(timeout);
        }

        if (malformedJson || !providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            logger.warn('[APITxT Aadhaar send-OTP malformed response]', {
                httpStatus: providerResponse.status,
                body: {
                    status: 'missing_or_unsupported',
                    statusType: 'undefined',
                    message: '',
                    responseShape: { topLevelKeys: [], dataType: 'undefined', dataKeys: [] },
                    hasReferenceId: false
                }
            });
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid response.');
        }
        if (!providerResponse.ok) {
            const classifiedCode = providerFailureCode(providerPayload, providerResponse.status);
            const code = classifiedCode === 'PROVIDER_ERROR' ? 'PROVIDER_HTTP_ERROR' : classifiedCode;
            logger.warn('[APITxT Aadhaar send-OTP HTTP rejection]', {
                httpStatus: providerResponse.status,
                classification: code,
                body: sanitizedProviderBody(providerPayload, authKey, aadhaarNumber)
            });
            const messages = {
                INVALID_AADHAAR: 'APITxT rejected the Aadhaar number.',
                INSUFFICIENT_CREDITS: 'APITxT reports insufficient credits.',
                INVALID_CREDENTIALS: 'APITxT rejected the configured credentials.',
                PROVIDER_ACCESS_RESTRICTED: 'APITxT denied access. Check the Auth Key and allowed IP settings.',
                PROVIDER_TIMEOUT: 'APITxT timed out. The request may have been accepted; check with the provider before retrying.',
                PROVIDER_HTTP_ERROR: `APITxT returned an HTTP error (status ${providerResponse.status}).`
            };
            const status = code === 'INVALID_AADHAAR' ? 400 : code === 'PROVIDER_TIMEOUT' ? 504 : 502;
            return sendError(res, status, code, messages[code] || 'APITxT could not accept the request.');
        }

        if (!Number.isInteger(providerPayload.status)
            || typeof providerPayload.message !== 'string'
            || !providerPayload.message.trim()) {
            logger.warn('[APITxT Aadhaar send-OTP malformed response]', {
                httpStatus: providerResponse.status,
                body: sanitizedProviderBody(providerPayload, authKey, aadhaarNumber)
            });
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid response.');
        }

        if (!isProviderSuccess(providerPayload)) {
            const code = providerFailureCode(providerPayload, providerResponse.status);
            logger.warn('[APITxT Aadhaar send-OTP provider rejection]', {
                httpStatus: providerResponse.status,
                classification: code,
                body: sanitizedProviderBody(providerPayload, authKey, aadhaarNumber)
            });
            const messages = {
                INVALID_AADHAAR: 'APITxT rejected the Aadhaar number.',
                INSUFFICIENT_CREDITS: 'APITxT reports insufficient credits.',
                INVALID_CREDENTIALS: 'APITxT rejected the configured credentials.',
                PROVIDER_ACCESS_RESTRICTED: 'APITxT denied access. Check the Auth Key and allowed IP settings.',
                PROVIDER_TIMEOUT: 'APITxT timed out. The request may have been accepted; check with the provider before retrying.',
                PROVIDER_ERROR: 'APITxT did not confirm that the OTP request was accepted. Check the provider response before trying again.'
            };
            const status = code === 'INVALID_AADHAAR' ? 400 : code === 'PROVIDER_TIMEOUT' ? 504 : 502;
            return sendError(res, status, code, messages[code] || 'APITxT returned an invalid response.');
        }

        const referenceId = providerPayload.data?.reference_id;
        if (!isValidReferenceId(referenceId) || referenceId.includes(aadhaarNumber)) {
            logger.warn('[APITxT Aadhaar send-OTP missing or unsafe reference]', {
                httpStatus: providerResponse.status,
                body: sanitizedProviderBody(providerPayload, authKey, aadhaarNumber)
            });
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid response.');
        }

        const result = {
            success: true,
            reference_id: referenceId.trim()
        };
        const maskedAadhaar = safeMaskedAadhaar(providerPayload.data?.masked_aadhaar);
        if (maskedAadhaar) {
            result.masked_aadhaar = maskedAadhaar;
        }
        return res.json(result);
    });

    app.post('/api/aadhaar/verify-otp', async (req, res) => {
        const referenceId = req.body?.reference_id;
        const otp = typeof req.body?.otp === 'string' ? req.body.otp.trim() : req.body?.otp;
        if (!isValidReferenceId(referenceId)) {
            return sendError(res, 400, 'INVALID_REFERENCE_ID', 'The OTP request reference is missing or invalid. Request a new OTP.');
        }
        if (typeof otp !== 'string' || !/^\d{6}$/.test(otp)) {
            return sendError(res, 400, 'INVALID_OTP', 'Enter the 6-digit OTP sent to your Aadhaar-linked mobile.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'Aadhaar OTP service is not configured.');
        }

        const normalizedReferenceId = referenceId.trim();
        const now = Date.now();
        for (const [storedReferenceId, transaction] of verificationTransactions) {
            if (transaction.state === 'verified' && now - transaction.updatedAt > 24 * 60 * 60 * 1000) {
                verificationTransactions.delete(storedReferenceId);
            } else if (transaction.profileExpiresAt && now > transaction.profileExpiresAt) {
                transaction.profile = undefined;
                transaction.profileExpiresAt = undefined;
            }
        }
        const existingTransaction = verificationTransactions.get(normalizedReferenceId);
        if (existingTransaction?.state === 'verified') {
            return res.json({ success: true, ...(existingTransaction.profile || { verified: true }) });
        }
        if (existingTransaction?.state === 'unknown') {
            return res.status(409).json({
                success: false,
                code: 'VERIFICATION_UNKNOWN',
                outcome: 'unknown',
                message: 'A verification request for this reference already has an unknown outcome. Do not resubmit it until APITxT confirms the transaction outcome.'
            });
        }
        if (existingTransaction?.state === 'pending') {
            return res.status(409).json({
                success: false,
                code: 'VERIFICATION_IN_PROGRESS',
                message: 'A verification request for this reference is already in progress.'
            });
        }
        verificationTransactions.set(normalizedReferenceId, { state: 'pending', updatedAt: now });

        const markVerificationUnknown = () => {
            verificationTransactions.set(normalizedReferenceId, { state: 'unknown', updatedAt: Date.now() });
        };

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        const startedAt = Date.now();
        let requestPhase = 'waiting_for_headers';
        let providerResponse;
        let providerPayload;
        let malformedJson = false;
        try {
            providerResponse = await fetchImpl(AADHAAR_VERIFY_OTP_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    authkey: authKey,
                    reference_id: referenceId.trim(),
                    otp
                }),
                signal: controller.signal
            });
            requestPhase = 'reading_response_body';
            try {
                providerPayload = await providerResponse.json();
            } catch (error) {
                if (controller.signal.aborted || error.name === 'AbortError') {
                    throw error;
                }
                malformedJson = true;
            }
        } catch (error) {
            markVerificationUnknown();
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            const elapsedMs = Date.now() - startedAt;
            const message = timedOut
                ? 'APITxT did not return a definitive verification result before the timeout. Aadhaar is not verified; do not resubmit this OTP until the provider confirms the transaction outcome.'
                : 'The verification connection ended without a definitive result. Aadhaar is not verified; do not resubmit this OTP until the provider confirms the transaction outcome.';
            logger.warn('[APITxT Aadhaar verify-OTP outcome unknown]', {
                operation: 'verify-otp',
                outcome: 'unknown',
                category: timedOut ? 'timeout' : 'network_error',
                phase: requestPhase,
                elapsedMs,
                timeoutMs,
                httpStatus: Number.isInteger(providerResponse?.status) ? providerResponse.status : null,
                providerStatus: null,
                providerStatusType: 'unavailable',
                contentType: providerResponse?.headers?.get?.('content-type')?.slice(0, 80) || null,
                responseShape: null
            });
            return res.status(timedOut ? 504 : 502).json({
                success: false,
                code: 'VERIFICATION_UNKNOWN',
                outcome: 'unknown',
                message
            });
        } finally {
            clearTimeout(timeout);
        }

        if (malformedJson || !providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            markVerificationUnknown();
            const elapsedMs = Date.now() - startedAt;
            logger.warn('[APITxT Aadhaar verify-OTP malformed response]', {
                operation: 'verify-otp',
                outcome: 'unknown',
                phase: 'reading_response_body',
                elapsedMs,
                timeoutMs,
                httpStatus: providerResponse.status,
                contentType: providerResponse.headers?.get?.('content-type')?.slice(0, 80) || null,
                parseFailure: malformedJson ? 'invalid_json' : 'invalid_body',
                body: {
                    status: 'missing_or_unsupported',
                    statusType: 'undefined',
                    message: '',
                    responseShape: { topLevelKeys: [], dataType: 'undefined', dataKeys: [] },
                    hasVerified: false
                }
            });
            return res.status(502).json({
                success: false,
                code: 'VERIFICATION_UNKNOWN',
                outcome: 'unknown',
                message: 'APITxT returned no readable verification result. Aadhaar is not verified; do not resubmit this OTP until the provider confirms the transaction outcome.'
            });
        }

        const providerContractReadable = Number.isInteger(providerPayload.status)
            && typeof providerPayload.message === 'string'
            && providerPayload.message.trim().length > 0;
        const providerExplicitlyRejected = providerPayload.data?.verified === false
            || (providerContractReadable && !isProviderSuccess(providerPayload));
        if ((!providerContractReadable || (isProviderSuccess(providerPayload) && typeof providerPayload.data?.verified !== 'boolean'))
            && !providerExplicitlyRejected) {
            markVerificationUnknown();
            const elapsedMs = Date.now() - startedAt;
            logger.warn('[APITxT Aadhaar verify-OTP malformed response]', {
                operation: 'verify-otp',
                outcome: 'unknown',
                phase: 'parsing_response',
                elapsedMs,
                timeoutMs,
                httpStatus: providerResponse.status,
                body: {
                    ...sanitizedProviderBody(providerPayload, authKey, ''),
                    hasVerified: typeof providerPayload.data?.verified === 'boolean'
                }
            });
            return res.status(502).json({
                success: false,
                code: 'VERIFICATION_UNKNOWN',
                outcome: 'unknown',
                message: 'APITxT returned an incomplete verification result. Aadhaar is not verified; do not resubmit this OTP until the provider confirms the transaction outcome.'
            });
        }

        if (!providerResponse.ok || !isProviderSuccess(providerPayload) || providerPayload.data?.verified !== true) {
            const code = providerPayload.data?.verified === false
                ? providerFailureCode(providerPayload, providerResponse.status)
                : isProviderSuccess(providerPayload)
                    ? 'INVALID_PROVIDER_RESPONSE'
                    : providerFailureCode(providerPayload, providerResponse.status);
            if (providerResponse.status >= 500 || code === 'PROVIDER_TIMEOUT') {
                markVerificationUnknown();
                const elapsedMs = Date.now() - startedAt;
                logger.warn('[APITxT Aadhaar verify-OTP outcome unknown]', {
                    operation: 'verify-otp',
                    outcome: 'unknown',
                    category: code === 'PROVIDER_TIMEOUT' ? 'provider_timeout' : 'provider_http_error',
                    phase: 'provider_response',
                    elapsedMs,
                    timeoutMs,
                    httpStatus: providerResponse.status,
                    classification: code,
                    body: sanitizedProviderBody(providerPayload, authKey, '')
                });
                return res.status(code === 'PROVIDER_TIMEOUT' ? 504 : 502).json({
                    success: false,
                    code: 'VERIFICATION_UNKNOWN',
                    outcome: 'unknown',
                    message: 'APITxT did not return a definitive verification result. Aadhaar is not verified; do not resubmit this OTP until the provider confirms the transaction outcome.'
                });
            }
            logger.warn('[APITxT Aadhaar verify-OTP rejected]', {
                httpStatus: providerResponse.status,
                classification: code,
                elapsedMs: Date.now() - startedAt,
                body: {
                    ...sanitizedProviderBody(providerPayload, authKey, ''),
                    hasVerified: typeof providerPayload.data?.verified === 'boolean'
                }
            });
            const providerMessage = safeProviderText(
                typeof providerPayload.message === 'string' ? providerPayload.message : providerPayload.error,
                authKey,
                ''
            );
            const messages = {
                INVALID_OTP: 'APITxT did not accept that OTP. Check the code and try again before it expires.',
                INSUFFICIENT_CREDITS: 'APITxT reports insufficient credits. Please check the provider wallet.',
                INVALID_CREDENTIALS: 'APITxT rejected the configured credentials.',
                PROVIDER_ACCESS_RESTRICTED: 'APITxT denied access. Check the Auth Key and allowed IP settings.',
                PROVIDER_TIMEOUT: 'APITxT timed out while verifying the OTP. Do not request another OTP automatically.',
                PROVIDER_ERROR: 'APITxT did not confirm Aadhaar verification.',
                INVALID_PROVIDER_RESPONSE: 'APITxT returned an incomplete verification response.'
            };
            const userMessage = providerPayload.status === 310
                ? 'APITxT returned status 310, documented as a vendor error or wrong OTP. This does not establish that the entered OTP was incorrect; confirm the transaction with APITxT before retrying.'
                : messages[code] || 'APITxT could not verify the OTP.';
            const status = code === 'INVALID_OTP' ? 400 : code === 'PROVIDER_TIMEOUT' ? 504 : 502;
            verificationTransactions.delete(normalizedReferenceId);
            return res.status(status).json({
                success: false,
                code,
                message: userMessage,
                ...(providerMessage ? { provider_message: providerMessage } : {})
            });
        }

        const profile = sanitizeAadhaarProfile(providerPayload.data);
        const transaction = {
            state: 'verified',
            updatedAt: Date.now(),
            profile,
            profileExpiresAt: Date.now() + 5 * 60 * 1000
        };
        verificationTransactions.set(normalizedReferenceId, transaction);
        const profileExpiry = setTimeout(() => {
            if (verificationTransactions.get(normalizedReferenceId) === transaction) {
                transaction.profile = undefined;
                transaction.profileExpiresAt = undefined;
            }
        }, 5 * 60 * 1000);
        profileExpiry.unref?.();
        return res.json({ success: true, ...profile });
    });

    app.post('/api/pan/advance-verify', async (req, res) => {
        const pan = typeof req.body?.pan === 'string' ? req.body.pan.trim().toUpperCase() : '';
        const name = typeof req.body?.name === 'string' ? req.body.name.trim().slice(0, 100) : '';
        if (!validPan(pan)) {
            return sendError(res, 400, 'INVALID_PAN', 'Enter PAN in the format ABCDE1234F.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'PAN verification is not configured.');
        }
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        let providerResponse;
        let providerPayload;
        try {
            providerResponse = await fetchImpl(PAN_ADVANCE_VERIFY_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ authkey: authKey, pan, ...(name ? { name } : {}) }),
                signal: controller.signal
            });
            providerPayload = await providerResponse.json();
        } catch (error) {
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            logger.warn('[APITxT PAN advance transport failure]', { category: timedOut ? 'timeout' : 'network_error' });
            return sendError(res, timedOut ? 504 : 502, timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
                timedOut ? 'APITxT timed out during PAN verification.' : 'Could not reach APITxT for PAN verification.');
        } finally {
            clearTimeout(timeout);
        }
        if (!providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid PAN response.');
        }
        const validResponse = providerResponse.ok && isProviderSuccess(providerPayload)
            && providerPayload.data && typeof providerPayload.data === 'object'
            && typeof providerPayload.data.status === 'string';
        if (!validResponse) {
            const code = providerPayload.status === 206 ? 'INVALID_PAN' : providerFailureCode(providerPayload, providerResponse.status);
            logger.warn('[APITxT PAN advance rejected]', {
                httpStatus: providerResponse.status,
                classification: code,
                body: sanitizedProviderBody(providerPayload, authKey, pan)
            });
            return sendError(res, code === 'INVALID_PAN' ? 400 : code === 'INSUFFICIENT_CREDITS' ? 402 : 502,
                code, code === 'INVALID_PAN' ? 'APITxT rejected the PAN number.' : 'APITxT could not complete PAN verification.');
        }
        return res.json({ success: true, data: sanitizePanProfile(providerPayload.data) });
    });

    app.post('/api/udyam/verify', async (req, res) => {
        const udyam = typeof req.body?.udyam === 'string' ? req.body.udyam.trim().toUpperCase() : '';
        if (!validUdyam(udyam)) {
            return sendError(res, 400, 'INVALID_UDYAM', 'Enter Udyam number in the format UDYAM-RJ-30-0001853.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'Udyam verification is not configured.');
        }
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        let providerResponse;
        let providerPayload;
        try {
            providerResponse = await fetchImpl(UDYAM_VERIFY_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ authkey: authKey, udyam, action: 'verify' }),
                signal: controller.signal
            });
            providerPayload = await providerResponse.json();
        } catch (error) {
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            logger.warn('[APITxT Udyam verify transport failure]', { category: timedOut ? 'timeout' : 'network_error' });
            return sendError(res, timedOut ? 504 : 502, timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
                timedOut ? 'APITxT timed out during Udyam verification.' : 'Could not reach APITxT for Udyam verification.');
        } finally {
            clearTimeout(timeout);
        }
        if (!providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid Udyam response.');
        }
        if (!providerResponse.ok || !isProviderSuccess(providerPayload)
            || !providerPayload.data || typeof providerPayload.data !== 'object') {
            const code = providerPayload.status === 220 ? 'INVALID_UDYAM' : providerFailureCode(providerPayload, providerResponse.status);
            logger.warn('[APITxT Udyam verify rejected]', {
                httpStatus: providerResponse.status,
                classification: code,
                body: sanitizedProviderBody(providerPayload, authKey, udyam)
            });
            return sendError(res, code === 'INVALID_UDYAM' ? 400 : code === 'INSUFFICIENT_CREDITS' ? 402 : 502,
                code, code === 'INVALID_UDYAM' ? 'APITxT rejected the Udyam registration number.' : 'APITxT could not complete Udyam verification.');
        }
        return res.json({ success: true, data: sanitizeUdyamProfile(providerPayload.data) });
    });

    app.post('/api/gst/:gstin', async (req, res) => {
        const gstin = typeof req.params.gstin === 'string' ? req.params.gstin.trim().toUpperCase() : '';
        const action = req.body?.action || req.query.action || 'verify';
        if (!validGstin(gstin)) {
            return sendError(res, 400, 'INVALID_GSTIN', 'Enter a valid 15-character GSTIN.');
        }
        if (!['verify', 'download'].includes(action)) {
            return sendError(res, 400, 'INVALID_ACTION', 'GST action must be verify or download.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'GST verification is not configured.');
        }
        if (action === 'download') {
            return proxyCertificate({
                res, fetchImpl, timeoutMs, url: `${GST_VERIFY_URL}/${encodeURIComponent(gstin)}`,
                body: { authkey: authKey, action: 'download' },
                filename: `GST_Certificate_${gstin}.pdf`, logger, label: 'GST'
            });
        }
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        let providerResponse;
        let providerPayload;
        try {
            providerResponse = await fetchImpl(`${GST_VERIFY_URL}/${encodeURIComponent(gstin)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ authkey: authKey, action: 'verify' }),
                signal: controller.signal
            });
            providerPayload = await providerResponse.json();
        } catch (error) {
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            logger.warn('[APITxT GST verify transport failure]', { category: timedOut ? 'timeout' : 'network_error' });
            return sendError(res, timedOut ? 504 : 502, timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
                timedOut ? 'APITxT timed out during GST verification.' : 'Could not reach APITxT for GST verification.');
        } finally {
            clearTimeout(timeout);
        }
        if (!providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid GST response.');
        }
        if (!providerResponse.ok || !isProviderSuccess(providerPayload)
            || !providerPayload.data || typeof providerPayload.data !== 'object') {
            const code = providerPayload.status === 202 ? 'INVALID_GSTIN'
                : providerPayload.status === 205 ? 'GST_INACTIVE'
                    : providerFailureCode(providerPayload, providerResponse.status);
            logger.warn('[APITxT GST verify rejected]', {
                httpStatus: providerResponse.status,
                classification: code,
                body: sanitizedProviderBody(providerPayload, authKey, gstin)
            });
            const status = code === 'INVALID_GSTIN' ? 400 : code === 'GST_INACTIVE' ? 409 : code === 'INSUFFICIENT_CREDITS' ? 402 : 502;
            const message = code === 'INVALID_GSTIN' ? 'APITxT rejected the GSTIN.'
                : code === 'GST_INACTIVE' ? 'The GST registration is inactive; a certificate is unavailable.'
                    : 'APITxT could not complete GST verification.';
            return sendError(res, status, code, message);
        }
        return res.json({ success: true, data: sanitizeGstProfile(providerPayload.data) });
    });

    app.post('/api/udyam/certificate/:action', async (req, res) => {
        const udyam = typeof req.body?.udyam === 'string' ? req.body.udyam.trim().toUpperCase() : '';
        const { action } = req.params;
        if (!validUdyam(udyam)) {
            return sendError(res, 400, 'INVALID_UDYAM', 'Enter Udyam number in the format UDYAM-RJ-30-0001853.');
        }
        if (!['view', 'download'].includes(action)) {
            return sendError(res, 400, 'INVALID_ACTION', 'Udyam certificate action must be view or download.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'Udyam certificate service is not configured.');
        }
        return proxyCertificate({
            res, fetchImpl, timeoutMs, url: UDYAM_VERIFY_URL,
            body: { authkey: authKey, udyam, action },
            filename: `Udyam_Certificate_${udyam}.pdf`, disposition: action === 'view' ? 'inline' : 'attachment',
            logger, label: 'Udyam'
        });
    });

    app.post('/api/mobile/send-otp', async (req, res) => {
        const mobileValue = typeof req.body?.mobile === 'string' ? req.body.mobile.replace(/\D/g, '') : '';
        if (!/^[6-9]\d{9}$/.test(mobileValue)) {
            return sendError(res, 400, 'INVALID_MOBILE', 'Enter a valid 10-digit Indian mobile number.');
        }
        if (typeof authKey !== 'string' || !authKey.trim()) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'Mobile OTP service is not configured.');
        }
        const now = Date.now();
        for (const [number, timestamps] of mobileOtpRateLimits) {
            const active = timestamps.filter(time => now - time < OTP_RATE_WINDOW_MS);
            if (active.length) mobileOtpRateLimits.set(number, active);
            else mobileOtpRateLimits.delete(number);
        }
        const recent = (mobileOtpRateLimits.get(mobileValue) || []).filter(time => now - time < OTP_RATE_WINDOW_MS);
        if (recent.length >= 3) {
            return sendError(res, 429, 'OTP_RATE_LIMITED', 'The limit of 3 OTP requests per mobile number per minute has been reached.');
        }
        const otp = String(randomInt(100000, 1000000));
        const form = new URLSearchParams({
            authkey: authKey,
            mobile: `91${mobileValue}`,
            otp,
            channel: otpChannel,
            country: '91'
        });
        if (!['sms', 'whatsapp', 'voice'].includes(otpChannel)) {
            return sendError(res, 503, 'SERVICE_NOT_CONFIGURED', 'The configured mobile OTP delivery channel is invalid.');
        }
        if (otpChannel === 'sms' && otpTemplateId) form.set('template_id', otpTemplateId);
        if (otpChannel === 'whatsapp' && otpTemplateName) form.set('template_name', otpTemplateName);
        if (otpChannel === 'whatsapp' && otpProjectRefId) form.set('project_ref_id', otpProjectRefId);
        mobileOtpRateLimits.set(mobileValue, [...recent, now]);
        for (const [number, challenge] of mobileOtpChallenges) {
            if (now > challenge.expiresAt) mobileOtpChallenges.delete(number);
        }
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), timeoutMs);
        let providerResponse;
        let providerPayload;
        try {
            providerResponse = await fetchImpl(SEND_OTP_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: form.toString(),
                signal: controller.signal
            });
            providerPayload = await providerResponse.json();
        } catch (error) {
            const timedOut = controller.signal.aborted || error.name === 'AbortError';
            logger.warn('[APITxT unified OTP transport failure]', { category: timedOut ? 'timeout' : 'network_error' });
            return sendError(res, timedOut ? 504 : 502, timedOut ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE',
                timedOut ? 'APITxT timed out while sending the OTP.' : 'Could not reach APITxT to send the OTP.');
        } finally {
            clearTimeout(timeout);
        }
        if (!providerPayload || typeof providerPayload !== 'object' || Array.isArray(providerPayload)) {
            return sendError(res, 502, 'INVALID_PROVIDER_RESPONSE', 'APITxT returned an invalid OTP response.');
        }
        if (!providerResponse.ok || providerPayload.status !== 'success') {
            const code = providerFailureCode(providerPayload, providerResponse.status);
            logger.warn('[APITxT unified OTP rejected]', {
                httpStatus: providerResponse.status,
                classification: code,
                responseShape: providerResponseShape(providerPayload)
            });
            return sendError(res, code === 'INSUFFICIENT_CREDITS' ? 402 : 502, code, 'APITxT did not confirm OTP delivery.');
        }
        mobileOtpChallenges.set(mobileValue, { otp, expiresAt: now + OTP_TTL_MS, attempts: 0 });
        const requestId = safeProviderValue(providerPayload.data?.request_id, 100);
        return res.json({ success: true, ...(requestId ? { request_id: requestId } : {}) });
    });

    app.post('/api/mobile/verify-otp', (req, res) => {
        const mobileValue = typeof req.body?.mobile === 'string' ? req.body.mobile.replace(/\D/g, '') : '';
        const otp = typeof req.body?.otp === 'string' ? req.body.otp.trim() : '';
        if (!/^[6-9]\d{9}$/.test(mobileValue)) {
            return sendError(res, 400, 'INVALID_MOBILE', 'Enter a valid 10-digit Indian mobile number.');
        }
        if (!/^\d{6}$/.test(otp)) {
            return sendError(res, 400, 'INVALID_OTP', 'Enter the 6-digit OTP sent to your mobile.');
        }
        const challenge = mobileOtpChallenges.get(mobileValue);
        if (!challenge || Date.now() > challenge.expiresAt) {
            mobileOtpChallenges.delete(mobileValue);
            return sendError(res, 400, 'OTP_EXPIRED', 'The mobile OTP is missing or expired. Request a new OTP.');
        }
        const expected = Buffer.from(challenge.otp);
        const received = Buffer.from(otp);
        if (expected.length !== received.length || !timingSafeEqual(expected, received)) {
            challenge.attempts += 1;
            if (challenge.attempts >= 5) {
                mobileOtpChallenges.delete(mobileValue);
                return sendError(res, 429, 'OTP_ATTEMPTS_EXCEEDED', 'Too many incorrect OTP attempts. Request a new OTP.');
            }
            return sendError(res, 400, 'INVALID_OTP', 'The mobile OTP is incorrect.');
        }
        mobileOtpChallenges.delete(mobileValue);
        return res.json({ success: true, verified: true });
    });

    app.post('/api/applications', (req, res) => {
        const application = { id: 'APP-' + Date.now(), ...req.body, status: 'Processing' };
        applications.push(application);
        res.json(application);
    });

    app.get('/api/tasks', (req, res) => res.json(tasks));

    return app;
}

if (require.main === module) {
    const app = createApp();
    const port = Number(process.env.PORT || 5000);
    const server = app.listen(port, '127.0.0.1', () => {
        console.log(`Backend running on 127.0.0.1:${port}`);
    });
    server.on('error', error => {
        if (error.code === 'EADDRINUSE') {
            console.error(`Backend cannot start: 127.0.0.1:${port} is already in use. Stop the existing server with Ctrl+C before running npm start.`);
            process.exitCode = 1;
            return;
        }
        throw error;
    });
}

module.exports = { createApp };
