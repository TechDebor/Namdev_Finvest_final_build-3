'use strict';

const assert = require('node:assert/strict');
const { once } = require('node:events');
const test = require('node:test');
const { createApp } = require('../server');

const TEST_AADHAAR = '123456789012';
const TEST_AUTH_KEY = 'test-auth-key';
const TEST_REFERENCE_ID = 'reference-123';
const TEST_OTP = '246810';

function providerResponse(payload, status = 200) {
    return {
        ok: status >= 200 && status < 300,
        status,
        json: async () => payload
    };
}

async function withServer(options, callback) {
    const server = createApp(options).listen(0, '127.0.0.1');
    await once(server, 'listening');
    const address = server.address();
    try {
        await callback(`http://127.0.0.1:${address.port}`);
    } finally {
        await new Promise((resolve, reject) => {
            server.close(error => error ? reject(error) : resolve());
        });
    }
}

async function postOtp(baseUrl, aadhaarNumber = TEST_AADHAAR) {
    return fetch(`${baseUrl}/api/aadhaar/send-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aadhaar_number: aadhaarNumber })
    });
}

async function postVerifyOtp(baseUrl, referenceId = TEST_REFERENCE_ID, otp = TEST_OTP) {
    return fetch(`${baseUrl}/api/aadhaar/verify-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reference_id: referenceId, otp })
    });
}

test('sends the documented request and returns only safe success fields', async () => {
    let request;
    await withServer({
        authKey: TEST_AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, ...options, body: JSON.parse(options.body) };
            return providerResponse({
                status: 200,
                message: 'success',
                request_id: 'provider-request-id',
                data: { reference_id: TEST_REFERENCE_ID, masked_aadhaar: 'XXXX-XXXX-9012' }
            });
        }
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 200);
        const body = await response.json();
        assert.deepEqual(body, {
            success: true,
            reference_id: TEST_REFERENCE_ID,
            masked_aadhaar: 'XXXX-XXXX-9012'
        });
        assert.equal(JSON.stringify(body).includes(TEST_AUTH_KEY), false);
    });

    assert.equal(request.url, 'https://apitxt.com/api/aadhaarSendOTP');
    assert.equal(request.method, 'POST');
    assert.deepEqual(request.body, {
        authkey: TEST_AUTH_KEY,
        aadhaar_number: TEST_AADHAAR
    });
    assert.ok(request.signal instanceof AbortSignal);
});

test('rejects invalid Aadhaar before contacting the provider', async () => {
    let providerCalls = 0;
    await withServer({
        authKey: TEST_AUTH_KEY,
        fetchImpl: async () => {
            providerCalls += 1;
            return providerResponse({});
        }
    }, async baseUrl => {
        const response = await postOtp(baseUrl, '12345');
        assert.equal(response.status, 400);
        assert.equal((await response.json()).code, 'INVALID_AADHAAR');
    });
    assert.equal(providerCalls, 0);
});

test('does not contact the provider when the backend Auth Key is missing', async () => {
    let providerCalls = 0;
    await withServer({
        authKey: '',
        fetchImpl: async () => {
            providerCalls += 1;
            return providerResponse({});
        }
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 503);
        assert.equal((await response.json()).code, 'SERVICE_NOT_CONFIGURED');
    });
    assert.equal(providerCalls, 0);
});

test('rejects HTTP 200 responses without success status or reference ID', async t => {
    const cases = [
        ['provider-declared failure', { status: 200, message: 'Failed to send Aadhaar OTP. Please try again later.' }, 'PROVIDER_ERROR'],
        ['missing provider status', { message: 'success', data: { reference_id: TEST_REFERENCE_ID } }, 'INVALID_PROVIDER_RESPONSE'],
        ['missing reference ID', { status: 200, message: 'success', data: { masked_aadhaar: 'XXXX-XXXX-9012' } }, 'INVALID_PROVIDER_RESPONSE'],
        ['unsafe reference ID', { status: 200, message: 'success', data: { reference_id: TEST_AADHAAR } }, 'INVALID_PROVIDER_RESPONSE']
    ];
    for (const [name, payload, expectedCode] of cases) {
        await t.test(name, async () => {
            await withServer({
                authKey: TEST_AUTH_KEY,
                fetchImpl: async () => providerResponse(payload)
            }, async baseUrl => {
                const response = await postOtp(baseUrl);
                assert.equal(response.status, 502);
                const body = await response.json();
                assert.equal(body.success, false);
                assert.equal(body.code, expectedCode);
            });
        });
    }
});

test('allows CORS only from the local application origin', async () => {
    await withServer({ authKey: TEST_AUTH_KEY }, async baseUrl => {
        const allowed = await fetch(`${baseUrl}/api/health`, {
            headers: { Origin: 'http://localhost:8000' }
        });
        assert.equal(allowed.headers.get('access-control-allow-origin'), 'http://localhost:8000');

        const rejected = await fetch(`${baseUrl}/api/health`, {
            headers: { Origin: 'https://untrusted.example' }
        });
        assert.equal(rejected.headers.get('access-control-allow-origin'), null);
    });
});

test('maps provider credential, IP restriction, credit and vendor errors safely', async t => {
    const cases = [
        [{ status: 304, message: 'Invalid authkey' }, 200, 'PROVIDER_ACCESS_RESTRICTED'],
        [{ status: 304, message: 'IP not whitelisted' }, 200, 'PROVIDER_ACCESS_RESTRICTED'],
        [{ status: 301, message: 'Insufficient wallet balance' }, 200, 'INSUFFICIENT_CREDITS'],
        [{ status: 310, message: 'Vendor unavailable' }, 200, 'PROVIDER_ERROR'],
        [{ status: 310, message: 'Vendor unavailable' }, 503, 'PROVIDER_HTTP_ERROR']
    ];
    for (const [payload, providerStatus, expectedCode] of cases) {
        await t.test(expectedCode, async () => {
            await withServer({
                authKey: TEST_AUTH_KEY,
                fetchImpl: async () => providerResponse(payload, providerStatus)
            }, async baseUrl => {
                const response = await postOtp(baseUrl);
                const body = await response.json();
                assert.equal(body.code, expectedCode);
                assert.equal(JSON.stringify(body).includes(TEST_AUTH_KEY), false);
                assert.equal(JSON.stringify(body).includes(TEST_AADHAAR), false);
                assert.equal(JSON.stringify(body).includes(payload.message), false);
            });
        });
    }
});

test('logs sanitized provider HTTP details without logging Aadhaar or Auth Key', async () => {
    const logs = [];
    await withServer({
        authKey: TEST_AUTH_KEY,
        logger: { warn: (...args) => logs.push(args) },
        fetchImpl: async () => providerResponse({
            status: 304,
            message: `Invalid authkey ${TEST_AUTH_KEY} for Aadhaar ${TEST_AADHAAR}, OTP 654321`
        }, 403)
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 502);
        assert.equal((await response.json()).code, 'PROVIDER_ACCESS_RESTRICTED');
    });
    assert.equal(logs.length, 1);
    const diagnostic = JSON.stringify(logs[0]);
    assert.match(diagnostic, /httpStatus/);
    assert.match(diagnostic, /403/);
    assert.match(diagnostic, /"statusType":"number"/);
    assert.equal(diagnostic.includes(TEST_AUTH_KEY), false);
    assert.equal(diagnostic.includes(TEST_AADHAAR), false);
    assert.equal(diagnostic.includes('654321'), false);
});

test('diagnoses the reported generic send failure without logging request values', async () => {
    const logs = [];
    await withServer({
        authKey: TEST_AUTH_KEY,
        logger: { warn: (...args) => logs.push(args) },
        fetchImpl: async () => providerResponse({
            status: 200,
            message: 'Failed to send Aadhaar OTP. Please try again later.'
        })
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 502);
        assert.equal((await response.json()).code, 'PROVIDER_ERROR');
    });
    assert.equal(logs.length, 1);
    const diagnostic = JSON.stringify(logs[0]);
    assert.match(diagnostic, /"httpStatus":200/);
    assert.match(diagnostic, /"status":200/);
    assert.match(diagnostic, /"statusType":"number"/);
    assert.match(diagnostic, /Failed to send Aadhaar OTP/);
    assert.match(diagnostic, /"topLevelKeys":\["status","message"\]/);
    assert.match(diagnostic, /"dataType":"undefined"/);
    assert.match(diagnostic, /"hasReferenceId":false/);
    assert.equal(diagnostic.includes(TEST_AUTH_KEY), false);
    assert.equal(diagnostic.includes(TEST_AADHAAR), false);
    assert.equal(diagnostic.includes(TEST_OTP), false);
});

test('returns a timeout without retrying the billable request', async () => {
    let providerCalls = 0;
    await withServer({
        authKey: TEST_AUTH_KEY,
        timeoutMs: 5,
        fetchImpl: async (url, { signal }) => {
            providerCalls += 1;
            return new Promise((resolve, reject) => {
                signal.addEventListener('abort', () => {
                    const error = new Error('aborted');
                    error.name = 'AbortError';
                    reject(error);
                }, { once: true });
            });
        }
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 504);
        assert.equal((await response.json()).code, 'PROVIDER_TIMEOUT');
    });
    assert.equal(providerCalls, 1);
});

test('returns a timeout if the provider response body stalls', async () => {
    await withServer({
        authKey: TEST_AUTH_KEY,
        timeoutMs: 5,
        fetchImpl: async (url, { signal }) => ({
            ok: true,
            status: 200,
            json: async () => new Promise((resolve, reject) => {
                signal.addEventListener('abort', () => {
                    const error = new Error('aborted');
                    error.name = 'AbortError';
                    reject(error);
                }, { once: true });
            })
        })
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        assert.equal(response.status, 504);
        assert.equal((await response.json()).code, 'PROVIDER_TIMEOUT');
    });
});

test('handles network failures and malformed provider JSON without leaking details', async t => {
    await t.test('network failure', async () => {
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => {
                throw new Error(`network failed for ${TEST_AADHAAR}`);
            }
        }, async baseUrl => {
            const response = await postOtp(baseUrl);
            const body = await response.json();
            assert.equal(body.code, 'PROVIDER_UNAVAILABLE');
            assert.equal(JSON.stringify(body).includes(TEST_AADHAAR), false);
        });
    });

    await t.test('malformed JSON', async () => {
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => ({
                ok: true,
                status: 200,
                json: async () => { throw new SyntaxError('malformed provider response'); }
            })
        }, async baseUrl => {
            const response = await postOtp(baseUrl);
            assert.equal((await response.json()).code, 'INVALID_PROVIDER_RESPONSE');
        });
    });
});

test('never forwards an unmasked Aadhaar value from a malformed provider response', async () => {
    await withServer({
        authKey: TEST_AUTH_KEY,
        fetchImpl: async () => providerResponse({
            status: 200,
            message: 'success',
            data: {
                reference_id: TEST_REFERENCE_ID,
                masked_aadhaar: TEST_AADHAAR
            }
        })
    }, async baseUrl => {
        const response = await postOtp(baseUrl);
        const body = await response.json();
        assert.equal(body.success, true);
        assert.equal(body.masked_aadhaar, undefined);
        assert.equal(JSON.stringify(body).includes(TEST_AADHAAR), false);
    });
});

test('verifies using the documented payload and confirms only provider-verified success', async () => {
        let request;
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async (url, options) => {
                request = { url, ...options, body: JSON.parse(options.body) };
                return providerResponse({
                    status: 200,
                    message: 'success',
                    request_id: 'provider-verification-request',
                    data: {
                        verified: true,
                        name: 'REDACTED PROFILE DATA',
                        date_of_birth: '15-06-1990',
                        gender: 'M',
                        full_address: 'Jaipur, Rajasthan',
                        address: { house: '123', state: 'Rajasthan', pincode: '302001' },
                        photo: 'aGVsbG8=',
                        has_photo: true,
                        certificate_url: 'https://private.example/certificate'
                    }
                });
            }
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            assert.equal(response.status, 200);
            const responseBody = await response.json();
            assert.deepEqual(responseBody, {
                success: true,
                verified: true,
                name: 'REDACTED PROFILE DATA',
                date_of_birth: '15-06-1990',
                gender: 'M',
                full_address: 'Jaipur, Rajasthan',
                address: { house: '123', state: 'Rajasthan', pincode: '302001' },
                photo: 'aGVsbG8=',
                has_photo: true
            });
            assert.equal(JSON.stringify(responseBody).includes('private.example'), false);
        });
        assert.equal(request.url, 'https://apitxt.com/api/aadhaarVerifyOTP');
        assert.equal(request.method, 'POST');
        assert.deepEqual(request.body, {
            authkey: TEST_AUTH_KEY,
            reference_id: TEST_REFERENCE_ID,
            otp: TEST_OTP
        });
        assert.ok(request.signal instanceof AbortSignal);
    });

    test('trims surrounding OTP whitespace without changing the submitted code', async () => {
        let requestBody;
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async (url, options) => {
                requestBody = JSON.parse(options.body);
                return providerResponse({
                    status: 200,
                    message: 'success',
                    data: { verified: true, name: 'TEST PROFILE' }
                });
            }
        }, async baseUrl => {
            const response = await fetch(`${baseUrl}/api/aadhaar/verify-otp`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reference_id: TEST_REFERENCE_ID, otp: ` ${TEST_OTP} \n` })
            });
            assert.equal(response.status, 200);
            assert.deepEqual(await response.json(), {
                success: true,
                verified: true,
                name: 'TEST PROFILE'
            });
        });
        assert.equal(requestBody.otp, TEST_OTP);
    });

    test('rejects an invalid OTP without marking verification successful', async () => {
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => providerResponse({
                status: 204,
                message: 'Invalid OTP. Must be exactly 6 digits.'
            })
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            assert.equal(response.status, 400);
            const body = await response.json();
            assert.equal(body.success, false);
            assert.equal(body.code, 'INVALID_OTP');
            assert.match(body.message, /did not accept that OTP/);
            assert.equal(body.provider_message, 'Invalid OTP. Must be exactly 6 digits.');
        });
    });

test('surfaces APITxT status 310 without claiming the OTP itself is wrong', async () => {
    await withServer({
        authKey: TEST_AUTH_KEY,
        fetchImpl: async () => providerResponse({
            status: 310,
            message: 'Verification failed (vendor error or wrong OTP).'
        })
    }, async baseUrl => {
        const response = await postVerifyOtp(baseUrl);
        const body = await response.json();
        assert.equal(response.status, 502);
        assert.equal(body.success, false);
        assert.equal(body.code, 'PROVIDER_ERROR');
        assert.match(body.message, /does not establish that the entered OTP was incorrect/);
        assert.equal(body.provider_message, 'Verification failed (vendor error or wrong OTP).');
    });
});

    test('verification diagnostics do not log the Auth Key, reference ID, OTP, or KYC fields', async () => {
        const logs = [];
        await withServer({
            authKey: TEST_AUTH_KEY,
            logger: { warn: (...args) => logs.push(args) },
            fetchImpl: async () => providerResponse({
                status: 204,
                message: `Invalid OTP ${TEST_OTP}; OTP 246 810; Aadhaar 1234 5678 9012; reference_id=${TEST_REFERENCE_ID}; authkey=${TEST_AUTH_KEY}`,
                data: { verified: false, name: 'Sensitive Customer Name' }
            })
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            assert.equal(response.status, 400);
            assert.equal((await response.json()).code, 'INVALID_OTP');
        });
        const diagnostic = JSON.stringify(logs);
        assert.match(diagnostic, /INVALID_OTP/);
        assert.equal(diagnostic.includes(TEST_AUTH_KEY), false);
        assert.equal(diagnostic.includes(TEST_REFERENCE_ID), false);
        assert.equal(diagnostic.includes(TEST_OTP), false);
        assert.equal(diagnostic.includes('246 810'), false);
        assert.equal(diagnostic.includes('1234 5678 9012'), false);
        assert.equal(diagnostic.includes('Sensitive Customer Name'), false);
    });

    test('rejects incomplete verification responses and invalid request fields', async t => {
        await t.test('provider success without verified true', async () => {
            await withServer({
                authKey: TEST_AUTH_KEY,
                fetchImpl: async () => providerResponse({ status: 200, message: 'success', data: {} })
            }, async baseUrl => {
                const response = await postVerifyOtp(baseUrl);
                assert.equal(response.status, 502);
                assert.equal((await response.json()).success, false);
            });
        });

        await t.test('invalid OTP shape is rejected before provider call', async () => {
            let providerCalls = 0;
            await withServer({
                authKey: TEST_AUTH_KEY,
                fetchImpl: async () => { providerCalls += 1; return providerResponse({}); }
            }, async baseUrl => {
                const response = await postVerifyOtp(baseUrl, TEST_REFERENCE_ID, '123');
                assert.equal(response.status, 400);
                assert.equal((await response.json()).code, 'INVALID_OTP');
            });
            assert.equal(providerCalls, 0);
        });

        await t.test('missing reference is rejected before provider call', async () => {
            let providerCalls = 0;
            await withServer({
                authKey: TEST_AUTH_KEY,
                fetchImpl: async () => { providerCalls += 1; return providerResponse({}); }
            }, async baseUrl => {
                const response = await postVerifyOtp(baseUrl, '', TEST_OTP);
                assert.equal(response.status, 400);
                assert.equal((await response.json()).code, 'INVALID_REFERENCE_ID');
            });
            assert.equal(providerCalls, 0);
        });
    });

test('verification timeout does not retry the provider request', async () => {
        let providerCalls = 0;
        const logs = [];
        await withServer({
            authKey: TEST_AUTH_KEY,
            logger: { warn: (...args) => logs.push(args) },
            timeoutMs: 5,
            fetchImpl: async (url, { signal }) => {
                providerCalls += 1;
                return new Promise((resolve, reject) => {
                    signal.addEventListener('abort', () => {
                        const error = new Error('aborted');
                        error.name = 'AbortError';
                        reject(error);
                    }, { once: true });
                });
            }
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            assert.equal(response.status, 504);
            const body = await response.json();
            assert.equal(body.code, 'VERIFICATION_UNKNOWN');
            assert.equal(body.outcome, 'unknown');
            assert.match(body.message, /do not resubmit/);
            const repeated = await postVerifyOtp(baseUrl);
            assert.equal(repeated.status, 409);
            assert.equal((await repeated.json()).code, 'VERIFICATION_UNKNOWN');
        });
        assert.equal(providerCalls, 1);
        const diagnostic = JSON.stringify(logs);
        assert.match(diagnostic, /"category":"timeout"/);
        assert.match(diagnostic, /"phase":"waiting_for_headers"/);
        assert.match(diagnostic, /"elapsedMs"/);
        assert.match(diagnostic, /"timeoutMs":5/);
        assert.equal(diagnostic.includes(TEST_AUTH_KEY), false);
        assert.equal(diagnostic.includes(TEST_REFERENCE_ID), false);
        assert.equal(diagnostic.includes(TEST_OTP), false);
});

test('verification body timeout is diagnosed separately from waiting for response headers', async () => {
        const logs = [];
        await withServer({
            authKey: TEST_AUTH_KEY,
            logger: { warn: (...args) => logs.push(args) },
            timeoutMs: 5,
            fetchImpl: async (url, { signal }) => ({
                ok: true,
                status: 200,
                json: async () => new Promise((resolve, reject) => {
                    signal.addEventListener('abort', () => {
                        const error = new Error('aborted');
                        error.name = 'AbortError';
                        reject(error);
                    }, { once: true });
                })
            })
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            assert.equal(response.status, 504);
            assert.equal((await response.json()).code, 'VERIFICATION_UNKNOWN');
        });
        const diagnostic = JSON.stringify(logs);
        assert.match(diagnostic, /"phase":"reading_response_body"/);
        assert.match(diagnostic, /"httpStatus":200/);
});

test('deduplicates concurrent and already-confirmed verification requests by reference', async () => {
    let providerCalls = 0;
    let releaseProvider;
    let signalProviderStarted;
    const providerStarted = new Promise(resolve => { signalProviderStarted = resolve; });
    await withServer({
        authKey: TEST_AUTH_KEY,
        fetchImpl: async () => {
            providerCalls += 1;
            signalProviderStarted();
            return new Promise(resolve => { releaseProvider = resolve; });
        }
    }, async baseUrl => {
        const firstRequest = postVerifyOtp(baseUrl);
        await providerStarted;
        const concurrent = await postVerifyOtp(baseUrl);
        assert.equal(concurrent.status, 409);
        assert.equal((await concurrent.json()).code, 'VERIFICATION_IN_PROGRESS');

        releaseProvider(providerResponse({
            status: 200,
            message: 'success',
            data: { verified: true }
        }));
        const firstResponse = await firstRequest;
        assert.equal(firstResponse.status, 200);
        assert.deepEqual(await firstResponse.json(), { success: true, verified: true });

        const repeated = await postVerifyOtp(baseUrl);
        assert.equal(repeated.status, 200);
        assert.deepEqual(await repeated.json(), { success: true, verified: true });
    });
    assert.equal(providerCalls, 1);
});

test('verification network failure is an unknown result and is never retried', async () => {
        let providerCalls = 0;
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => {
                providerCalls += 1;
                throw new Error(`socket closed; reference_id=${TEST_REFERENCE_ID}; otp=${TEST_OTP}`);
            }
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            const body = await response.json();
            assert.equal(response.status, 502);
            assert.equal(body.code, 'VERIFICATION_UNKNOWN');
            assert.equal(body.outcome, 'unknown');
            assert.equal(JSON.stringify(body).includes(TEST_REFERENCE_ID), false);
            assert.equal(JSON.stringify(body).includes(TEST_OTP), false);
        });
        assert.equal(providerCalls, 1);
});

test('verification response parse failure is unknown rather than a retryable invalid OTP', async () => {
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => ({
                ok: true,
                status: 200,
                json: async () => { throw new SyntaxError('invalid json'); }
            })
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            const body = await response.json();
            assert.equal(response.status, 502);
            assert.equal(body.code, 'VERIFICATION_UNKNOWN');
            assert.equal(body.outcome, 'unknown');
        });
});

test('provider HTTP 5xx response is unknown and not reported as OTP mismatch', async () => {
        await withServer({
            authKey: TEST_AUTH_KEY,
            fetchImpl: async () => providerResponse({
                status: 310,
                message: 'Temporary vendor failure'
            }, 503)
        }, async baseUrl => {
            const response = await postVerifyOtp(baseUrl);
            const body = await response.json();
            assert.equal(response.status, 502);
            assert.equal(body.code, 'VERIFICATION_UNKNOWN');
            assert.equal(body.outcome, 'unknown');
        });
});
