'use strict';

const assert = require('node:assert/strict');
const { once } = require('node:events');
const test = require('node:test');
const { createApp } = require('../server');

const AUTH_KEY = 'test-provider-key';
const PAN = 'ABCDE1234F';
const UDYAM = 'UDYAM-RJ-30-0001853';
const GSTIN = '22AAAAA0000A1Z5';

function jsonResponse(payload, status = 200) {
    return {
        ok: status >= 200 && status < 300,
        status,
        headers: new Headers({ 'content-type': 'application/json' }),
        json: async () => payload
    };
}

async function withServer(options, callback) {
    const server = createApp(options).listen(0, '127.0.0.1');
    await once(server, 'listening');
    const address = server.address();
    try {
        await callback(`http://127.0.0.1:${address.port}`);
    } finally {
        await new Promise((resolve, reject) => {
            server.close(error => error ? reject(error) : resolve());
        });
    }
}

async function postJson(url, body) {
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });
}

test('PAN advance sends normalized PAN and optional name, returning only documented profile fields', async () => {
    let request;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, ...options, body: JSON.parse(options.body) };
            return jsonResponse({
                status: 200,
                message: 'success',
                data: {
                    status: 'VALID',
                    registered_name: 'JANE DOE',
                    pan: PAN,
                    date_of_birth: '01-01-1990',
                    email: 'j***@example.com',
                    address: { city: 'JAIPUR', pincode: 302001 },
                    certificate_url: 'https://private.example/cert'
                }
            });
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/pan/advance-verify`, { pan: PAN.toLowerCase(), name: 'Jane Doe' });
        const body = await response.json();
        assert.equal(response.status, 200);
        assert.equal(body.success, true);
        assert.equal(body.data.status, 'VALID');
        assert.equal(body.data.registered_name, 'JANE DOE');
        assert.equal(body.data.address.city, 'JAIPUR');
        assert.equal(JSON.stringify(body).includes('private.example'), false);
        assert.equal(JSON.stringify(body).includes(AUTH_KEY), false);
    });
    assert.equal(request.url, 'https://apitxt.com/api/panAdvanceVerify');
    assert.deepEqual(request.body, { authkey: AUTH_KEY, pan: PAN, name: 'Jane Doe' });
});

test('Udyam verify returns the allowlisted enterprise data and never a certificate URL', async () => {
    let request;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, body: JSON.parse(options.body) };
            return jsonResponse({
                status: 200,
                message: 'success',
                data: {
                    status: 'SUCCESS',
                    udyam_number: UDYAM,
                    enterprise_name: 'Example Enterprise',
                    classification_history: [{ serial_number: '1', enterprise_type: 'Micro' }],
                    split_address: { city: 'Jaipur', pincode: '302001' },
                    certificate_url: 'https://private.example/signed.pdf'
                }
            });
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/udyam/verify`, { udyam: UDYAM.toLowerCase() });
        const body = await response.json();
        assert.equal(response.status, 200);
        assert.equal(body.data.udyam_number, UDYAM);
        assert.equal(body.data.classification_history[0].enterprise_type, 'Micro');
        assert.equal(JSON.stringify(body).includes('signed.pdf'), false);
    });
    assert.equal(request.url, 'https://apitxt.com/api/udyamVerify');
    assert.deepEqual(request.body, { authkey: AUTH_KEY, udyam: UDYAM, action: 'verify' });
});

test('GST verification uses the URL path and returns a sanitized active registration', async () => {
    let request;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, body: JSON.parse(options.body) };
            return jsonResponse({
                status: 200,
                message: 'success',
                data: { gstin: GSTIN, verified: true, status: 'Active', legal_name: 'EXAMPLE LIMITED' }
            });
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/gst/${GSTIN.toLowerCase()}`, {});
        const body = await response.json();
        assert.equal(response.status, 200);
        assert.equal(body.data.gstin, GSTIN);
        assert.equal(body.data.verified, true);
    });
    assert.equal(request.url, `https://apitxt.com/api/gst/${GSTIN}`);
    assert.deepEqual(request.body, { authkey: AUTH_KEY, action: 'verify' });
});

test('Udyam certificate action streams validated PDF with requested disposition', async () => {
    const pdf = Buffer.from('%PDF-1.7 test certificate');
    let request;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, body: JSON.parse(options.body) };
            return {
                ok: true,
                status: 200,
                headers: new Headers({ 'content-type': 'application/pdf', 'content-length': String(pdf.length) }),
                arrayBuffer: async () => pdf
            };
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/udyam/certificate/view`, { udyam: UDYAM });
        assert.equal(response.status, 200);
        assert.equal(response.headers.get('content-type'), 'application/pdf');
        assert.match(response.headers.get('content-disposition'), /^inline;/);
        assert.equal(Buffer.from(await response.arrayBuffer()).toString(), pdf.toString());
    });
    assert.equal(request.url, 'https://apitxt.com/api/udyamVerify');
    assert.deepEqual(request.body, { authkey: AUTH_KEY, udyam: UDYAM, action: 'view' });
});

test('GST certificate download streams an attachment and does not expose provider URLs', async () => {
    const pdf = Buffer.from('%PDF-1.4 GST certificate');
    let request;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, body: JSON.parse(options.body) };
            return {
                ok: true,
                status: 200,
                headers: new Headers({ 'content-type': 'application/pdf' }),
                arrayBuffer: async () => pdf
            };
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/gst/${GSTIN}?action=download`, {});
        assert.equal(response.status, 200);
        assert.match(response.headers.get('content-disposition'), /^attachment; filename="GST_Certificate_/);
        assert.equal(Buffer.from(await response.arrayBuffer()).toString(), pdf.toString());
    });
    assert.equal(request.url, `https://apitxt.com/api/gst/${GSTIN}`);
    assert.deepEqual(request.body, { authkey: AUTH_KEY, action: 'download' });
});

test('invalid business identifiers are rejected before provider calls', async t => {
    let calls = 0;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async () => {
            calls += 1;
            return jsonResponse({});
        }
    }, async baseUrl => {
        const pan = await postJson(`${baseUrl}/api/pan/advance-verify`, { pan: 'bad' });
        const udyam = await postJson(`${baseUrl}/api/udyam/verify`, { udyam: 'bad' });
        const gst = await postJson(`${baseUrl}/api/gst/bad`, {});
        assert.equal(pan.status, 400);
        assert.equal(udyam.status, 400);
        assert.equal(gst.status, 400);
    });
    assert.equal(calls, 0);
});

test('unified mobile OTP sends form-encoded request, keeps OTP server-side, and verifies once', async () => {
    let request;
    let sentOtp;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            request = { url, ...options };
            const form = new URLSearchParams(options.body);
            sentOtp = form.get('otp');
            assert.equal(form.get('mobile'), '919876543210');
            assert.equal(form.get('channel'), 'sms');
            return jsonResponse({ status: 'success', message: 'Sms OTP Sent Successfully', data: { request_id: 'SMS-123' } });
        }
    }, async baseUrl => {
        const sent = await postJson(`${baseUrl}/api/mobile/send-otp`, { mobile: '9876543210' });
        const sendBody = await sent.json();
        assert.deepEqual(sendBody, { success: true, request_id: 'SMS-123' });
        assert.equal(JSON.stringify(sendBody).includes(sentOtp), false);
        assert.equal(JSON.stringify(sendBody).includes(AUTH_KEY), false);
        assert.match(sentOtp, /^\d{6}$/);

        const verified = await postJson(`${baseUrl}/api/mobile/verify-otp`, { mobile: '9876543210', otp: sentOtp });
        assert.deepEqual(await verified.json(), { success: true, verified: true });
        const replay = await postJson(`${baseUrl}/api/mobile/verify-otp`, { mobile: '9876543210', otp: sentOtp });
        assert.equal(replay.status, 400);
        assert.equal((await replay.json()).code, 'OTP_EXPIRED');
    });
    assert.equal(request.url, 'https://apitxt.com/api/sendOTP');
    assert.equal(request.headers['Content-Type'], 'application/x-www-form-urlencoded');
    assert.equal(new URLSearchParams(request.body).get('authkey'), AUTH_KEY);
});

test('unified mobile OTP enforces the documented three-send-per-minute limit', async () => {
    let calls = 0;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async () => {
            calls += 1;
            return jsonResponse({ status: 'success', message: 'sent' });
        }
    }, async baseUrl => {
        for (let index = 0; index < 3; index += 1) {
            const response = await postJson(`${baseUrl}/api/mobile/send-otp`, { mobile: '9876543210' });
            assert.equal(response.status, 200);
        }
        const limited = await postJson(`${baseUrl}/api/mobile/send-otp`, { mobile: '9876543210' });
        assert.equal(limited.status, 429);
        assert.equal((await limited.json()).code, 'OTP_RATE_LIMITED');
    });
    assert.equal(calls, 3);
});

test('unified mobile OTP supports configured WhatsApp template settings', async () => {
    let formValues;
    await withServer({
        authKey: AUTH_KEY,
        otpChannel: 'whatsapp',
        otpTemplateName: 'verification_otp',
        otpProjectRefId: 'PROJ_test_123',
        fetchImpl: async (url, options) => {
            formValues = new URLSearchParams(options.body);
            return jsonResponse({ status: 'success', message: 'WhatsApp OTP Sent Successfully' });
        }
    }, async baseUrl => {
        const response = await postJson(`${baseUrl}/api/mobile/send-otp`, { mobile: '9876543210' });
        assert.equal(response.status, 200);
        assert.equal(formValues.get('channel'), 'whatsapp');
        assert.equal(formValues.get('template_name'), 'verification_otp');
        assert.equal(formValues.get('project_ref_id'), 'PROJ_test_123');
        assert.equal(formValues.has('template_id'), false);
    });
});

test('unified mobile OTP locks the challenge after five invalid attempts', async () => {
    let sentOtp;
    await withServer({
        authKey: AUTH_KEY,
        fetchImpl: async (url, options) => {
            sentOtp = new URLSearchParams(options.body).get('otp');
            return jsonResponse({ status: 'success', message: 'sent' });
        }
    }, async baseUrl => {
        await postJson(`${baseUrl}/api/mobile/send-otp`, { mobile: '9876543210' });
        for (let index = 0; index < 4; index += 1) {
            const invalid = await postJson(`${baseUrl}/api/mobile/verify-otp`, {
                mobile: '9876543210',
                otp: sentOtp === '000000' ? '000001' : '000000'
            });
            assert.equal(invalid.status, 400);
        }
        const locked = await postJson(`${baseUrl}/api/mobile/verify-otp`, {
            mobile: '9876543210',
            otp: sentOtp === '000000' ? '000001' : '000000'
        });
        assert.equal(locked.status, 429);
        assert.equal((await locked.json()).code, 'OTP_ATTEMPTS_EXCEEDED');
    });
});
