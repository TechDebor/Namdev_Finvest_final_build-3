import re
import os

images = {
    'index.html': 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=2400&q=80', # Rural entrepreneur/business
    'msme.html': 'https://images.unsplash.com/photo-1556761175-5973dc0f32b7?auto=format&fit=crop&w=2400&q=80', # Small business/shop
    'two-wheeler.html': 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=2400&q=80', # Motorcycle
    'lap.html': 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2400&q=80', # Beautiful property/house
    'solar.html': 'https://images.unsplash.com/photo-1509391366360-1f9509e98822?auto=format&fit=crop&w=2400&q=80', # Solar panels
    'tractor.html': 'https://images.unsplash.com/photo-1592982537447-6f2a6a0c5c58?auto=format&fit=crop&w=2400&q=80', # Tractor/Farming
    'welcome-dashboard.html': 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=2400&q=80' # Corporate dashboard
}

def inject_bg_into_hero(file, img_url):
    if not os.path.exists(file):
        return
        
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # Check if we already injected a background image
        if '<div style="position: absolute; inset: 0; z-index: -1' in content:
            # Let's replace the existing img src to high res if it exists
            print(f"Image already in {file}, skipping or replacing...")
            pass
            
        # Find <section class="hero-quantum" ... >
        # We need to inject the background div right after it
        pattern = r'(<section[^>]*class="hero-quantum"[^>]*>)'
        match = re.search(pattern, content)
        
        if match:
            # Ensure the section has position: relative
            section_tag = match.group(1)
            new_section_tag = section_tag
            if 'position: relative' not in new_section_tag:
                if 'style="' in new_section_tag:
                    new_section_tag = new_section_tag.replace('style="', 'style="position: relative; overflow: hidden; ')
                else:
                    new_section_tag = new_section_tag.replace('>', ' style="position: relative; overflow: hidden;">')
                    
            bg_div = f"""
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.25;">
        <img src="{img_url}" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">
      </div>
"""
            # Replace the section tag with the new one + the background div
            content = content.replace(section_tag, new_section_tag + bg_div)
            
            # Now we need to make sure the inner container has z-index: 1 so it sits above the image
            # Find the div immediately following the bg_div. Usually <div class="container"> or <div class="hero-grid">
            content = content.replace('<div class="container">', '<div class="container" style="position: relative; z-index: 1;">', 1)
            content = content.replace('<div class="hero-grid">', '<div class="hero-grid" style="position: relative; z-index: 1;">', 1)

            with open(file, 'w') as f:
                f.write(content)
            print(f"Successfully added High-Res image to {file}")
    except Exception as e:
        print(f"Error on {file}: {e}")

for file, img in images.items():
    inject_bg_into_hero(file, img)

# Also let's fix any "fat" images in the 4 pages we generated earlier by upgrading their resolution (w=2400)
# and ensuring object-fit is strict.
pages_to_upgrade = ['about.html', 'investor.html', 'team.html', 'contact.html']
for page in pages_to_upgrade:
    try:
        with open(page, 'r') as f:
            content = f.read()
            
        content = content.replace('w=1600', 'w=2400')
        # Ensure object-fit is present on all imgs
        content = content.replace('<img src=', '<img style="object-fit: cover;" src=')
        # Clean up any double object-fit
        content = content.replace('style="object-fit: cover;" style="', 'style="object-fit: cover; ')
        
        with open(page, 'w') as f:
            f.write(content)
        print(f"Upgraded image resolution in {page}")
    except Exception as e:
        pass

