# Local banking statement prototype

This API supports the statement-upload stage in `../apply.html`. It parses the
uploaded statement in memory and does not provide bank verification, a validated
BSA score, loan underwriting, or loan approval. Account Aggregator endpoints
remain unavailable until a licensed provider is configured.

## Run locally

From this directory, create and activate a Python virtual environment, install
`requirements.txt`, then start the API:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 127.0.0.1 --port 8787
```

Serve the website separately over HTTP, for example at `http://127.0.0.1:8000`.
The application connects to the local API on port `8787`. The API health check
is `/api/health`; interactive API documentation is at `/docs`.

PDF image OCR requires the Tesseract executable in addition to the Python
dependencies. CSV statements can be parsed without Tesseract. Do not use real
customer statements with this prototype; it has no production authentication,
retention controls, or approved banking-provider integration.
