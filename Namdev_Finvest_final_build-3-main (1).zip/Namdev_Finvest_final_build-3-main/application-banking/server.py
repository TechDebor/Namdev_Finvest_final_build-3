"""Namdev local prototype backend: real OCR/parsing, no live verification or AA provider.
Run: uvicorn server:app --host 127.0.0.1 --port 8787
Production must add auth, encryption, secure storage, virus checks and approved APIs.
"""
from __future__ import annotations
import csv, io, re, os, pathlib, logging, decimal, hashlib
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
import shutil
from PIL import Image, ImageOps, ImageEnhance, UnidentifiedImageError
import pytesseract
import fitz

app=FastAPI(title='Namdev Banking & KYC Local Prototype',version='2.0')
app.add_middleware(CORSMiddleware,allow_origins=[f'http://{h}:{p}' for h in ('127.0.0.1','localhost') for p in (3000,4173,5000,5173,5500,8000,8080)], allow_methods=['GET','POST'],allow_headers=['*'])
MAX_KYC=12*1024*1024
MAX_BANK=22*1024*1024

@app.get('/')
async def ui():
    return {'service':'Namdev local banking prototype API','health':'/api/health','apiDocs':'/docs','website':'Serve apply.html separately'}
@app.get('/api/health')
async def health():
    return {'status':'local-ocr-ready','ocrInstalled':bool(shutil.which('tesseract')),'statementParserReady':True,'liveAA':False,'liveOTP':False,'providerVerification':False,'version':'3.0'}

async def read_safe(upload:UploadFile,limit:int):
    raw=await upload.read(limit+1)
    if len(raw)>limit:raise HTTPException(413,'File exceeds configured size limit')
    if not raw:raise HTTPException(400,'Empty upload')
    return raw

def recognize_image(data:bytes):
    try:
        image=Image.open(io.BytesIO(data));image.load()
    except (UnidentifiedImageError,OSError):raise HTTPException(415,'Invalid image file')
    if image.width*image.height>26_000_000:raise HTTPException(413,'Image dimensions too large')
    image=ImageOps.exif_transpose(image).convert('RGB')
    scale=min(3.0,max(1.0,1800/min(image.size)))
    if scale>1.01:image=image.resize((int(image.width*scale),int(image.height*scale)))
    gray=ImageOps.grayscale(image)
    enh=ImageEnhance.Contrast(gray).enhance(1.5)
    try:return pytesseract.image_to_string(enh,config='--oem 3 --psm 6')+'\n'+pytesseract.image_to_string(image,config='--oem 3 --psm 11')
    except pytesseract.TesseractNotFoundError:raise HTTPException(503,'Tesseract OCR binary not installed')

def get_text(raw:bytes,filename:str,mimetype:str,maxpages:int):
    name=filename.lower()
    if name.endswith('.pdf') or mimetype=='application/pdf':
        if not raw.startswith(b'%PDF-'):raise HTTPException(415,'File is not a valid PDF')
        try:
            doc=fitz.open(stream=raw,filetype='pdf')
        except Exception:raise HTTPException(400,'PDF could not be opened or is password protected')
        if doc.needs_pass:raise HTTPException(400,'Remove PDF password before scanning')
        if len(doc)>maxpages:raise HTTPException(413,f'PDF must have {maxpages} pages or fewer')
        chunks=[]
        for page in doc:
            txt=page.get_text(sort=True)
            chunks.append(txt)
            if len(txt.strip())<95:
                pix=page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
                chunks.append(recognize_image(pix.tobytes('png')))
        return '\n'.join(chunks),'PDF text + OCR fallback'
    if name.endswith(('.png','.jpg','.jpeg','.webp')) or mimetype.startswith('image/'):
        return recognize_image(raw),'Local Tesseract OCR'
    if name.endswith('.csv') and maxpages>10:
        try:return raw.decode('utf-8-sig'),'CSV text'
        except:return raw.decode('latin-1'),'CSV text'
    raise HTTPException(415,'Use PDF/JPG/PNG/WEBP (or CSV for banking)')

def pickup(lines,patterns):
    for idx,line in enumerate(lines):
        for pat in patterns:
            m=re.search(pat,line,re.I)
            if m:
                v=(m.group(1) if m.lastindex else '').strip().strip(':.- ')
                if v and 1<len(v)<120:return v
                if idx+1<len(lines) and len(lines[idx+1])<120:return lines[idx+1].strip()
    return ''

def identifier(doc,text):
    up=text.upper().replace('–','-')
    if doc=='aadhaar':
        matches=re.findall(r'(?<!\d)([2-9]\d{3}[\s-]?\d{4}[\s-]?\d{4})(?!\d)',up)
        return next((re.sub(r'\D','',v) for v in matches), '')
    if doc=='pan':
        candidates=re.findall(r'(?<![A-Z0-9])[A-Z]{5}[0-9OQ]{4}[A-Z](?![A-Z0-9])',up)
        return next((v[:5]+v[5:9].replace('O','0').replace('Q','0')+v[9] for v in candidates),'')
    if doc=='gstin':
        candidates=re.findall(r'(?<![A-Z0-9])[0-9OQ]{2}[A-Z]{5}[0-9OQ]{4}[A-Z][1-9A-Z]Z[0-9A-Z](?![A-Z0-9])',up)
        return next((v[:2].replace('O','0').replace('Q','0')+v[2:7]+v[7:11].replace('O','0').replace('Q','0')+v[11:] for v in candidates),'')
    if doc=='udyam':
        m=re.search(r'UDYAM[\s-]*([A-Z]{2})[\s-]*(\d{2})[\s-]*(\d{7})',up)
        return 'UDYAM-'+m[1]+'-'+m[2]+'-'+m[3] if m else ''
    return ''

def identity_fields(doc,text):
    lines=[v.strip() for v in text.replace('\r','\n').splitlines() if v.strip()]
    f={}
    num=identifier(doc,text)
    if num:f[doc]=num
    def put(key,regex):
        val=pickup(lines,regex)
        if val and val.lower() not in ('name','date of birth','address','gender') and len(val)<110:f[key]=val
    if doc in ('aadhaar','pan'):
        put('name',[r'^(?:name|cardholder\s*name|applicant\s*name|name\s*of\s*(?:the\s*)?holder)\s*[:\-]\s*(.*)$'])
        put('dob',[r'(?:DOB|D[.\s]*O[.\s]*B|Date\s*of\s*Birth|Birth\s*date)\s*[:\-]?\s*(\d{1,2}[/.\-]\d{1,2}[/.\-]\d{4})'])
        put('gender',[r'^\s*(male|female|transgender)\s*$'])
        if doc=='aadhaar':put('address',[r'^\s*Address\s*[:\-]\s*(.*)$'])
        else:put('father',[r'^(?:father.?s\s*name|father\s*name)\s*[:\-]\s*(.*)$'])
    if doc in ('gstin','udyam'):
        put('business',[r'^(?:legal\s*name\s*of\s*business|name\s*of\s*(?:the\s*)?enterprise|enterprise\s*name|legal\s*business\s*name)\s*[:\-]\s*(.*)$'])
        put('trade',[r'^\s*trade\s*name\s*[:\-]\s*(.*)$'])
        put('constitution',[r'^(?:constitution\s*of\s*business|type\s*of\s*organisation|organisation\s*type)\s*[:\-]\s*(.*)$'])
        put('state',[r'^\s*state\s*[:\-]\s*(.*)$'])
        put('district',[r'^\s*district\s*[:\-]\s*(.*)$'])
        put('activity',[r'^\s*major\s*activity\s*[:\-]\s*(.*)$'])
        put('registration',[r'^(?:date\s*of\s*registration|registration\s*date)\s*[:\-]\s*(.*)$'])
    return f

@app.post('/api/ocr/kyc')
async def ocr_kyc(document_type:str=Form(...),file:UploadFile=File(...)):
    typ=document_type.lower()
    if typ not in ('aadhaar','pan','gstin','udyam'):raise HTTPException(422,'Unsupported KYC document type')
    raw=await read_safe(file,MAX_KYC)
    txt,source=get_text(raw,file.filename or '',file.content_type or '',8)
    fields=identity_fields(typ,txt)
    return {'fields':fields,'identifierValid':bool(fields.get(typ)),'fieldCount':len(fields),'engine':source,'providerVerified':False,'message':'Extracted from document; not government verified' if fields.get(typ) else 'Number not recognized. Retry with clear document.'}

BANKS=[('STATE BANK OF INDIA',r'\b(?:STATE BANK OF INDIA|SBI)\b'),('HDFC Bank',r'\bHDFC BANK\b'),('ICICI Bank',r'\bICICI BANK\b'),('Axis Bank',r'\bAXIS BANK\b'),('Punjab National Bank',r'\bPUNJAB NATIONAL BANK|\bPNB\b'),('Bank of Baroda',r'\bBANK OF BARODA\b'),('Kotak Mahindra Bank',r'\bKOTAK MAHINDRA\b'),('Union Bank of India',r'\bUNION BANK OF INDIA\b')]

def bank_fields(text):
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    u=text.upper();f={}
    for name,pat in BANKS:
        if re.search(pat,u):f['bank']=name;break
    patterns=[r'\b(?:a/c|account)\s*(?:no\.?|number|#|:)?\s*[:\-]?\s*([Xx*\d\s-]{7,26})',r'\bACCT\s*(?:NO|NUMBER)?\s*[:\-]\s*([Xx*\d\s-]{7,26})']
    for pat in patterns:
        m=re.search(pat,text,re.I)
        if m:
            v=re.sub(r'[\s-]+','',m.group(1));
            if len(v)>=7 and re.search(r'\d{4}',v):f['accountMasked']='•'*(max(0,len(v)-4))+v[-4:];break
    ifsc=re.search(r'\b[A-Z]{4}0[A-Z0-9]{6}\b',u)
    if ifsc:f['ifsc']=ifsc.group()
    holder=pickup(lines,[r'^(?:account\s*holder|customer\s*name|account\s*name|name\s*of\s*customer|name)\s*[:\-]\s*(.*)$'])
    if holder:f['holder']=holder
    typ=re.search(r'\b(CURRENT|SAVINGS|OVERDRAFT|CASH CREDIT)\s+ACCOUNT\b|\bACCOUNT\s+TYPE\s*[:\-]\s*(CURRENT|SAVINGS|OVERDRAFT|CASH CREDIT)',u)
    if typ:f['type']=(typ[1] or typ[2]).title()
    return f

def parse_transaction_summary(text):
    """Conservative credit/debit totals: compute ONLY on recognized date + debit/credit columns.
    Never fabricate monthly cash flow from loosely structured scanned text.
    """
    lines=[v.strip() for v in text.splitlines() if v.strip()]
    data={'transactionCount':None,'totalCredits':None,'totalDebits':None,'confidence':'Not calculated: transaction columns require a reliable structured parser.'}
    # CSV header with explicit debit/credit columns is safe to aggregate.
    try:
        dialect=csv.Sniffer().sniff(text[:4096]);rows=list(csv.DictReader(io.StringIO(text),dialect=dialect))
        if rows and len(rows)<15000:
            keys={k.lower().strip():k for k in rows[0].keys() if k}
            debit=next((keys[k] for k in keys if k in ('debit','withdrawal','withdrawals','withdrawal amt.')),None)
            credit=next((keys[k] for k in keys if k in ('credit','deposit','deposits','deposit amt.')),None)
            if debit and credit:
                def amt(raw):
                    v=re.sub(r'[₹,\s]','',str(raw or '')).strip()
                    return decimal.Decimal(v) if re.fullmatch(r'-?\d+(?:\.\d{1,2})?',v) else decimal.Decimal('0')
                c=sum((amt(row.get(credit)) for row in rows),decimal.Decimal('0'))
                d=sum((amt(row.get(debit)) for row in rows),decimal.Decimal('0'))
                data={'transactionCount':len(rows),'totalCredits':str(c),'totalDebits':str(d),'confidence':'Computed from explicit CSV debit and credit columns.'}
    except (csv.Error,ValueError,decimal.InvalidOperation):pass
    return data

@app.post('/api/banking/statement/parse')
async def statement_parse(file:UploadFile=File(...)):
    raw=await read_safe(file,MAX_BANK)
    txt,source=get_text(raw,file.filename or '',file.content_type or '',60)
    fields=bank_fields(txt)
    summary=parse_transaction_summary(txt) if (file.filename or '').lower().endswith('.csv') else {'transactionCount':None,'totalCredits':None,'totalDebits':None,'confidence':'PDF parsed for identity metadata; financial metrics require a validated BSA service.'}
    return {'fields':fields,'analysis':summary,'fileName':pathlib.PurePath(file.filename or 'statement').name,'sha256':hashlib.sha256(raw).hexdigest(),'engine':source,'fieldCount':len(fields),'verifiedByBank':False,'providerConnected':False,'warnings':([] if fields else ['No bank metadata confidently found. Request a clearer statement or provider response.'])}

@app.post('/api/banking/bsa/analyze')
async def analyze_bsa(file:UploadFile=File(...),consent:str=Form(...)):
    if consent!='true':raise HTTPException(400,'Customer consent required')
    return await statement_parse(file)

@app.post('/api/banking/aa/consent')
async def aa_consent():raise HTTPException(501,'Live Account Aggregator provider not connected. Add FIU/AA integration and hosted consent flow.')
@app.post('/api/banking/aa/fetch')
async def aa_fetch():raise HTTPException(501,'Live Account Aggregator FI data fetch is not configured.')
