/* Namdev local banking prototype. Live AA and customer OTP providers are not configured. */
(()=>{'use strict';
const $=id=>document.getElementById(id), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store=new Map(); let selected='primary',flow='aa';let fileURL=null;
const localHost=/^(localhost|127\.0\.0\.1)$/.test(location.hostname);
let apiBase=localHost?`http://${location.hostname}:8787`:'';
let serviceStatus='checking', checking=null;
const LOCAL_API=apiBase;
function issueText(e){let t=String(e?.message||e||'Unable to complete request');
  if(/Failed to fetch|NetworkError|Load failed|fetch failed|abort/i.test(t))return 'The local statement OCR API is unavailable on port 8787. Start it using the instructions in application-banking/README.md, then retry.';
  return t;
}
async function fetchJSON(path, options={},ms=45000){
  if(location.protocol==='file:')throw Error('This page was opened as a file. Serve the website over HTTP and run the local OCR API on port 8787.');
  if(!apiBase)throw Error('No approved statement-processing API is configured for this website.');
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),ms);
  try{const resp=await fetch(apiBase+path,{...options,signal:controller.signal});const kind=resp.headers.get('content-type')||'';
    if(!kind.includes('application/json'))throw Error('The local OCR API on port 8787 did not return JSON. Check the backend service and retry.');
    const result=await resp.json();if(!resp.ok)throw Error(typeof result.detail==='string'?result.detail:'Request failed (HTTP '+resp.status+')');return result;
  }catch(e){if(e.name==='AbortError')throw Error('The OCR service timed out. Please check the server and retry.');throw Error(issueText(e));}
  finally{clearTimeout(timeout)}
}
async function healthPing(base,ms=3600){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),ms);
  try{const r=await fetch(base+'/api/health',{cache:'no-store',signal:controller.signal});if(!r.ok||!r.headers.get('content-type')?.includes('application/json'))return null;
    const d=await r.json();return d?.status==='local-ocr-ready'?d:null;
  }catch{return null}finally{clearTimeout(timer)}
}
function serviceUI(ready,why){serviceStatus=ready?'ready':'offline';
  const box=$('ev-service');if(!box)return;box.dataset.service=serviceStatus;
  $('ev-service-icon').textContent=ready?'✓':'!';$('ev-service-title').textContent=ready?'Statement OCR connected':'Statement OCR service unavailable';
  $('ev-service-desc').textContent=ready?'Local statement parser connected on port 8787. Upload a PDF or CSV statement.':(why||'Start the local OCR service on port 8787. Account Aggregator is not configured.');
  $('ev-service-open').hidden=ready;
  $('ev-check-service').textContent=ready?'Connected · recheck':'Retry connection';
}
async function checkService(){if(checking)return checking;
  $('ev-check-service')?.setAttribute('disabled','');
  checking=(async()=>{
   if(location.protocol==='file:'){serviceUI(false,'Opened as a file. Serve the website over HTTP and run the local OCR API on port 8787.');return false}
   if(!localHost){serviceUI(false,'No approved statement-processing API is configured for this website.');return false}
   const data=await healthPing(LOCAL_API);if(data){serviceUI(true);return true}
   serviceUI(false,'Local OCR service is not responding on port 8787. Start it and retry.');return false;
  })();try{return await checking}finally{checking=null;$('ev-check-service')?.removeAttribute('disabled')}
}

const people=()=>[{id:'primary',name:window.NamdevInstantApply?.applicantName||'',role:'Primary applicant'}];
const person=()=>people()[0];
const primary=()=>selected==='primary';
function blank(){return {filename:'',file:null,parsed:null,hasDoc:false,fields:{bank:'',holder:'',accountMasked:'',ifsc:'',type:''},aa:{step:0,account:'',selected:false,otp:'',consent:false,complete:false,live:false},bsa:{step:0,otp:'',consent:false,complete:false},events:[{title:'Banking stage opened',desc:'Ready to collect statement and consent.',at:'Now'}]}}
function state(){if(!store.has(selected))store.set(selected,blank());return store.get(selected)}
function audit(title,desc){state().events.unshift({title,desc,at:new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})});state().events.splice(12)}
function enter(id='primary'){selected=id;checkService();render();$('ev-party-title').textContent=person().name||'Primary applicant';window.scrollTo({top:0,behavior:'instant'})}
function back(){closePreview();window.NamdevInstantApply?.backToApplication?.()}
const names={aa:['Provider setup required','Account discovery','Customer authorization','Consent approval','Financial data fetch'],bsa:['Upload statement','Consent to analyze','OTP authorization','Analyze statement','Review result']};
const tips={aa:[['!','Account Aggregator unavailable','No licensed AA provider is configured. No consent request, account discovery, OTP or data fetch will be made.'],['·','Provider setup required','Account selection requires a licensed Account Aggregator provider.'],['·','Provider setup required','Customer OTP must use the provider-hosted authorization journey.'],['·','Provider setup required','Consent must be recorded by the licensed provider.'],['·','Provider setup required','Financial information is unavailable until an authorized provider is connected.']],bsa:[['⇧','Upload bank statement','Attach a PDF or CSV statement. It stays in this browser until you consent and confirm the demo authorization step.'],['☑','Customer authorizes analysis','Explicitly authorize the local prototype to process the uploaded statement.'],['◌','OTP authorization','This is a demonstration code only. No real SMS or customer authentication occurs.'],['▤','Analyze statement','Send the consented file to the local parser. It does not provide a validated BSA score or bank verification.'],['✓','Review extracted report','Review locally extracted statement metadata. These values are not bank verified.']]};
function stage(){return state()[flow]};
function setError(msg=''){const el=$('ev-error');el.textContent=msg;el.hidden=!msg}
function value(id,text){$(id).value=text||''}
function setFileNotice(message,err=false){$('ev-docnotice').innerHTML=`<span class="ev-circle">${err?'!':'i'}</span><span>${esc(message)}</span>`}
function render(){const s=state(),p=person(),st=stage(),data=s.parsed?.fields||{};
 $('ev-party-title').textContent=p.name||p.role; $('ev-party-role').textContent=(p.role||'Applicant').toUpperCase()+' · '+(primary()?'MANDATORY':'OPTIONAL');
 $('ev-uploadtitle').textContent=s.filename||'Drop statement or browse';$('ev-uploadsub').textContent=s.filename?(s.parsed?'Document parsed · not bank verified':s.failed?'Analysis failed · retry available':'Awaiting consent before local analysis'):'PDF / CSV · Maximum 20 MB';
 const f=s.fields;
 $('nf-banking').classList.toggle('ev-bsa-mode',flow==='bsa');
 value('ev-bank',f.bank);value('ev-holder',f.holder);value('ev-number',f.accountMasked);value('ev-ifsc',f.ifsc);value('ev-type',f.type);
 $('ev-fieldstate').textContent=s.parsed?`● Source: ${s.parsed.engine} · ${s.parsed.fieldCount} field(s) read · document only`:'● Source pending · not bank verified';
 $('ev-preview').disabled=!s.file;$('ev-retry').hidden=!s.file||!s.failed;$('ev-retry').disabled=!!s.parsing;
 const report=s.parsed?.analysis||{};
 $('ev-credits').textContent=report.totalCredits===null||report.totalCredits===undefined?'—':'₹'+report.totalCredits;
 $('ev-debits').textContent=report.totalDebits===null||report.totalDebits===undefined?'—':'₹'+report.totalDebits;
 $('ev-transactions').textContent=report.transactionCount===null||report.transactionCount===undefined?'—':String(report.transactionCount);
 $('ev-tab-aa').classList.toggle('active',flow==='aa');$('ev-tab-bsa').classList.toggle('active',flow==='bsa');$('ev-tab-aa').setAttribute('aria-selected',String(flow==='aa'));$('ev-tab-bsa').setAttribute('aria-selected',String(flow==='bsa'));
 $('ev-method').textContent=flow==='aa'?'ACCOUNT AGGREGATOR · CUSTOMER LED':'BANK STATEMENT ANALYZER · UPLOAD LED';
 $('ev-flowtitle').textContent=flow==='aa'?'Account Aggregator not configured':'Statement-led verification';
 $('ev-flowdesc').textContent=flow==='aa'?'No live AA requests can be made until a licensed provider is configured.':'Document extraction, customer authorization and evidence processing in one view.';
 $('ev-flowstatus').textContent=st.complete?'Demo walkthrough':'Step '+(st.step+1)+' of 5';
 $('ev-timeline').innerHTML=names[flow].map((n,i)=>`<div class="ev-time ${st.step>i?'done':st.step===i?'active':''}"><span class="ev-number">${i<st.step?'✓':i+1}</span><span>${esc(n)}</span></div>`).join('');
 const [ico,title,help]=tips[flow][Math.min(st.step,4)];let inner=`<div class="ev-stagetitle"><span class="ev-stageicon">${ico}</span><div><strong>${title}</strong><p>${help}</p></div></div>`;
 if(flow==='aa'){
  if(st.step===0)inner+='<div class="ev-docnotice"><span class="ev-circle">!</span><span>No licensed Account Aggregator provider is configured. No account discovery, consent request, OTP or bank-data fetch can be performed here. Use Statement Analyzer only with an authorized local test document.</span></div>';
  if(st.step===0)inner+='<div class="ev-chiplist"><span class="ev-chip">Purpose · MSME loan appraisal</span><span class="ev-chip">Requested · account transaction data</span><span class="ev-chip">Consent can be revoked</span></div>';
  if(st.step===1)inner+='<div class="ev-docnotice"><span class="ev-circle">!</span><span>Account selection is unavailable until a licensed AA provider is configured.</span></div>';
  if(st.step===2)inner+=otpHTML();
  if(st.step===3)inner+=`<label class="ev-checklabel"><input type="checkbox" id="ev-consent" ${st.consent?'checked':''}/> <span>I consent to share the selected bank account data for this MSME loan assessment. This prototype does not create an enforceable AA consent artifact.</span></label>`;
  if(st.step===4)inner+=`<div class="ev-chiplist"><span class="ev-chip">Selected bank: ${esc(st.account||'None')}</span><span class="ev-chip">OTP demo complete</span><span class="ev-chip">Real FIU API required</span></div>`;
 }else{
  if(st.step===0)inner+=`<div class="ev-chiplist"><span class="ev-chip">${s.filename?esc(s.filename):'No statement uploaded yet'}</span><span class="ev-chip">PDF or CSV</span></div>`;
  if(st.step===1)inner+=`<label class="ev-checklabel"><input type="checkbox" id="ev-consent" ${st.consent?'checked':''}/> <span>I authorize analysis of the uploaded statement for the purpose of the MSME loan application. The document remains locally processed for this prototype.</span></label>`;
  if(st.step===2)inner+=otpHTML();
  if(st.step===3)inner+=`<div class="ev-chiplist"><span class="ev-chip">${s.filename?esc(s.filename):'No file'}</span><span class="ev-chip">Consent recorded (demo)</span><span class="ev-chip">Parse locally</span></div>`;
  if(st.step===4)inner+=`<div class="ev-chiplist"><span class="ev-chip">${s.parsed?.fieldCount??0} field(s) extracted</span><span class="ev-chip">Account data locked</span><span class="ev-chip">No bureau/BSA score fabricated</span></div>`;
 }
 $('ev-stage').innerHTML=inner;
 const button=({aa:['No live AA provider connected','Continue with chosen bank →','Verify demo OTP →','Approve demo consent →','Request AA data →'],bsa:['Select statement →','Send demo OTP →','Verify demo OTP →','Analyze uploaded statement →','View source summary →']})[flow][Math.min(st.step,4)];
 $('ev-continue').innerHTML=button;$('ev-continue').disabled=!!st.complete||(flow==='aa'&&st.step===0);
 $('ev-hint').textContent=flow==='aa'?'Live Account Aggregator integration is not configured.':st.step===2?'Demo OTP: 123456 · No SMS sent':'Prototype steps are labeled · no live AA credentials';
 $('ev-aa-status').textContent=s.aa.complete?'Demo complete · no FI fetched':s.aa.step?'In progress · step '+(s.aa.step+1):'Awaiting consent';
 $('ev-bsa-status').textContent=s.bsa.complete?'Statement extracted · unverified':s.bsa.step?'In progress · step '+(s.bsa.step+1):'Awaiting statement';
 $('ev-integrity-status').textContent=s.parsed?'Document parsed · not verified':'Source pending';
 $('ev-log').innerHTML=s.events.map(e=>`<div class="ev-logitem"><div class="ev-logmark">✓</div><div><strong>${esc(e.title)}</strong><small>${esc(e.at)} · ${esc(e.desc)}</small></div></div>`).join('');
 $('ev-skip').hidden=primary();$('ev-save').disabled=primary()&&!s.bsa.complete&&!s.aa.live;
 $('ev-save').textContent=primary()?'View local demo summary →':'Continue application →';
 $('ev-save-hint').textContent=primary()?'Local walkthrough only: this does not submit an application or verify bank data.':'Optional banking for this party; you can skip with a pending obligation.';
}
function otpHTML(){return '<div class="ev-otp" aria-label="Demo one-time password">'+Array.from({length:6},(_,i)=>`<input type="text" inputmode="numeric" maxlength="6" aria-label="Digit ${i+1}" data-otp="${i}" autocomplete="one-time-code"/>`).join('')+'</div><div class="ev-chiplist"><span class="ev-chip">Demo OTP · 123456</span><span class="ev-chip">Do not enter real OTP</span></div>'}
function fileSelected(f){if(!f)return;setError('');if(!/\.(pdf|csv)$/i.test(f.name)){setError('Upload a valid PDF or CSV statement.');return}if(f.size>20*1024*1024){setError('Statement must be 20 MB or smaller.');return}
 const s=state();s.file=f;s.filename=f.name;s.parsed=null;s.parsing=false;s.failed=false;s.fields={bank:'',holder:'',accountMasked:'',ifsc:'',type:''};s.bsa.step=0;s.bsa.consent=false;s.bsa.complete=false;
 if(fileURL)URL.revokeObjectURL(fileURL);fileURL=URL.createObjectURL(f);
 audit('Statement selected',f.name+' · held in browser memory; not sent before consent');setFileNotice('Statement is held in this browser. It is sent to the local parser only after consent and the demo authorization step.');render();}
async function next(){const s=state(),st=stage();setError('');if(st.complete)return;
 if(flow==='aa'){
  setError('A licensed Account Aggregator provider is not configured. No account, consent or OTP request can be completed here.');
  return;
 }else{
  if(st.step===0){if(!s.file){$('ev-file').click();setError('Upload a statement before continuing.');return}st.step=1;audit('Statement awaiting authorization','No file data has been sent for processing');setFileNotice('Statement is held in this browser until consent and the demo authorization step are complete.')}
  else if(st.step===1){if(!$('ev-consent')?.checked){setError('Customer must authorize statement analysis.');return}st.consent=true;st.step=2;audit('Statement consent recorded','Demo acknowledgment · OTP requested')}
  else if(st.step===2){if(!readOTP()){setError('Enter the six-digit demo OTP (123456).');return}st.step=3;audit('Statement OTP demo verified','No real SMS sent')}
  else if(st.step===3){if(!s.file||!st.consent){setError('Select a statement and authorize processing before analysis.');return}s.parsing=true;s.failed=false;$('ev-continue').disabled=true;$('ev-continue').textContent='Analyzing evidence…';try{const fd=new FormData();fd.append('file',s.file);fd.append('consent','true');const data=await fetchJSON('/api/banking/bsa/analyze',{method:'POST',body:fd});s.parsed=data;s.fields={bank:'',holder:'',accountMasked:'',ifsc:'',type:'',...data.fields};s.parsing=false;st.step=4;st.complete=true;const stats=data.analysis||{};audit('Statement source parsed',`${data.fieldCount} account field(s); ${stats.confidence||'No scoring from this source.'}`);setFileNotice('Statement parsed locally. Values are extracted from the document and are not bank verified.')}catch(e){s.parsing=false;s.failed=true;setFileNotice('The consented analysis did not complete. The document remains in this browser; retry when the local API is available.',true);setError('BSA analysis is pending: '+issueText(e));audit('Analysis pending',issueText(e));checkService()}}
  else {st.complete=true}
 }
 render()}
function readOTP(){const nodes=Array.from(document.querySelectorAll('#ev-stage [data-otp]'));return nodes.map(n=>n.value).join('').replace(/\D/g,'')==='123456'}
function attachAutoOTP(){document.addEventListener('input',e=>{if(!e.target.matches('#ev-stage [data-otp]'))return;const inp=Array.from(document.querySelectorAll('#ev-stage [data-otp]')),i=inp.indexOf(e.target),digits=e.target.value.replace(/\D/g,'');if(digits.length>1){digits.slice(0,6).split('').forEach((d,n)=>{if(inp[i+n])inp[i+n].value=d})}else e.target.value=digits;inp[Math.min(5,i+(digits.length||0))]?.focus()})}
function attach(){
 $('ev-back').addEventListener('click',back);$('ev-check-service').addEventListener('click',checkService);$('ev-retry').addEventListener('click',async()=>{setError('');setFileNotice('Retrying the consented statement analysis…');await checkService();await next()});$('ev-tab-aa').addEventListener('click',()=>{flow='aa';setError('');render()});$('ev-tab-bsa').addEventListener('click',()=>{flow='bsa';setError('');render()});$('ev-continue').addEventListener('click',next);$('ev-file').addEventListener('change',e=>{fileSelected(e.target.files?.[0]);e.target.value=''});$('ev-browse').addEventListener('click',e=>{e.stopPropagation();$('ev-file').click()});$('ev-replace').addEventListener('click',()=>$('ev-file').click());const drop=$('ev-drop');drop.addEventListener('click',e=>{if(e.target.closest('button'))return;$('ev-file').click()});drop.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('ev-file').click()}});for(const kind of ['dragenter','dragover'])drop.addEventListener(kind,e=>{e.preventDefault();drop.classList.add('drag')});for(const kind of ['dragleave','drop'])drop.addEventListener(kind,e=>{e.preventDefault();drop.classList.remove('drag')});drop.addEventListener('drop',e=>fileSelected(e.dataTransfer?.files?.[0]));
 $('ev-stage').addEventListener('change',e=>{if(e.target.id==='ev-consent')stage().consent=e.target.checked});attachAutoOTP();
 $('ev-preview').addEventListener('click',()=>{const s=state();if(!s.file)return;const v=$('ev-preview-body');v.replaceChildren();if(s.file.name.toLowerCase().endsWith('.pdf')){const i=document.createElement('iframe');i.src=fileURL;i.title='Uploaded statement PDF';v.appendChild(i)}else{const pre=document.createElement('pre');pre.textContent='Reading...';v.appendChild(pre);s.file.text().then(t=>{pre.textContent=t.slice(0,50000)});} $('ev-preview-title').textContent=s.filename;$('ev-preview-overlay').hidden=false});$('ev-close-preview').addEventListener('click',closePreview);$('ev-preview-overlay').addEventListener('click',e=>{if(e.target===$('ev-preview-overlay'))closePreview()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closePreview()});
 $('ev-skip').addEventListener('click',()=>{if(primary())return;audit('Banking skipped','Optional party · outstanding verification obligation');back()});$('ev-save').addEventListener('click',()=>{if(primary()&&!state().bsa.complete&&!state().aa.live)return;const detail={partyId:selected,role:person().role,statementParsed:!!state().parsed,bsaDemoComplete:state().bsa.complete,aaDemoComplete:state().aa.complete,aaLiveComplete:state().aa.live,verifiedByProvider:false};window.dispatchEvent(new CustomEvent('namdev:banking-journey-complete',{detail}));window.NamdevInstantApply?.completeBanking?.(detail)});
 render()}
function closePreview(){$('ev-preview-overlay').hidden=true}
window.NamdevBanking={openForParty:enter,reset(){if(fileURL)URL.revokeObjectURL(fileURL);fileURL=null;store.clear();selected='primary';flow='aa';render()},viewState:()=>({partyId:selected,extractedBankFields:{...state().fields},bsa:state().bsa,aa:state().aa,sourceProviderVerified:false})};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',attach);else attach();
})();
