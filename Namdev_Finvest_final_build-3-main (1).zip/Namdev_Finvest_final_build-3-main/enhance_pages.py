import re

# Read the standard header from about.html so we don't have to hardcode the whole thing again
with open('about.html', 'r') as f:
    content = f.read()
    # Extract everything up to the first <section class="hero-quantum">
    header_part = content.split('<section class="hero-quantum"')[0]
    
# Extract the footer
    footer_part = '<footer class="quantum-footer">' + content.split('<footer class="quantum-footer">')[1]

def create_page(filename, body_content):
    with open(filename, 'w') as f:
        f.write(header_part + body_content + footer_part)
    print(f"Enhanced {filename}")

# 1. ABOUT PAGE (Added IDs for Management, Profile Images, Hero Image)
about_body = """
    <section class="hero-quantum" id="who-we-are" style="justify-content: center; align-items: center; text-align: center; min-height: 50vh; padding-top: 140px; position: relative; overflow: hidden;">
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.2;">
        <img src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=1600&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">
      </div>
      <div class="hero-grid" style="width: 100%; display: block; z-index: 1;">
        <div class="hero-content-col" style="margin: 0 auto; max-width: 900px;">
          <div class="hero-badge-row" style="justify-content: center;">
            <span class="badge-quantum">ESTABLISHED 2013</span>
          </div>
          <h1 class="hero-headline">Empowering Rural Bharat.</h1>
          <p class="hero-lead">Namdev Finvest Limited is a fast-growing RBI-registered NBFC dedicated to driving financial inclusion across India's underbanked sectors. With AUM crossing ₹1,200 Cr, we specialize in MSME, Green Finance, and Asset-backed lending.</p>
        </div>
      </div>
    </section>

    <section class="section-stage" id="board">
      <div class="container">
        <h2 style="text-align:center; font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px;">Board of Directors</h2>
        <div class="content-grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
          <div class="info-card" style="text-align: center;">
            <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=400&q=80" style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; margin: 0 auto 20px; border: 3px solid var(--brand);">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Jitendra Tanwar</h3>
            <p style="color: var(--brand); font-size: 0.9rem; font-weight:bold;">Managing Director & CEO</p>
            <p style="margin-top: 15px; font-size: 0.9rem;">Visionary leader driving Namdev's mission to bridge the credit gap in semi-urban geographies.</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80" style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; margin: 0 auto 20px; border: 3px solid var(--border);">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Independent Directors</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem; font-weight:bold;">Corporate Governance</p>
            <p style="margin-top: 15px; font-size: 0.9rem;">Distinguished veterans from banking and regulatory sectors ensuring the highest standards of ESG.</p>
          </div>
        </div>
      </div>
    </section>
    
    <section class="section-stage" id="management" style="background: var(--bg-surface);">
      <div class="container">
        <h2 style="text-align:center; font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px;">Core Management Team</h2>
        <div class="content-grid">
          <div class="info-card" style="display: flex; gap: 20px; align-items: center;">
            <img src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80" style="width: 80px; height: 80px; border-radius: 12px; object-fit: cover;">
            <div>
              <h3 style="font-size:1.2rem; margin-bottom:5px;">Credit & Underwriting</h3>
              <p style="font-size: 0.9rem;">Ensuring robust risk assessment and rapid decision intelligence.</p>
            </div>
          </div>
          <div class="info-card" style="display: flex; gap: 20px; align-items: center;">
            <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=200&q=80" style="width: 80px; height: 80px; border-radius: 12px; object-fit: cover;">
            <div>
              <h3 style="font-size:1.2rem; margin-bottom:5px;">Operations & Tech</h3>
              <p style="font-size: 0.9rem;">Delivering a seamless 10-minute digital lending experience.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
"""
create_page('about.html', about_body)

# 2. INVESTOR PAGE (Added proper anchor IDs for policies, reports. Added imagery.)
investor_body = """
    <section class="hero-quantum" id="partners" style="justify-content: center; align-items: center; text-align: center; min-height: 50vh; padding-top: 140px; position: relative; overflow: hidden;">
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.15;">
        <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">
      </div>
      <div class="hero-grid" style="width: 100%; display: block; z-index: 1;">
        <div class="hero-content-col" style="margin: 0 auto; max-width: 900px;">
          <div class="hero-badge-row" style="justify-content: center;">
            <span class="badge-quantum">CAPITAL PARTNERS</span>
          </div>
          <h1 class="hero-headline">Growth & Investors.</h1>
          <p class="hero-lead">Namdev Finvest is backed by globally respected institutional investors and development finance institutions. We recently raised $19 Million in Pre-Series C funding led by Maj Invest.</p>
        </div>
      </div>
    </section>

    <section class="section-stage">
      <div class="container">
        <div class="content-grid">
          <div class="info-card" style="text-align: center; position: relative; overflow: hidden;">
            <div style="height: 100px; background: url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=400&q=80') center/cover; margin: -30px -30px 20px; opacity: 0.8;"></div>
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Maj Invest</h3>
            <p>Lead Investor - Pre-Series C</p>
          </div>
          <div class="info-card" style="text-align: center; position: relative; overflow: hidden;">
            <div style="height: 100px; background: url('https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=400&q=80') center/cover; margin: -30px -30px 20px; opacity: 0.8;"></div>
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Incofin</h3>
            <p>Global Impact Investment</p>
          </div>
          <div class="info-card" style="text-align: center; position: relative; overflow: hidden;">
            <div style="height: 100px; background: url('https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80') center/cover; margin: -30px -30px 20px; opacity: 0.8;"></div>
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">BII</h3>
            <p>British International Investment</p>
          </div>
          <div class="info-card" style="text-align: center; position: relative; overflow: hidden;">
            <div style="height: 100px; background: url('https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=400&q=80') center/cover; margin: -30px -30px 20px; opacity: 0.8;"></div>
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">FMO & IIX</h3>
            <p>Development Finance Partners</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section-stage" id="disclosures" style="background: var(--bg-surface);">
      <div class="container">
        <h2 style="font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px;">Disclosures & ESG</h2>
        <div class="content-grid" style="grid-template-columns: 1fr 1fr;">
          <div class="info-card" id="esg" style="display: flex; flex-direction: column; justify-content: center;">
            <span style="font-size: 2rem; margin-bottom: 10px;">🌱</span>
            <h3 style="font-size:1.5rem; margin-bottom:10px;">ESG Commitment</h3>
            <p>Namdev Finvest Pvt. Ltd. earned the GOLD-level Client Protection certification from MFR for its high standards in social and environmental performance.</p>
          </div>
          <div class="info-card" id="financials">
            <span style="font-size: 2rem; margin-bottom: 10px;">📈</span>
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Financial Performance</h3>
            <p>AUM crossed ₹1,200 Cr mark in FY24. Successfully raised USD 37 million (324 crore) from globally respected partners through listed NCDs and ECB structures.</p>
          </div>
          
          <div class="info-card" id="policies">
            <h3 style="font-size:1.2rem; margin-bottom:10px;">Codes and Policies</h3>
            <p style="font-size:0.9rem;">Fair Practice Code, Grievance Redressal, and operational transparency protocols.</p>
          </div>
          <div class="info-card" id="reports">
            <h3 style="font-size:1.2rem; margin-bottom:10px;">Annual Reports</h3>
            <p style="font-size:0.9rem;">Comprehensive breakdown of yearly financial audits and growth trajectories.</p>
          </div>
          <div class="info-card" id="rta">
            <h3 style="font-size:1.2rem; margin-bottom:10px;">RTA, DT & GRO</h3>
            <p style="font-size:0.9rem;">Registrar & Transfer Agent details and Debenture Trustee contacts.</p>
          </div>
        </div>
      </div>
    </section>
"""
create_page('investor.html', investor_body)

# 3. TEAM PAGE (Added proper gallery and team images)
team_body = """
    <section class="hero-quantum" id="culture" style="justify-content: center; align-items: center; text-align: center; min-height: 50vh; padding-top: 140px; position: relative; overflow: hidden;">
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.3;">
        <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1600&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%) contrast(1.2);">
      </div>
      <div class="hero-grid" style="width: 100%; display: block; z-index: 1;">
        <div class="hero-content-col" style="margin: 0 auto; max-width: 900px;">
          <div class="hero-badge-row" style="justify-content: center;">
            <span class="badge-quantum">LIFE AT NAMDEV</span>
          </div>
          <h1 class="hero-headline">Build the Future of Finance.</h1>
          <p class="hero-lead" style="color: #fff; font-weight: 500;">Join a dynamic team of over 1,000+ professionals spread across 137+ branches in Rajasthan, Gujarat, MP, Punjab, and Delhi NCR. We are mechanizing Bharat and funding green transitions.</p>
        </div>
      </div>
    </section>

    <section class="section-stage" id="gallery">
      <div class="container">
        <h2 style="font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 20px; text-align: center;">Culture & Impact</h2>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 40px;">
          <img src="https://images.unsplash.com/photo-1542744094-24638ea0b3b5?auto=format&fit=crop&w=600&q=80" style="width:100%; height:250px; object-fit:cover; border-radius: 12px;">
          <img src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=600&q=80" style="width:100%; height:250px; object-fit:cover; border-radius: 12px;">
          <img src="https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=600&q=80" style="width:100%; height:250px; object-fit:cover; border-radius: 12px;">
        </div>
        
        <div class="content-grid" id="careers">
          <div class="info-card" style="border-color: var(--brand);">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Careers at Namdev</h3>
            <p style="margin-bottom: 25px;">We are always looking for ambitious Credit Managers, Branch Managers, and Technology experts.</p>
            <a href="https://namdevcareers.peoplestrong.com/" target="_blank" class="btn-quantum" style="text-decoration:none; padding:10px 20px; font-size:0.9rem;">View Open Roles</a>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Employee Testimonials</h3>
            <p>Hear directly from our branch leaders and credit officers about their rapid career growth journeys within Namdev Finvest.</p>
          </div>
        </div>
      </div>
    </section>
"""
create_page('team.html', team_body)

# 4. CONTACT PAGE (Added Map/Building aesthetic)
contact_body = """
    <section class="hero-quantum" id="support" style="justify-content: center; align-items: center; text-align: center; min-height: 50vh; padding-top: 140px; position: relative; overflow: hidden;">
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.15;">
        <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1600&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">
      </div>
      <div class="hero-grid" style="width: 100%; display: block; z-index: 1;">
        <div class="hero-content-col" style="margin: 0 auto; max-width: 900px;">
          <div class="hero-badge-row" style="justify-content: center;">
            <span class="badge-quantum">24/7 SUPPORT</span>
          </div>
          <h1 class="hero-headline">Contact Us.</h1>
          <p class="hero-lead">Whether you need a new loan, support with your EMI, or want to locate your nearest branch, our team is ready to assist you.</p>
        </div>
      </div>
    </section>

    <section class="section-stage">
      <div class="container">
        <div class="content-grid" style="grid-template-columns: 1fr 1fr;">
          <div class="info-card" style="position: relative; overflow: hidden;">
            <div style="position: absolute; top: 0; right: 0; width: 150px; height: 150px; background: radial-gradient(circle, var(--brand) 0%, transparent 70%); opacity: 0.1; filter: blur(20px);"></div>
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Corporate Headquarters</h3>
            <div style="display: flex; gap: 15px; margin-bottom: 25px;">
              <span style="font-size: 1.5rem;">📍</span>
              <div>
                <p style="font-size: 1.1rem; margin-bottom: 5px;">"Namdev House", Plot No. 21</p>
                <p style="font-size: 1.1rem; margin-bottom: 5px;">Neer Sagar-A, Bhankrota</p>
                <p style="font-size: 1.1rem;">Jaipur, Rajasthan - 302026</p>
              </div>
            </div>
            
            <div style="display: flex; gap: 15px; margin-bottom: 25px;">
              <span style="font-size: 1.5rem;">📞</span>
              <div>
                <h4 style="color: var(--text-muted); margin-bottom: 5px; font-size: 0.8rem;">Toll Free</h4>
                <p style="font-size: 1.5rem; font-weight: bold;">1800-103-5800</p>
              </div>
            </div>
            
            <div style="display: flex; gap: 15px;">
              <span style="font-size: 1.5rem;">✉️</span>
              <div>
                <h4 style="color: var(--text-muted); margin-bottom: 5px; font-size: 0.8rem;">Email</h4>
                <p style="font-size: 1.2rem; font-weight: bold;">info@namfin.in</p>
              </div>
            </div>
          </div>
          
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">137+ Branches Across India</h3>
            <p style="margin-bottom: 20px;">We are expanding rapidly to serve you better. Find us in:</p>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Rajasthan</div>
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Gujarat</div>
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Madhya Pradesh</div>
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Punjab</div>
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Haryana</div>
              <div style="background: var(--bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border); text-align: center; font-weight: bold;">Delhi NCR</div>
            </div>
          </div>
        </div>
      </div>
    </section>
"""
create_page('contact.html', contact_body)

