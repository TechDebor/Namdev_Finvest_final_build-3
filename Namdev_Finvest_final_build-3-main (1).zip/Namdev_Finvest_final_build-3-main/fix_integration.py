import re

# 1. Update los-bre-engine.html
with open('los-bre-engine.html', 'r') as f:
    los = f.read()

# Add a button to open namfindesk
new_header = """<div class="sub">CRM &rarr; LOS &rarr; BRE &rarr; Exceptions &rarr; Disbursement</div></div>
<button class="btn green" style="font-weight: 800;" onclick="window.open('namfindesk.html', '_blank')">💻 Open Namfindesk CRM</button>
<span class="badge">"""

los = los.replace('<div class="sub">CRM → LOS → BRE → Exceptions → Disbursement</div></div><span class="badge">', new_header)

# Save state to localStorage when run finishes
save_logic = """
    localStorage.setItem('namfin_bre_issues', JSON.stringify(issues));
    localStorage.setItem('namfin_customer', JSON.stringify({
        name: $('name').value,
        product: $('product').value,
        amount: $('amount').value
    }));
    addLog(issues.some(x=>!x.resolved)?'HOLD: deviation remediation required before controlled next stage':'RULE RUN COMPLETE: ready for delegated decision review',issues.length?'r':'g');
"""
los = los.replace("addLog(issues.some(x=>!x.resolved)?'HOLD: deviation remediation required before controlled next stage':'RULE RUN COMPLETE: ready for delegated decision review',issues.length?'r':'g');", save_logic)

with open('los-bre-engine.html', 'w') as f:
    f.write(los)

# 2. Update namfindesk.html to read from localStorage
with open('namfindesk.html', 'r') as f:
    desk = f.read()

# Replace the hardcoded appState logic with dynamic localStorage logic
desk_js_old = """let appState = {
      appId: "APP-982734",
      customer: "Aarav Sharma",
      product: "Loan Against Property",
      amount: "₹40,00,000",
      tasks: {
        ops: { id: "EXC-001", title: "KYC Mismatch", desc: "PAN Card name (Aarav K. Sharma) does not match entered name.", resolved: false },
        rcu: { id: "EXC-002", title: "Dedupe Match Flag", desc: "Partial match found in Defaulter Database. Verify Father's Name.", resolved: false },
        legal: { id: "EXC-003", title: "Title Search Pending", desc: "Upload Clear Title Search Report (TSR) for mortgaged property.", resolved: false },
        credit: { id: "EXC-004", title: "High FOIR (>55%)", desc: "Existing EMIs push obligation ratio above policy limits. Review BSA.", resolved: false },
        do: { id: "DISB-001", title: "Ready for Disbursal", desc: "All departments have cleared holds. Push to Loan Management System.", resolved: false }
      }
    };"""

desk_js_new = """
    function getAppState() {
      let issues = JSON.parse(localStorage.getItem('namfin_bre_issues') || '[]');
      let customer = JSON.parse(localStorage.getItem('namfin_customer') || '{"name":"Aarav", "product":"Loan", "amount":"300000"}');
      
      let resolvedRoles = JSON.parse(localStorage.getItem('namfin_resolved_roles') || '{"ops":false,"rcu":false,"legal":false,"credit":false,"do":false}');

      let tasks = {
        ops: { id: "EXC-KYC", title: "KYC & Identity Review", desc: "Action required on Customer Identity or Document verification.", resolved: resolvedRoles.ops },
        rcu: { id: "EXC-RCU", title: "Compliance & Risk Check", desc: "Action required on Dedupe, AML, or Risk flags.", resolved: resolvedRoles.rcu },
        legal: { id: "EXC-LGL", title: "Technical/Legal Check", desc: "Action required on Asset Valuation or Legal Title Search.", resolved: resolvedRoles.legal },
        credit: { id: "EXC-CRD", title: "Credit & Affordability", desc: "Action required on FOIR, Bureau, or Cashflow limits.", resolved: resolvedRoles.credit },
        do: { id: "DISB-001", title: "Ready for Disbursal", desc: "All departments have cleared holds. Push to Loan Management System.", resolved: resolvedRoles.do }
      };

      // Determine if a role ACTUALLY has a task based on BRE output
      // If the BRE generated specific exceptions, we enforce them.
      let hasOps = issues.some(i => i.department.includes("KYC"));
      let hasRCU = issues.some(i => i.department.includes("Compliance"));
      let hasLegal = issues.some(i => i.department.includes("Technical") || i.department.includes("Legal"));
      let hasCredit = issues.some(i => i.department.includes("Credit"));
      
      // If BRE didn't flag this role, auto-resolve it in our UI so they don't block the DO
      if (!hasOps && issues.length > 0) tasks.ops.resolved = true;
      if (!hasRCU && issues.length > 0) tasks.rcu.resolved = true;
      if (!hasLegal && issues.length > 0) tasks.legal.resolved = true;
      if (!hasCredit && issues.length > 0) tasks.credit.resolved = true;

      // If NO issues at all (clean run), everything is resolved except DO
      if (issues.length === 0) {
        tasks.ops.resolved = true; tasks.rcu.resolved = true; tasks.legal.resolved = true; tasks.credit.resolved = true;
      }

      return {
        appId: "APP-" + Math.floor(100000 + Math.random() * 900000),
        customer: customer.name,
        product: customer.product,
        amount: "₹" + parseInt(customer.amount).toLocaleString('en-IN'),
        tasks: tasks
      };
    }
    
    let appState = getAppState();
    
    // Add event listener to auto-refresh if localStorage changes
    window.addEventListener('storage', () => {
        appState = getAppState();
        if(currentUserRole) renderTasks();
    });
"""

desk = desk.replace(desk_js_old, desk_js_new)

# Update resolve task logic in namfindesk to save to localStorage
resolve_old = """appState.tasks[currentTaskToResolve].resolved = true;
      closeModal();
      renderTasks();"""
      
resolve_new = """appState.tasks[currentTaskToResolve].resolved = true;
      let resolvedRoles = JSON.parse(localStorage.getItem('namfin_resolved_roles') || '{"ops":false,"rcu":false,"legal":false,"credit":false,"do":false}');
      resolvedRoles[currentTaskToResolve] = true;
      localStorage.setItem('namfin_resolved_roles', JSON.stringify(resolvedRoles));
      
      closeModal();
      renderTasks();"""
      
desk = desk.replace(resolve_old, resolve_new)

with open('namfindesk.html', 'w') as f:
    f.write(desk)

