(() => {
  'use strict';

  const localeCodes = new Set(['en', 'hi', 'mr', 'gu', 'ur', 'pa', 'or']);
  const dictionaryVersion = '20261014-i18n5';
  const languageNames = {
    en: 'English',
    hi: 'हिंदी',
    mr: 'मराठी',
    gu: 'ગુજરાતી',
    ur: 'اردو',
    pa: 'ਪੰਜਾਬੀ',
    or: 'ଓଡ଼ିଆ'
  };
  const runtimeUrl = document.currentScript?.src || new URL('js/i18n.js', document.baseURI).href;
  const localeUrl = (locale) => {
    const url = new URL(`../locales/${locale}.json`, runtimeUrl);
    url.searchParams.set('v', dictionaryVersion);
    return url;
  };
  const dictionaries = new Map();
  const originalText = new WeakMap();
  const originalAttributes = new WeakMap();
  let currentLocale = 'en';
  let englishDictionary;
  let englishTextKeys;
  let observer;

  const normalize = (value) => value.replace(/\s+/g, ' ').trim();

  const loadDictionary = async (locale) => {
    if (dictionaries.has(locale)) return dictionaries.get(locale);
    const response = await fetch(localeUrl(locale), { credentials: 'same-origin' });
    if (!response.ok) {
      throw new Error(`Could not load ${locale} translations (${response.status}).`);
    }
    const dictionary = await response.json();
    if (!dictionary || Array.isArray(dictionary) || typeof dictionary !== 'object') {
      throw new Error(`The ${locale} translation file is not a valid dictionary.`);
    }
    dictionaries.set(locale, dictionary);
    return dictionary;
  };

  const buildEnglishTextIndex = (dictionary) => {
    const values = new Map();
    Object.entries(dictionary).forEach(([key, value]) => {
      if (typeof value !== 'string' || !value.trim()) return;
      const text = normalize(value);
      const keys = values.get(text) || [];
      keys.push(key);
      values.set(text, keys);
    });
    return values;
  };

  const findKeyForText = (text, element) => {
    const explicitKey = element?.closest('[data-i18n]')?.getAttribute('data-i18n');
    if (explicitKey) return explicitKey;
    const candidates = englishTextKeys.get(normalize(text));
    if (!candidates?.length) return null;
    if (candidates.length === 1) return candidates[0];
    const translated = new Set(candidates.map((key) => dictionaries.get(currentLocale)?.[key]));
    return translated.size === 1 ? candidates[0] : null;
  };

  const translateTextNode = (node, dictionary) => {
    const parent = node.parentElement;
    if (!parent || parent.closest('script, style, noscript, textarea, code, [data-i18n-ignore]')) return;
    if (parent.closest('[data-language], [onclick*="switchLanguage("]')) return;
    if (!originalText.has(node)) originalText.set(node, node.nodeValue);
    const source = originalText.get(node);
    const key = findKeyForText(source, parent);
    const translated = key && dictionary[key];
    if (typeof translated !== 'string') return;
    const leadingWhitespace = source.match(/^\s*/)?.[0] || '';
    const trailingWhitespace = source.match(/\s*$/)?.[0] || '';
    node.nodeValue = `${leadingWhitespace}${translated}${trailingWhitespace}`;
  };

  const translatedValue = (source, element, attribute, dictionary) => {
    const explicitKey = element.getAttribute(`data-i18n-${attribute}`);
    const key = explicitKey || findKeyForText(source, element);
    return key && typeof dictionary[key] === 'string' ? dictionary[key] : null;
  };

  const translateAttributes = (element, dictionary) => {
    ['placeholder', 'aria-label', 'title'].forEach((attribute) => {
      if (!element.hasAttribute(attribute)) return;
      let sources = originalAttributes.get(element);
      if (!sources) {
        sources = new Map();
        originalAttributes.set(element, sources);
      }
      if (!sources.has(attribute)) sources.set(attribute, element.getAttribute(attribute));
      const translated = translatedValue(sources.get(attribute), element, attribute, dictionary);
      if (translated !== null) element.setAttribute(attribute, translated);
    });
  };

  const translateTree = (root, dictionary) => {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) translateTextNode(node, dictionary);
    const elements = root.nodeType === Node.ELEMENT_NODE ? [root, ...root.querySelectorAll('*')] : [];
    elements.forEach((element) => translateAttributes(element, dictionary));
  };

  const updateLanguageControls = (locale, dictionary) => {
    document.querySelectorAll('[data-language], [onclick*="switchLanguage("]').forEach((link) => {
      const language = link.dataset.language
        || link.getAttribute('onclick')?.match(/switchLanguage\(['"]([a-z]{2})['"]\)/)?.[1];
      if (!language) return;
      link.dataset.language = language;
      link.setAttribute('aria-current', language === locale ? 'true' : 'false');
    });
    const languageButton = document.querySelector('[data-language-control]');
    if (languageButton) {
      languageButton.setAttribute('aria-label', dictionary['language.select'] || 'Change Language');
      languageButton.setAttribute('title', languageNames[locale]);
    }
    const careerSelect = document.getElementById('careerLanguageSelect');
    if (careerSelect) {
      careerSelect.value = locale;
      careerSelect.setAttribute('aria-label', dictionary['language.select'] || 'Change Language');
    }
    document.querySelectorAll('.mobile-language-picker summary').forEach((summary) => {
      summary.textContent = dictionary['language.select'] || 'Language';
    });
  };

  const applyLocale = async (locale, persist) => {
    const nextLocale = localeCodes.has(locale) ? locale : 'en';
    const dictionary = await loadDictionary(nextLocale);
    const missingKeys = Object.keys(englishDictionary).filter((key) => !(key in dictionary));

    currentLocale = nextLocale;
    document.documentElement.lang = nextLocale;
    document.documentElement.dir = nextLocale === 'ur' ? 'rtl' : 'ltr';
    translateTree(document.body, dictionary);
    updateLanguageControls(nextLocale, dictionary);
    if (persist) localStorage.setItem('namfin_language', nextLocale);

    const coverage = window.namfinI18n?.getCoverage?.();
    if (missingKeys.length) {
      console.warn(`[i18n] ${nextLocale} is missing ${missingKeys.length} dictionary keys.`, missingKeys);
    }
    document.dispatchEvent(new CustomEvent('namfin:languagechange', {
      detail: { locale: nextLocale, language: nextLocale, direction: document.documentElement.dir, coverage }
    }));
    return nextLocale;
  };

  window.namfinI18n = {
    get language() {
      return currentLocale;
    },
    get supportedLanguages() {
      return Array.from(localeCodes);
    },
    getCoverage() {
      const textNodes = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (!node.parentElement?.closest('script, style, noscript, textarea, code, [data-i18n-ignore]')) {
          textNodes.push(node);
        }
      }
      const eligible = textNodes.filter((textNode) =>
        findKeyForText(originalText.get(textNode) || textNode.nodeValue, textNode.parentElement)
      );
      const untranslatedExamples = textNodes
        .filter((textNode) => {
          const value = normalize(originalText.get(textNode) || textNode.nodeValue);
          return value && !findKeyForText(value, textNode.parentElement);
        })
        .slice(0, 20)
        .map((textNode) => normalize(originalText.get(textNode) || textNode.nodeValue));
      return {
        translatableNodes: eligible.length,
        pageTextNodes: textNodes.length,
        untranslatedNodes: textNodes.length - eligible.length,
        untranslatedExamples
      };
    }
  };

  window.switchLanguage = (locale) => applyLocale(locale, true).catch((error) => {
    console.error('[i18n] Language change failed.', error);
    return false;
  });

  const initialize = async () => {
    try {
      englishDictionary = await loadDictionary('en');
      englishTextKeys = buildEnglishTextIndex(englishDictionary);
      const savedLocale = localStorage.getItem('namfin_language') || 'en';
      await applyLocale(savedLocale, false);
      observer = new MutationObserver((records) => {
        const dictionary = dictionaries.get(currentLocale);
        records.forEach((record) => {
          record.addedNodes.forEach((addedNode) => {
            if (addedNode.nodeType === Node.TEXT_NODE) {
              translateTextNode(addedNode, dictionary);
            } else if (addedNode.nodeType === Node.ELEMENT_NODE) {
              translateTree(addedNode, dictionary);
            }
          });
        });
      });
      observer.observe(document.body, { childList: true, subtree: true });
    } catch (error) {
      console.error('[i18n] Translation initialization failed.', error);
    }
  };

  document.addEventListener('click', (event) => {
    if (!(event.target instanceof Element)) return;
    const link = event.target.closest('[data-language]');
    if (!link || link.hasAttribute('onclick')) return;
    event.preventDefault();
    window.switchLanguage(link.dataset.language);
    document.activeElement?.blur();
  });

  document.addEventListener('DOMContentLoaded', initialize, { once: true });

  window.addEventListener('storage', (event) => {
    if (event.key !== 'namfin_language') return;
    applyLocale(event.newValue || 'en', false).catch((error) => {
      console.error('[i18n] Cross-tab language update failed.', error);
    });
  });
})();
