/**
 * NAMDEV FINVEST LIMITED — MINIMALIST BLACK & WHITE CORE ENGINE
 * Web Audio, Monochrome Particle Physics, 3D Tilt & Modal Mechanics
 */

(function () {
  'use strict';

  // ===================================================================
  // 1. WEB AUDIO SYNTHESIZER (MINIMALIST CLICK FX)
  // ===================================================================
  class SoundFX {
    constructor() {
      this.ctx = null;
      this.enabled = localStorage.getItem('namfin_audio') === 'true';
      this.initButton();
    }

    initContext() {
      if (!this.ctx && (window.AudioContext || window.webkitAudioContext)) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioCtx();
      }
    }

    playClick(freq = 600, type = 'sine', duration = 0.04) {
      if (!this.enabled) return;
      try {
        this.initContext();
        if (this.ctx && this.ctx.state === 'suspended') {
          this.ctx.resume();
        }
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {
        // Audio error
      }
    }

    playQuantumBeep() {
      this.playClick(900, 'triangle', 0.05);
    }

    toggle() {
      this.enabled = !this.enabled;
      localStorage.setItem('namfin_audio', this.enabled);
      this.updateUI();
      if (this.enabled) {
        this.playQuantumBeep();
      }
    }

    initButton() {
      const btn = document.getElementById('audioToggleBtn');
      if (btn) {
        btn.addEventListener('click', () => this.toggle());
        this.updateUI();
      }
    }

    updateUI() {
      const btn = document.getElementById('audioToggleBtn');
      if (!btn) return;
      if (this.enabled) {
        btn.classList.add('active');
        btn.setAttribute('title', 'Sound FX: Enabled');
        btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>`;
      } else {
        btn.classList.remove('active');
        btn.setAttribute('title', 'Sound FX: Muted');
        btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`;
      }
    }
  }

  const sfx = new SoundFX();
  window.namfinSFX = sfx;

  // ===================================================================
  // 2. MONOCHROME PARTICLE NETWORK CANVAS
  // ===================================================================
  const canvas = document.getElementById('cyberGridCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width, height;
    let particles = [];
    const particleCount = window.innerWidth < 768 ? 30 : 65;
    const maxDistance = 130;
    const mouse = { x: null, y: null, radius: 140 };

    function resize() {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }

    class Particle {
      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.6;
        this.vy = (Math.random() - 0.5) * 0.6;
        this.radius = Math.random() * 1.5 + 0.8;
        this.color = document.documentElement.getAttribute('data-theme') === 'dark' ? '#ffffff' : '#000000';
        this.alpha = Math.random() * 0.35 + 0.15;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;

        if (mouse.x !== null) {
          const dx = mouse.x - this.x;
          const dy = mouse.y - this.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mouse.radius) {
            const force = (mouse.radius - dist) / mouse.radius;
            this.x -= (dx / dist) * force * 2.5;
            this.y -= (dy / dist) * force * 2.5;
          }
        }
      }

      draw() {
        ctx.save();
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.globalAlpha = this.alpha;
        ctx.shadowBlur = 4;
        ctx.shadowColor = document.documentElement.getAttribute('data-theme') === 'dark' ? '#ffffff' : 'transparent';
        ctx.fill();
        ctx.restore();
      }
    }

    window.initParticles = function() {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
      }
    }

    function connectParticles() {
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDistance) {
            const alpha = (1 - dist / maxDistance) * 0.14;
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = document.documentElement.getAttribute('data-theme') === 'dark' ? '#ffffff' : '#000000';
            ctx.globalAlpha = alpha;
            ctx.lineWidth = 0.8;
            ctx.stroke();
            ctx.restore();
          }
        }
      }
    }

    function animate() {
      ctx.clearRect(0, 0, width, height);
      particles.forEach((p) => {
        p.update();
        p.draw();
      });
      connectParticles();
      requestAnimationFrame(animate);
    }

    window.addEventListener('resize', () => {
      resize();
      window.initParticles();
    });

    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    });

    window.addEventListener('mouseleave', () => {
      mouse.x = null;
      mouse.y = null;
    });

    resize();
    window.initParticles();
    animate();
  }

  // ===================================================================
  // 3. 3D CARD TILT & SPOTLIGHT FOLLOWER
  // ===================================================================
  const tiltCards = document.querySelectorAll('.hologram-card, .bento-card, .product-matrix-card');
  tiltCards.forEach((card) => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);

      if (card.classList.contains('hologram-card')) {
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -8;
        const rotateY = ((x - centerX) / centerX) * 8;
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.01, 1.01, 1.01)`;
      }
    });

    card.addEventListener('mouseleave', () => {
      if (card.classList.contains('hologram-card')) {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
      }
    });
  });

  // ===================================================================
  // 4. NAVBAR SCROLL EFFECT & MOBILE DRAWER
  // ===================================================================
  const moduleRoutes = {
    'about.html': {
      story: { title: 'Our Story', selectors: ['#who-we-are', '#story'] },
      'vision-mission': { title: 'Our Purpose & Mission', selectors: ['#vision-mission'] },
      values: { title: 'Our Values', selectors: ['#values'] },
      board: { title: 'Board of Directors', selectors: ['#board'] },
      management: { title: 'Management Team', selectors: ['#management'] }
    },
    'investor.html': {
      partners: { title: 'Growth Partners', selectors: ['#partners', '#equity', '#categories'] },
      board: { title: 'Board & Committees', selectors: ['#board'] },
      financials: { title: 'Financial Performance', selectors: ['#financials'] },
      reports: { title: 'Annual Reports', selectors: ['#reports'] },
      policies: { title: 'Codes and Policies', selectors: ['#policies'] },
      esg: { title: 'ESG & Responsible Finance', selectors: ['#esg'] },
      disclosures: { title: 'Disclosures', selectors: ['#disclosures'] },
      rta: { title: 'Registrar & Transfer Agent', selectors: ['#rta'] }
    },
    'team.html': {
      culture: { title: 'Life at Namdev', selectors: ['#culture', '[data-site-module="culture"]'] },
      gallery: { title: 'Team & Culture Gallery', selectors: ['#gallery'] },
      careers: { title: 'Careers', selectors: ['#careers'] }
    },
    'contact.html': {
      information: { title: 'Contact Information', panel: 'contactPanelInfo' },
      'branch-locator': { title: 'Branch Locator', panel: 'contactPanelBranch' },
      suggestions: { title: 'Suggestion / Query', panel: 'contactPanelQuery' },
      grievance: { title: 'Grievance Redressal', panel: 'contactPanelGrievance' }
    }
  };
  const moduleHashMap = {
    'about.html': {
      'who-we-are': 'story', story: 'story', board: 'board', management: 'management',
      'vision-mission': 'vision-mission', purpose: 'vision-mission', values: 'values'
    },
    'investor.html': {
      partners: 'partners', equity: 'partners', categories: 'partners', board: 'board',
      financials: 'financials', reports: 'reports', policies: 'policies', esg: 'esg',
      disclosures: 'disclosures', rta: 'rta'
    },
    'team.html': { culture: 'culture', gallery: 'gallery', careers: 'careers' },
    'contact.html': {
      contactPanelInfo: 'information', contactPanelBranch: 'branch-locator',
      contactPanelQuery: 'suggestions', contactPanelGrievance: 'grievance'
    }
  };
  const routeFile = decodeURIComponent(window.location.pathname.split('/').pop() || '');
  const pageModules = moduleRoutes[routeFile];
  const navMenu = document.querySelector('.quantum-nav .nav-menu');

  const moduleHref = (file, module) => `${file}?module=${encodeURIComponent(module)}`;
  const appendModuleLink = (menu, file, module, label) => {
    if (!menu) return;
    const alreadyLinked = Array.from(menu.querySelectorAll('a[href]')).some((anchor) => {
      const url = new URL(anchor.href, window.location.href);
      const targetFile = decodeURIComponent(url.pathname.split('/').pop() || '');
      const targetModule = url.searchParams.get('module') || moduleHashMap[targetFile]?.[decodeURIComponent(url.hash.slice(1))];
      return targetFile === file && targetModule === module;
    });
    if (alreadyLinked) return;
    const item = document.createElement('li');
    const link = document.createElement('a');
    link.href = moduleHref(file, module);
    link.textContent = label;
    link.setAttribute('data-module-link', '');
    item.appendChild(link);
    menu.appendChild(item);
  };

  if (navMenu) {
    const aboutItem = navMenu.querySelector('a[href^="about.html"]')?.closest('li');
    const investorItem = navMenu.querySelector('a[href^="investor.html"]')?.closest('li');
    const teamItem = navMenu.querySelector('a[href^="team.html"]')?.closest('li');
    const productItem = Array.from(navMenu.children).find((item) =>
      item.querySelector(':scope > a')?.textContent.trim().startsWith('Products')
    );
    const ensureMenu = (item, className = 'dropdown-menu-simple') => {
      if (!item) return null;
      let menu = item.querySelector(':scope > ul');
      if (!menu) {
        menu = document.createElement('ul');
        menu.className = className;
        item.appendChild(menu);
      }
      item.classList.add('nav-item-dropdown');
      return menu;
    };

    const aboutMenu = ensureMenu(aboutItem);
    appendModuleLink(aboutMenu, 'about.html', 'story', 'Our Story');
    appendModuleLink(aboutMenu, 'about.html', 'vision-mission', 'Purpose & Mission');
    appendModuleLink(aboutMenu, 'about.html', 'values', 'Our Values');

    const investorMenu = ensureMenu(investorItem);
    appendModuleLink(investorMenu, 'investor.html', 'board', 'Board & Committees');
    const teamMenu = ensureMenu(teamItem);
    appendModuleLink(teamMenu, 'team.html', 'culture', 'Life at Namdev');
    appendModuleLink(teamMenu, 'team.html', 'gallery', 'Team & Culture Gallery');
    appendModuleLink(teamMenu, 'team.html', 'careers', 'Careers');

    const productMenu = productItem?.querySelector(':scope > ul');
    if (productMenu && !productMenu.querySelector('a[href^="e-rickshaw.html"]')) {
      const item = document.createElement('li');
      const link = document.createElement('a');
      link.href = 'e-rickshaw.html';
      link.className = 'dropdown-link-quantum';
      link.innerHTML = '<div class="dropdown-info"><span class="dropdown-name">E-Rickshaw &amp; EV Loans</span></div>';
      item.appendChild(link);
      productMenu.appendChild(item);
    }

    let contactItem = navMenu.querySelector('a[href^="contact.html"]')?.closest('li');
    if (contactItem) {
      contactItem.classList.add('nav-item-dropdown');
      const contactLink = contactItem.querySelector(':scope > a');
      contactLink.href = moduleHref('contact.html', 'information');
      const contactMenu = ensureMenu(contactItem);
      [
        ['information', 'Contact Information'],
        ['branch-locator', 'Branch Locator'],
        ['suggestions', 'Suggestion / Query'],
        ['grievance', 'Grievance Redressal']
      ].forEach(([module, label]) => appendModuleLink(contactMenu, 'contact.html', module, label));
    }

    const primaryRoutes = [
      ['about.html', /^About\b/],
      ['investor.html', /^Investor\b/],
      ['team.html', /^Our Team\b/],
      ['contact.html', /^Contact\b/]
    ];
    navMenu.querySelectorAll(':scope > li > a.nav-link').forEach((link) => {
      const label = link.textContent.replace(/\s+/g, ' ').trim();
      const match = primaryRoutes.find(([, expression]) => expression.test(label));
      if (match) link.href = match[0];
    });
  }

  document.querySelectorAll('a[href]').forEach((link) => {
    const url = new URL(link.href, window.location.href);
    if (url.origin !== window.location.origin) return;
    const file = decodeURIComponent(url.pathname.split('/').pop() || '');
    const hash = decodeURIComponent(url.hash.slice(1));
    const module = moduleHashMap[file]?.[hash];
    if (module) link.href = moduleHref(file, module);
  });

  const requestedModule = new URLSearchParams(window.location.search).get('module')
  || moduleHashMap[routeFile]?.[decodeURIComponent(window.location.hash.slice(1))];
  if (requestedModule && window.location.hash && moduleHashMap[routeFile]?.[decodeURIComponent(window.location.hash.slice(1))]) {
  history.replaceState(null, '', moduleHref(routeFile, requestedModule));
  }
  const activeModule = pageModules?.[requestedModule];
  if (activeModule) {
    const app = document.querySelector('.app-container');
    const topSections = Array.from(app?.querySelectorAll(':scope > section') || []);
    let activeRoots = [];
    if (activeModule.panel) {
      activeRoots = [document.getElementById('contact-options')].filter(Boolean);
    } else {
      activeRoots = activeModule.selectors
        .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
        .filter((element) => topSections.includes(element));
    }
    if (app && activeRoots.length) {
      topSections.forEach((section) => {
        section.hidden = !activeRoots.includes(section);
      });
      const breadcrumb = document.createElement('nav');
      breadcrumb.className = 'module-breadcrumb';
      breadcrumb.setAttribute('aria-label', 'Breadcrumb');
      const parentLabel = routeFile === 'about.html'
        ? 'About Us'
        : routeFile === 'investor.html'
          ? 'Investor'
          : routeFile === 'team.html'
            ? 'Our Team'
            : 'Contact';
      breadcrumb.innerHTML = `<a href="index.html">Home</a><span aria-hidden="true">/</span><a href="${routeFile}">${parentLabel}</a><span aria-hidden="true">/</span><span aria-current="page"></span>`;
      breadcrumb.lastElementChild.textContent = activeModule.title;
      activeRoots[0].before(breadcrumb);
      if (routeFile === 'contact.html') {
        document.addEventListener('DOMContentLoaded', () => {
          let syncingContactRoute = false;
          const contactTabs = Array.from(document.querySelectorAll('#contact-options [role="tab"]'));
          const syncContactTab = (panelId) => {
            const panel = document.getElementById(panelId);
            const tab = panel && document.getElementById(panel.getAttribute('aria-labelledby'));
            if (!tab) return;
            syncingContactRoute = true;
            tab.click();
            syncingContactRoute = false;
          };
          contactTabs.forEach((tab) => {
            tab.addEventListener('click', () => {
              if (syncingContactRoute) return;
              const module = Object.entries(pageModules).find(([, item]) => item.panel === tab.getAttribute('aria-controls'))?.[0];
              if (!module) return;
              const label = pageModules[module].title;
              history.pushState(null, '', moduleHref(routeFile, module));
              breadcrumb.lastElementChild.textContent = label;
              document.title = `${label} | Contact Us | Namdev Finvest`;
            });
          });
          window.addEventListener('popstate', () => {
            const module = new URLSearchParams(window.location.search).get('module');
            const restored = pageModules[module];
            if (!restored?.panel) return;
            syncContactTab(restored.panel);
            breadcrumb.lastElementChild.textContent = restored.title;
            document.title = `${restored.title} | Contact Us | Namdev Finvest`;
          });
          syncContactTab(activeModule.panel);
          window.scrollTo(0, 0);
        }, { once: true });
      }
      document.title = `${activeModule.title} | ${document.title}`;
      document.body.classList.add('module-route-view');
    }
  }

  const moduleHubPages = {
    'about.html': { title: 'About Us', description: 'Explore our story, purpose, values, board, and management.' },
    'investor.html': { title: 'Investor Relations', description: 'Find investor resources, financial information, governance, and disclosures.' },
    'team.html': { title: 'Our Team', description: 'Explore the workplace, team gallery, and careers.' },
    'contact.html': { title: 'Contact', description: 'Choose the contact or support information you need.' }
  };
  const moduleHub = moduleHubPages[routeFile];
  if (pageModules && moduleHub && !activeModule) {
    const app = document.querySelector('.app-container');
    const topSections = Array.from(app?.querySelectorAll(':scope > section') || []);
    if (app && topSections.length) {
      topSections.forEach((section) => {
        section.hidden = true;
      });
      const hub = document.createElement('main');
      hub.className = 'module-hub';
      const breadcrumb = document.createElement('nav');
      breadcrumb.className = 'module-breadcrumb';
      breadcrumb.setAttribute('aria-label', 'Breadcrumb');
      breadcrumb.innerHTML = '<a href="index.html">Home</a><span aria-hidden="true">/</span><span aria-current="page"></span>';
      breadcrumb.lastElementChild.textContent = moduleHub.title;

      const content = document.createElement('div');
      content.className = 'container module-hub-content';
      const heading = document.createElement('h1');
      heading.className = 'module-hub-title';
      heading.textContent = moduleHub.title;
      const description = document.createElement('p');
      description.className = 'module-hub-description';
      description.textContent = moduleHub.description;
      const grid = document.createElement('div');
      grid.className = 'module-hub-grid';
      grid.setAttribute('aria-label', `${moduleHub.title} modules`);
      Object.entries(pageModules).forEach(([module, item]) => {
        const link = document.createElement('a');
        link.className = 'module-hub-card';
        link.href = moduleHref(routeFile, module);
        const title = document.createElement('h2');
        title.textContent = item.title;
        const action = document.createElement('span');
        action.setAttribute('aria-hidden', 'true');
        action.textContent = 'Explore →';
        link.append(title, action);
        grid.appendChild(link);
      });
      content.append(heading, description, grid);
      hub.append(breadcrumb, content);
      const firstSection = topSections[0];
      firstSection.before(hub);
      document.body.classList.add('module-hub-view');
    }
  }

  const productPages = {
    'msme.html': 'MSME Business Loans',
    'two-wheeler.html': 'Two Wheeler Loans',
    'e-rickshaw.html': 'E-Rickshaw & EV Loans',
    'lap.html': 'Loan Against Property',
    'solar.html': 'Solar & Clean Energy',
    'tractor.html': 'Tractor & Agri Loans'
  };
  if (productPages[routeFile]) {
    const productHero = document.querySelector('.product-hero');
    if (productHero) {
      const breadcrumb = document.createElement('nav');
      breadcrumb.className = 'module-breadcrumb';
      breadcrumb.setAttribute('aria-label', 'Breadcrumb');
      breadcrumb.innerHTML = '<a href="index.html">Home</a><span aria-hidden="true">/</span><a href="index.html#products">Products</a><span aria-hidden="true">/</span><span aria-current="page"></span>';
      breadcrumb.lastElementChild.textContent = productPages[routeFile];
      productHero.before(breadcrumb);
      document.body.classList.add('module-route-view');
    }
  }

  const nav = document.querySelector('.quantum-nav');
  const navInner = nav?.querySelector('.nav-inner');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  if (navInner) {
    let navMeasurePending = false;
    const updateNavDensity = () => {
      navMeasurePending = false;
      if (window.matchMedia('(max-width: 1180px)').matches) {
        navInner.classList.remove('is-compact');
        return;
      }

      navInner.classList.remove('is-compact');
      const contentOverflows = navInner.scrollWidth > navInner.clientWidth + 1;
      navInner.classList.toggle('is-compact', contentOverflows);
    };
    const scheduleNavDensityUpdate = () => {
      if (navMeasurePending) return;
      navMeasurePending = true;
      window.requestAnimationFrame(updateNavDensity);
    };

    scheduleNavDensityUpdate();
    window.addEventListener('resize', scheduleNavDensityUpdate, { passive: true });
    new MutationObserver(scheduleNavDensityUpdate).observe(navInner, {
      childList: true,
      characterData: true,
      subtree: true
    });
  }

  const mobileToggle = document.getElementById('mobileNavToggle');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const mobileClose = document.getElementById('mobileDrawerClose');

  if (mobileToggle && mobileDrawer) {
    const mobileLinks = mobileDrawer.querySelector('.mobile-menu-links');
    const desktopLinks = nav?.querySelector('.nav-menu');
    const priorDrawerLinks = mobileLinks ? Array.from(mobileLinks.querySelectorAll('a')) : [];
    const seenHrefs = new Set();

    mobileDrawer.setAttribute('role', 'dialog');
    mobileDrawer.setAttribute('aria-modal', 'true');
    mobileDrawer.setAttribute('aria-label', 'Main navigation');
    mobileToggle.setAttribute('aria-controls', mobileDrawer.id);
    mobileToggle.setAttribute('aria-expanded', 'false');

    if (mobileLinks && desktopLinks) {
      const addDrawerLink = (source) => {
        const href = source.getAttribute('href');
        if (!href || seenHrefs.has(href)) return;
        seenHrefs.add(href);

        const item = document.createElement('li');
        const link = document.createElement('a');
        link.href = href;
        link.className = 'mobile-link';
        link.textContent = source.textContent.replace(/\s+/g, ' ').trim();
        const languageCode = source.dataset.language
          || source.getAttribute('onclick')?.match(/switchLanguage\(['"]([a-z]{2})['"]\)/)?.[1];
        if (languageCode) {
          link.href = '#';
          link.dataset.language = languageCode;
        }
        if (source.target) link.target = source.target;
        if (source.rel) link.rel = source.rel;
        item.appendChild(link);
        mobileLinks.appendChild(item);
      };

      mobileLinks.replaceChildren();
      desktopLinks.querySelectorAll('a').forEach(addDrawerLink);
      priorDrawerLinks.forEach(addDrawerLink);
    }

    const drawerActions = document.createElement('div');
    drawerActions.className = 'mobile-drawer-actions';

    const addActionLink = (source, primary = false) => {
      if (!source) return;
      const link = source.cloneNode(true);
      link.className = primary ? 'mobile-action-primary' : '';
      link.removeAttribute('style');
      link.querySelectorAll('svg').forEach((icon) => icon.remove());
      link.setAttribute('data-mobile-drawer-link', '');
      drawerActions.appendChild(link);
    };

    addActionLink(nav?.querySelector('.nav-actions .login-btn'));
    addActionLink(nav?.querySelector('.nav-actions > .btn-quantum'), true);

    const languageOptions = nav?.querySelector('.nav-actions .nav-item-dropdown ul');
    if (languageOptions) {
      const languagePicker = document.createElement('details');
      languagePicker.className = 'mobile-language-picker';
      const summary = document.createElement('summary');
      summary.textContent = 'Language';
      const options = languageOptions.cloneNode(true);
      options.classList.remove('dropdown-menu-simple');
      options.removeAttribute('style');
      options.querySelectorAll('a').forEach((link) => {
        link.removeAttribute('style');
        link.className = '';
      });
      languagePicker.append(summary, options);
      drawerActions.appendChild(languagePicker);
    }

    [
      ['themeToggleBtn', 'Theme'],
      ['audioToggleBtn', 'Sound']
    ].forEach(([id, label]) => {
      const original = document.getElementById(id);
      if (!original) return;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'mobile-setting-button';
      button.textContent = label;
      button.setAttribute('aria-label', original.getAttribute('aria-label') || label);
      button.addEventListener('click', () => original.click());
      drawerActions.appendChild(button);
    });

    const drawerFallbackAction = Array.from(mobileDrawer.children)
      .find((child) => child.querySelector('[data-open-modal]'));
    if (drawerFallbackAction) {
      mobileDrawer.insertBefore(drawerActions, drawerFallbackAction);
    } else {
      mobileDrawer.appendChild(drawerActions);
    }

    let previousBodyOverflow = '';
    const getDrawerFocusables = () => Array.from(mobileDrawer.querySelectorAll(
      'a[href], button:not([disabled]), summary, [tabindex]:not([tabindex="-1"])'
    )).filter((element) => element.getClientRects().length > 0);

    const closeMobileDrawer = (restoreFocus = true) => {
      if (restoreFocus || mobileDrawer.contains(document.activeElement)) {
        mobileToggle.focus({ preventScroll: true });
      }
      mobileDrawer.classList.remove('open');
      mobileDrawer.setAttribute('aria-hidden', 'true');
      mobileDrawer.inert = true;
      mobileToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = previousBodyOverflow;
    };

    const openMobileDrawer = () => {
      previousBodyOverflow = document.body.style.overflow;
      mobileDrawer.inert = false;
      mobileDrawer.setAttribute('aria-hidden', 'false');
      mobileDrawer.classList.add('open');
      mobileToggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
      mobileClose?.focus();
    };

    mobileDrawer.setAttribute('aria-hidden', 'true');
    mobileDrawer.inert = true;
    mobileToggle.addEventListener('click', () => {
      sfx.playQuantumBeep();
      openMobileDrawer();
    });

    mobileClose?.addEventListener('click', () => {
      sfx.playClick(500);
      closeMobileDrawer();
    });

    mobileDrawer.addEventListener('click', (event) => {
      if (event.target === mobileDrawer) {
        closeMobileDrawer();
      } else if (event.target.closest('a[href]')) {
        closeMobileDrawer(false);
      }
    });

    mobileDrawer.addEventListener('keydown', (event) => {
      if (event.key !== 'Tab') return;
      const focusables = getDrawerFocusables();
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });

    window.closeNamdevMobileDrawer = closeMobileDrawer;
  }

  // ===================================================================
  // 5. APPLICATION MODAL DIALOG
  // ===================================================================
  const modalBackdrop = document.getElementById('quantumModal');
  const openModalButtons = document.querySelectorAll('[data-open-modal]');
  const closeModalButtons = document.querySelectorAll('.modal-close-btn, [data-close-modal]');

  function openApplicationModal(product = '') {
    sfx.playQuantumBeep();
    if (modalBackdrop) {
      if (product) {
        const select = modalBackdrop.querySelector('#modalProductSelect');
        if (select) select.value = product;
      }
      modalBackdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeApplicationModal() {
    sfx.playClick(400);
    if (modalBackdrop) {
      modalBackdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  openModalButtons.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const product = btn.getAttribute('data-product') || '';
      openApplicationModal(product);
    });
  });

  closeModalButtons.forEach((btn) => {
    btn.addEventListener('click', () => closeApplicationModal());
  });

  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) {
        closeApplicationModal();
      }
    });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeApplicationModal();
      if (mobileDrawer?.classList.contains('open')) {
        window.closeNamdevMobileDrawer?.();
      }
    }
  });

  // Modal Form Submission Simulation
  const modalForm = document.getElementById('quantumLoanForm');
  if (modalForm) {
    modalForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (window.namfinSFX) window.namfinSFX.playQuantumBeep();

      const submitBtn = modalForm.querySelector('button[type="submit"]');
      
      // Get data
      const name = document.getElementById('modalName') ? document.getElementById('modalName').value : 'Applicant';
      const mobile = document.getElementById('modalPhone') ? document.getElementById('modalPhone').value : '';
      const productSelect = document.getElementById('modalProductSelect');
      const product = productSelect ? productSelect.options[productSelect.selectedIndex].text : 'Loan';
      
      submitBtn.innerHTML = `<span class="pulse-dot"></span> ANALYZING DATA & SENDING WHATSAPP...`;
      submitBtn.disabled = true;

      setTimeout(() => {
        if (window.namfinSFX) window.namfinSFX.playClick(1000, 'triangle', 0.15);
        window.location.href = `whatsapp-simulator.html?name=${encodeURIComponent(name)}&mobile=${encodeURIComponent(mobile)}&product=${encodeURIComponent(product)}&amount=500000`;
      }, 1500);
    });
  }

  // ===================================================================
  // ===================================================================
  // 6. FAQ ACCORDION ENGINE
  // ===================================================================
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach((item) => {
    const btn = item.querySelector('.faq-question-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        sfx.playClick(800, 'sine', 0.05);
        const isOpen = item.classList.contains('active');
        
        faqItems.forEach(faq => faq.classList.remove('active'));
        
        if (!isOpen) {
          item.classList.add('active');
        }
      });
    }
  });

  // ===================================================================
  // 7. THEME SWITCHER
  // ===================================================================
  const initThemeSwitcher = () => {
    const btn = document.getElementById('themeToggleBtn');
    if (!btn) return;

    const sunIcon = btn.querySelector('.sun-icon');
    const moonIcon = btn.querySelector('.moon-icon');

    const updateIcons = (theme) => {
      const isDark = theme === 'dark';
      if (theme === 'dark') {
        if (sunIcon) sunIcon.style.display = 'block';
        if (moonIcon) moonIcon.style.display = 'none';
      } else {
        if (sunIcon) sunIcon.style.display = 'none';
        if (moonIcon) moonIcon.style.display = 'block';
      }
      btn.setAttribute('aria-label', `Switch to ${isDark ? 'light' : 'night'} mode`);
      btn.setAttribute('title', `Switch to ${isDark ? 'light' : 'night'} mode`);
    };

    const currentTheme = localStorage.getItem('namfin_theme') === 'dark' ? 'dark' : 'light';
    if (currentTheme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    updateIcons(currentTheme);

    btn.addEventListener('click', () => {
      const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      const nextTheme = theme === 'dark' ? 'light' : 'dark';
      if (nextTheme === 'light') {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('namfin_theme', 'light');
        updateIcons('light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('namfin_theme', 'dark');
        updateIcons('dark');
      }
      sfx.playQuantumBeep();
      
      // Re-initialize particles if network exists
      if (typeof window.initParticles === 'function') {
        window.initParticles();
      }
    });

    window.addEventListener('storage', (event) => {
      if (event.key !== 'namfin_theme') return;
      const theme = event.newValue === 'dark' ? 'dark' : 'light';
      if (theme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.documentElement.removeAttribute('data-theme');
      }
      updateIcons(theme);
    });
  };
  
  document.addEventListener('DOMContentLoaded', () => {
    initThemeSwitcher();
  });
})();


/* ==========================================================================
   DYNAMIC GRADIENT THEME SELECTOR LOGIC
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
    const gradients = {
        cyberpunk: { c1: '#6366f1', c2: '#a855f7', c3: '#ec4899', glow: 'rgba(99,102,241,0.4)' },
        emerald:   { c1: '#14b8a6', c2: '#10b981', c3: '#84cc16', glow: 'rgba(16,185,129,0.4)' },
        sunset:    { c1: '#f43f5e', c2: '#f97316', c3: '#eab308', glow: 'rgba(249,115,22,0.4)' },
        ocean:     { c1: '#06b6d4', c2: '#3b82f6', c3: '#4f46e5', glow: 'rgba(59,130,246,0.4)' },
        namdev:    { c1: '#ef4444', c2: '#8b5cf6', c3: '#3b82f6', glow: 'rgba(239,68,68,0.4)' }
    };

    const applyGradient = (themeId) => {
        const theme = gradients[themeId] || gradients.cyberpunk;
        document.documentElement.style.setProperty('--grad-c1', theme.c1);
        document.documentElement.style.setProperty('--grad-c2', theme.c2);
        document.documentElement.style.setProperty('--grad-c3', theme.c3);
        document.documentElement.style.setProperty('--theme-btn-glow', theme.glow);
        localStorage.setItem('namfin_gradient', themeId);
        
        document.querySelectorAll('.theme-dot').forEach(dot => {
            dot.classList.toggle('active', dot.dataset.grad === themeId);
        });
    };

    // Initialize from localStorage
    const savedGrad = localStorage.getItem('namfin_gradient') || 'cyberpunk';
    applyGradient(savedGrad);

    // Add click listeners to dots
    document.querySelectorAll('.theme-dot').forEach(dot => {
        dot.addEventListener('click', (e) => {
            applyGradient(e.target.dataset.grad);
        });
    });
});
