(function () {
  'use strict';

  const COPY = {
    en: {
      title: 'Helpful Buddy', subtitle: 'Your Namdev Finvest website guide',
      open: 'Open Helpful Buddy', close: 'Close Helpful Buddy', send: 'Send message',
      placeholder: 'Ask about this page...', privacy: 'Website guide only. It cannot access accounts, verify identity, or submit forms.',
      greeting: 'Hi! I can explain this page and point you to the next useful step.',
      chipNext: 'What should I do next?', chipExplain: 'Explain this page',
      chipApply: 'Help me apply', chipPay: 'Pay my EMI', chipAccount: 'Find my application',
      chipDocs: 'Which documents?', chipStuck: 'I am stuck', chipContact: 'Contact support',
      chipProducts: 'Explore loan options', chipBranch: 'Find a branch',
      nextHome: 'Choose a loan product that fits your need from the Products section, or open Pay EMI if you already have a loan account.',
      nextProduct: 'Review the eligibility and document information on this product page, then use its existing Apply or Enquire button. You can also continue through the loan application page.',
      nextApply: 'Complete the required Personal Details, Identity Verification, and Loan Requirement fields, then use the page’s existing Generate Pre-Sanction Score button. Aadhaar/PAN verification must follow the on-page controls. The result is explicitly labelled as a demo pre-approval, not a final sanction.',
      nextResult: 'This page labels the displayed result “DEMO PRE-APPROVAL GENERATED”. It is not a final loan sanction or confirmation from a lender. Use the page’s Back control to review your entries, or contact Namdev Finvest for official guidance.',
      nextPayment: 'This page says it is not connected to a payment gateway and cannot look up your EMI. No payment is initiated here. Follow the instructions on your official loan statement or contact Namdev Finvest before paying.',
      nextContact: 'Choose the relevant Contact Us tab: contact information, Branch Locator, Suggestion / Query, or Grievance Redressal. The forms on this page explain when information is not sent.',
      nextLogin: 'Use the mobile-number and OTP steps shown on this page. I cannot access your account, request an OTP, or verify an OTP for you.',
      nextInvestor: 'Use the Investor navigation links or the sections on this page to find partner, financial, policy, report, ESG, and registrar information.',
      nextTeam: 'Explore the workplace and culture information, browse the team albums, or open Careers for the official opportunities link.',
      nextAbout: 'Use the About navigation to read the company overview, Board of Directors, and Management Team sections.',
      nextGeneric: 'Use the page heading and visible sections to identify the information you need. I can also guide you to loan products, EMI information, login, or Contact Us.',
      explain: 'You are viewing {page}. I can guide you through the content on this page, but I cannot see private account or application data.',
      apply: 'The application page contains personal details, identity verification, and loan requirement sections. Aadhaar and PAN are required there; GSTIN is provided for applicable business cases. Use the page’s own controls and review any displayed notices. I cannot verify documents or submit an application.',
      pay: 'Open Pay EMI to review the payment form. The page clearly states that it is not connected to a payment gateway, cannot look up your EMI, and does not initiate or store payment details.',
      account: 'The Login page provides a mobile-number and OTP flow. Open it and follow the prompts. I cannot retrieve an application, confirm delivery of an OTP, or verify account status.',
      stuck: 'I can help with the visible fields or page controls. If a required field was just rejected, I’ll point you to it; otherwise tell me what you were trying to do.',
      contact: 'For customer assistance, the Contact page lists 1800-103-5800 and info@namfin.in. Complaints can also be directed to compliance@namfin.in. Open Contact Us to view the available options.',
      products: 'Choose a product page to review its details and use its existing enquiry/application controls.',
      documents: 'The application page says Aadhaar and PAN are required. It accepts JPG, PNG, or PDF uploads up to 5 MB; GSTIN is available where applicable. OTP requests or document scans do not, by themselves, prove that verification succeeded.',
      invalid: 'A required field needs attention{field}. Complete or correct it before using the page’s existing Continue or submit control.',
      invalidNoField: 'Some required information needs attention. Review the highlighted fields on the page before continuing.',
      allValid: 'I do not see a currently invalid, visible field in this form. Review the information and use the page’s existing button when you are ready; I will not submit it for you.',
      unknown: 'I can guide you around this page and the existing loan, payment, login, and support routes. I cannot check loan eligibility, account status, or payment status.',
      unsaved: 'You have entered information that may not be saved. Continue away from this page?',
      actionApply: 'Open Loan Application', actionPay: 'Open EMI Payments',
      actionLogin: 'Open Login', actionContact: 'Open Contact Us',
      actionProducts: 'Browse Loan Products', actionBranch: 'Open Branch Locator',
      actionDocs: 'Review document requirements', actionFocus: 'Review required fields',
      actionBack: 'Back to application details', actionSupport: 'Contact customer support',
      contextPage: 'Page', contextAbout: 'About', contextInvestor: 'Investor Relations',
      contextTeam: 'Our Team', contextContact: 'Contact Us', contextPayment: 'Pay EMI',
      contextLogin: 'Login', contextApply: 'Loan Application', contextHome: 'Home',
      contextProduct: 'Loan Product', contextResult: 'Pre-Approval Demo'
    },
    hi: {
      title: 'सहायक साथी', subtitle: 'नामदेव फिनवेस्ट वेबसाइट मार्गदर्शक',
      open: 'सहायक साथी खोलें', close: 'सहायक साथी बंद करें', send: 'संदेश भेजें',
      placeholder: 'इस पेज के बारे में पूछें...', privacy: 'यह केवल वेबसाइट मार्गदर्शक है। यह खाते नहीं देख सकता, पहचान सत्यापित नहीं कर सकता और फ़ॉर्म जमा नहीं करता।',
      greeting: 'नमस्ते! मैं इस पेज को समझाने और अगला उपयोगी कदम बताने में मदद कर सकता हूं।',
      chipNext: 'अब मुझे क्या करना चाहिए?', chipExplain: 'यह पेज समझाएं',
      chipApply: 'लोन आवेदन में मदद', chipPay: 'ईएमआई का भुगतान', chipAccount: 'मेरा आवेदन खोजें',
      chipDocs: 'कौन से दस्तावेज़?', chipStuck: 'मैं अटक गया हूं', chipContact: 'सहायता से संपर्क',
      chipProducts: 'लोन विकल्प देखें', chipBranch: 'शाखा खोजें',
      nextHome: 'Products सेक्शन में अपनी ज़रूरत के अनुसार लोन चुनें, या पहले से लोन खाता होने पर Pay EMI खोलें।',
      nextProduct: 'इस उत्पाद पेज पर पात्रता और दस्तावेज़ जानकारी देखें, फिर मौजूदा Apply या Enquire बटन का उपयोग करें। आप लोन आवेदन पेज पर भी जा सकते हैं।',
      nextApply: 'Personal Details, Identity Verification और Loan Requirement के आवश्यक फ़ील्ड भरें, फिर पेज का Generate Pre-Sanction Score बटन उपयोग करें। आधार/PAN सत्यापन के लिए पेज पर दिए नियंत्रण अपनाएं। परिणाम स्पष्ट रूप से डेमो प्री-अप्रूवल है, अंतिम मंज़ूरी नहीं।',
      nextResult: 'यह पेज परिणाम को “DEMO PRE-APPROVAL GENERATED” कहता है। यह अंतिम लोन मंज़ूरी या ऋणदाता की पुष्टि नहीं है। जानकारी देखने के लिए Back नियंत्रण चुनें या आधिकारिक मार्गदर्शन हेतु नामदेव फिनवेस्ट से संपर्क करें।',
      nextPayment: 'पेज बताता है कि यह पेमेंट गेटवे से जुड़ा नहीं है और आपकी ईएमआई नहीं देख सकता। यहां कोई भुगतान शुरू नहीं होता। भुगतान से पहले आधिकारिक लोन विवरण या नामदेव फिनवेस्ट से पुष्टि करें।',
      nextContact: 'संबंधित Contact Us टैब चुनें: संपर्क जानकारी, Branch Locator, Suggestion / Query या Grievance Redressal। फ़ॉर्म स्पष्ट करते हैं कि जानकारी कब नहीं भेजी जाती।',
      nextLogin: 'इस पेज पर दिए मोबाइल नंबर और OTP चरण अपनाएं। मैं आपका खाता नहीं देख सकता और OTP मंगवा या सत्यापित नहीं कर सकता।',
      nextInvestor: 'पार्टनर, वित्तीय, नीति, रिपोर्ट, ESG और रजिस्ट्रार जानकारी के लिए Investor लिंक या इस पेज के सेक्शन देखें।',
      nextTeam: 'कार्यस्थल और संस्कृति की जानकारी देखें, टीम एल्बम ब्राउज़ करें या आधिकारिक अवसरों के लिए Careers खोलें।',
      nextAbout: 'कंपनी परिचय, निदेशक मंडल और प्रबंधन टीम देखने के लिए About नेविगेशन का उपयोग करें।',
      nextGeneric: 'ज़रूरी जानकारी के लिए पेज का शीर्षक और दिखने वाले सेक्शन देखें। मैं लोन, ईएमआई, लॉगिन या संपर्क पेज भी दिखा सकता हूं।',
      explain: 'आप {page} देख रहे हैं। मैं इस पेज की सामग्री समझा सकता हूं, लेकिन निजी खाते या आवेदन की जानकारी नहीं देख सकता।',
      apply: 'आवेदन पेज में व्यक्तिगत जानकारी, पहचान सत्यापन और लोन आवश्यकता सेक्शन हैं। आधार और PAN आवश्यक हैं; लागू व्यवसाय के लिए GSTIN है। पेज के नियंत्रणों का उपयोग करें। मैं दस्तावेज़ सत्यापित या आवेदन जमा नहीं कर सकता।',
      pay: 'पेमेंट फ़ॉर्म देखने के लिए Pay EMI खोलें। पेज बताता है कि यह पेमेंट गेटवे से जुड़ा नहीं है, ईएमआई नहीं देख सकता और भुगतान शुरू या संग्रहित नहीं करता।',
      account: 'Login पेज पर मोबाइल नंबर और OTP प्रक्रिया है। उसे खोलकर दिए निर्देश अपनाएं। मैं आवेदन ढूंढ, OTP डिलीवरी या खाते की स्थिति की पुष्टि नहीं कर सकता।',
      stuck: 'मैं दिख रहे फ़ील्ड या पेज नियंत्रणों में मदद कर सकता हूं। यदि कोई आवश्यक फ़ील्ड अस्वीकार हुआ है तो मैं वहां ले जाऊंगा; अन्यथा बताएं कि आप क्या करना चाहते थे।',
      contact: 'ग्राहक सहायता के लिए Contact पेज पर 1800-103-5800 और info@namfin.in दिए हैं। शिकायत के लिए compliance@namfin.in भी है। विकल्प देखने के लिए Contact Us खोलें।',
      products: 'उत्पाद विवरण देखने और मौजूदा आवेदन/पूछताछ नियंत्रणों के लिए उत्पाद पेज चुनें।',
      documents: 'आवेदन पेज के अनुसार आधार और PAN आवश्यक हैं। JPG, PNG या PDF (अधिकतम 5 MB) अपलोड करें; लागू होने पर GSTIN दें। OTP अनुरोध या दस्तावेज़ स्कैन अपने आप सत्यापन की पुष्टि नहीं करते।',
      invalid: 'एक आवश्यक फ़ील्ड जांचें{field}। आगे बढ़ने से पहले इसे भरें या सही करें।',
      invalidNoField: 'कुछ आवश्यक जानकारी की जांच करें। आगे बढ़ने से पहले पेज पर चिह्नित फ़ील्ड देखें।',
      allValid: 'इस फ़ॉर्म में कोई दिखने वाला अमान्य फ़ील्ड नहीं दिख रहा। जानकारी जांचकर तैयार होने पर पेज का मौजूदा बटन उपयोग करें; मैं आपके लिए जमा नहीं करूंगा।',
      unknown: 'मैं इस पेज और मौजूदा लोन, भुगतान, लॉगिन और सहायता मार्गों में मदद कर सकता हूं। मैं पात्रता, खाते या भुगतान की स्थिति नहीं जांच सकता।',
      unsaved: 'आपने ऐसी जानकारी भरी है जो सहेजी नहीं गई हो सकती। क्या इस पेज से आगे बढ़ना है?',
      actionApply: 'लोन आवेदन खोलें', actionPay: 'ईएमआई भुगतान खोलें',
      actionLogin: 'लॉगिन खोलें', actionContact: 'Contact Us खोलें',
      actionProducts: 'लोन उत्पाद देखें', actionBranch: 'शाखा खोजें',
      actionDocs: 'दस्तावेज़ आवश्यकताएं देखें', actionFocus: 'आवश्यक फ़ील्ड जांचें',
      actionBack: 'आवेदन विवरण पर लौटें', actionSupport: 'ग्राहक सहायता से संपर्क',
      contextPage: 'पेज', contextAbout: 'हमारे बारे में', contextInvestor: 'निवेशक संबंध',
      contextTeam: 'हमारी टीम', contextContact: 'संपर्क', contextPayment: 'ईएमआई भुगतान',
      contextLogin: 'लॉगिन', contextApply: 'लोन आवेदन', contextHome: 'होम',
      contextProduct: 'लोन उत्पाद', contextResult: 'प्री-अप्रूवल डेमो'
    },
    mr: {
      title: 'मदतनीस मित्र', subtitle: 'नामदेव फिनवेस्ट वेबसाइट मार्गदर्शक',
      open: 'मदतनीस मित्र उघडा', close: 'मदतनीस मित्र बंद करा', send: 'संदेश पाठवा',
      placeholder: 'या पृष्ठाबद्दल विचारा...', privacy: 'हा केवळ वेबसाइट मार्गदर्शक आहे. तो खाते पाहू शकत नाही, ओळख पडताळू शकत नाही किंवा फॉर्म सबमिट करू शकत नाही.',
      greeting: 'नमस्कार! हे पृष्ठ समजून घेण्यासाठी आणि पुढील उपयुक्त पाऊल शोधण्यासाठी मी मदत करू शकतो.',
      chipNext: 'आता पुढे काय?', chipExplain: 'हे पृष्ठ समजावून सांगा',
      chipApply: 'कर्ज अर्जात मदत', chipPay: 'EMI भरणे', chipAccount: 'माझा अर्ज शोधा',
      chipDocs: 'कोणती कागदपत्रे?', chipStuck: 'मी अडकलो आहे', chipContact: 'सहाय्याशी संपर्क',
      chipProducts: 'कर्ज पर्याय पाहा', chipBranch: 'शाखा शोधा',
      nextHome: 'Products विभागातून गरजेनुसार कर्ज निवडा किंवा आधीच कर्ज खाते असल्यास Pay EMI उघडा.',
      nextProduct: 'या उत्पादन पृष्ठावरील पात्रता आणि कागदपत्रांची माहिती पाहून विद्यमान Apply किंवा Enquire बटण वापरा. कर्ज अर्ज पृष्ठही उघडू शकता.',
      nextApply: 'Personal Details, Identity Verification आणि Loan Requirement मधील आवश्यक माहिती भरा आणि पृष्ठावरील Generate Pre-Sanction Score बटण वापरा. आधार/PAN पडताळणी पृष्ठावरील नियंत्रणांनुसार करा. निकाल हा डेमो प्री-अप्रूव्हल आहे, अंतिम मंजुरी नाही.',
      nextResult: 'या पृष्ठावर निकाल “DEMO PRE-APPROVAL GENERATED” असा नमूद आहे. ही अंतिम कर्जमंजुरी किंवा कर्जदात्याची पुष्टी नाही. माहिती पाहण्यासाठी Back वापरा किंवा अधिकृत मार्गदर्शनासाठी नामदेव फिनवेस्टशी संपर्क साधा.',
      nextPayment: 'हे पृष्ठ पेमेंट गेटवेशी जोडलेले नाही आणि EMI शोधू शकत नाही, असे स्पष्ट करते. येथे पेमेंट सुरू होत नाही. पैसे भरण्यापूर्वी अधिकृत कर्ज विवरण किंवा नामदेव फिनवेस्टशी खात्री करा.',
      nextContact: 'योग्य Contact Us टॅब निवडा: संपर्क माहिती, Branch Locator, Suggestion / Query किंवा Grievance Redressal. फॉर्म माहिती पाठवली जाते की नाही हे स्पष्ट करतात.',
      nextLogin: 'या पृष्ठावरील मोबाइल क्रमांक आणि OTP सूचना पाळा. मी खाते पाहू शकत नाही किंवा OTP मागवू/पडताळू शकत नाही.',
      nextInvestor: 'भागीदार, आर्थिक माहिती, धोरणे, अहवाल, ESG आणि निबंधक माहितीसाठी Investor दुवे किंवा पृष्ठावरील विभाग वापरा.',
      nextTeam: 'कार्यस्थळ आणि संस्कृतीची माहिती पाहा, टीम अल्बम ब्राउझ करा किंवा अधिकृत संधींसाठी Careers उघडा.',
      nextAbout: 'कंपनीची माहिती, संचालक मंडळ आणि व्यवस्थापन टीमसाठी About नेव्हिगेशन वापरा.',
      nextGeneric: 'माहितीसाठी पृष्ठाचे शीर्षक आणि दिसणारे विभाग पाहा. कर्ज, EMI, लॉगिन किंवा संपर्क पृष्ठांसाठीही मी मार्गदर्शन करू शकतो.',
      explain: 'तुम्ही {page} पाहत आहात. या पृष्ठाबद्दल मी मदत करू शकतो, पण खाजगी खाते किंवा अर्ज माहिती पाहू शकत नाही.',
      apply: 'अर्ज पृष्ठात वैयक्तिक तपशील, ओळख पडताळणी आणि कर्जाची आवश्यकता विभाग आहेत. आधार आणि PAN आवश्यक; लागू व्यवसायासाठी GSTIN आहे. पृष्ठावरील नियंत्रणे वापरा. मी कागदपत्रे पडताळू किंवा अर्ज सबमिट करू शकत नाही.',
      pay: 'पेमेंट फॉर्म पाहण्यासाठी Pay EMI उघडा. पृष्ठ पेमेंट गेटवेशी जोडलेले नाही, EMI शोधू शकत नाही आणि पेमेंट सुरू किंवा साठवत नाही, असे सांगते.',
      account: 'Login पृष्ठावर मोबाइल क्रमांक आणि OTP प्रक्रिया आहे. सूचना पाळा. मी अर्ज शोधू, OTP मिळाल्याची किंवा खाते स्थितीची पुष्टी करू शकत नाही.',
      stuck: 'दिसणाऱ्या फील्ड किंवा पृष्ठ नियंत्रणांमध्ये मी मदत करू शकतो. आवश्यक फील्ड नाकारले असल्यास तिथे नेईन; अन्यथा तुम्ही काय करत होता ते सांगा.',
      contact: 'ग्राहक मदतीसाठी Contact पृष्ठावर 1800-103-5800 आणि info@namfin.in आहेत. तक्रारींसाठी compliance@namfin.in उपलब्ध आहे. पर्याय पाहण्यासाठी Contact Us उघडा.',
      products: 'उत्पादनाची माहिती आणि विद्यमान चौकशी/अर्ज नियंत्रणांसाठी उत्पादन पृष्ठ निवडा.',
      documents: 'अर्ज पृष्ठानुसार आधार आणि PAN आवश्यक आहेत. JPG, PNG किंवा PDF (कमाल 5 MB) अपलोड करा; लागू असल्यास GSTIN द्या. OTP विनंती किंवा स्कॅन म्हणजे पडताळणी पूर्ण झाली असे नाही.',
      invalid: 'आवश्यक फील्ड तपासा{field}. पुढे जाण्यापूर्वी ते भरा किंवा दुरुस्त करा.',
      invalidNoField: 'काही आवश्यक माहिती तपासावी लागेल. पुढे जाण्यापूर्वी पृष्ठावरील ठळक फील्ड पाहा.',
      allValid: 'फॉर्ममध्ये सध्या दिसणारे अवैध फील्ड नाही. माहिती तपासून तयार झाल्यावर पृष्ठावरील बटण वापरा; मी सबमिट करणार नाही.',
      unknown: 'या पृष्ठावर आणि विद्यमान कर्ज, पेमेंट, लॉगिन व सहाय्य मार्गांवर मी मदत करू शकतो. पात्रता किंवा खाते/पेमेंट स्थिती तपासू शकत नाही.',
      unsaved: 'तुम्ही भरलेली माहिती जतन झालेली नसेल. या पृष्ठावरून पुढे जायचे आहे का?',
      actionApply: 'कर्ज अर्ज उघडा', actionPay: 'EMI पेमेंट उघडा',
      actionLogin: 'Login उघडा', actionContact: 'Contact Us उघडा',
      actionProducts: 'कर्ज उत्पादने पाहा', actionBranch: 'शाखा शोधा',
      actionDocs: 'कागदपत्रांची आवश्यकता पाहा', actionFocus: 'आवश्यक फील्ड तपासा',
      actionBack: 'अर्ज तपशीलाकडे परत', actionSupport: 'ग्राहक सहाय्याशी संपर्क',
      contextPage: 'पृष्ठ', contextAbout: 'आमच्याबद्दल', contextInvestor: 'गुंतवणूकदार संबंध',
      contextTeam: 'आमची टीम', contextContact: 'संपर्क', contextPayment: 'EMI पेमेंट',
      contextLogin: 'Login', contextApply: 'कर्ज अर्ज', contextHome: 'मुख्यपृष्ठ',
      contextProduct: 'कर्ज उत्पादन', contextResult: 'प्री-अप्रूव्हल डेमो'
    },
    gu: {
      title: 'મદદગાર સાથી', subtitle: 'નામદેવ ફિનવેસ્ટ વેબસાઇટ માર્ગદર્શક',
      open: 'મદદગાર સાથી ખોલો', close: 'મદદગાર સાથી બંધ કરો', send: 'સંદેશ મોકલો',
      placeholder: 'આ પેજ વિશે પૂછો...', privacy: 'માત્ર વેબસાઇટ માર્ગદર્શક. તે ખાતાં જોઈ, ઓળખ ચકાસી કે ફોર્મ સબમિટ કરી શકતો નથી.',
      greeting: 'નમસ્તે! આ પેજ સમજવા અને આગળનું ઉપયોગી પગલું શોધવામાં હું મદદ કરી શકું છું.',
      chipNext: 'હવે શું કરવું?', chipExplain: 'આ પેજ સમજાવો',
      chipApply: 'લોન અરજીમાં મદદ', chipPay: 'EMI ચૂકવો', chipAccount: 'મારી અરજી શોધો',
      chipDocs: 'કયા દસ્તાવેજો?', chipStuck: 'હું અટવાયો છું', chipContact: 'સહાયનો સંપર્ક',
      chipProducts: 'લોન વિકલ્પો જુઓ', chipBranch: 'શાખા શોધો',
      nextHome: 'Products વિભાગમાં તમારી જરૂરિયાતનો લોન વિકલ્પ પસંદ કરો અથવા હાલનું લોન ખાતું હોય તો Pay EMI ખોલો.',
      nextProduct: 'આ પ્રોડક્ટ પેજ પર પાત્રતા અને દસ્તાવેજોની માહિતી વાંચો, પછી હાલનું Apply અથવા Enquire બટન વાપરો. લોન અરજી પેજ પણ ખોલી શકો છો.',
      nextApply: 'Personal Details, Identity Verification અને Loan Requirement વિભાગોની જરૂરી માહિતી ભરો, પછી પેજનું Generate Pre-Sanction Score બટન વાપરો. આધાર/PAN ચકાસણી માટે પેજના નિયંત્રણો અનુસરો. પરિણામ ડેમો પ્રી-અપ્રૂવલ છે, અંતિમ મંજૂરી નહીં.',
      nextResult: 'આ પેજ પરિણામને “DEMO PRE-APPROVAL GENERATED” કહે છે. આ અંતિમ લોન મંજૂરી કે ધિરાણકર્તાની પુષ્ટિ નથી. માહિતી બદલવા Back પસંદ કરો અથવા સત્તાવાર માર્ગદર્શન માટે સંપર્ક કરો.',
      nextPayment: 'પેજ કહે છે કે તે પેમેન્ટ ગેટવે સાથે જોડાયેલું નથી અને EMI જોઈ શકતું નથી. અહીં ચુકવણી શરૂ થતી નથી. ચૂકવતા પહેલાં સત્તાવાર લોન સ્ટેટમેન્ટ અથવા નામદેવ ફિનવેસ્ટ સાથે ખાતરી કરો.',
      nextContact: 'યોગ્ય Contact Us ટૅબ પસંદ કરો: સંપર્ક માહિતી, Branch Locator, Suggestion / Query અથવા Grievance Redressal. ફોર્મ માહિતી મોકલાય છે કે નહીં તે સ્પષ્ટ કરે છે.',
      nextLogin: 'આ પેજ પર બતાવેલી મોબાઇલ નંબર અને OTP પ્રક્રિયા અનુસરો. હું ખાતું જોઈ, OTP મંગાવી કે ચકાસી શકતો નથી.',
      nextInvestor: 'ભાગીદારો, નાણાકીય માહિતી, નીતિ, અહેવાલ, ESG અને રજિસ્ટ્રાર માહિતી માટે Investor લિંક્સ અથવા પેજના વિભાગો જુઓ.',
      nextTeam: 'કાર્યસ્થળ અને સંસ્કૃતિ વિશે જાણો, ટીમ આલ્બમ જુઓ અથવા સત્તાવાર તકો માટે Careers ખોલો.',
      nextAbout: 'કંપની, બોર્ડ ઑફ ડિરેક્ટર્સ અને મેનેજમેન્ટ ટીમ માટે About નેવિગેશન વાપરો.',
      nextGeneric: 'જરૂરી માહિતી માટે પેજનું શીર્ષક અને દેખાતા વિભાગો જુઓ. લોન, EMI, લૉગિન અથવા સંપર્ક પેજમાં પણ મદદ કરી શકું છું.',
      explain: 'તમે {page} જોઈ રહ્યા છો. આ પેજ સમજાવવામાં મદદ કરી શકું છું, પરંતુ ખાનગી ખાતા કે અરજીની માહિતી જોઈ શકતો નથી.',
      apply: 'અરજી પેજમાં વ્યક્તિગત વિગતો, ઓળખ ચકાસણી અને લોન જરૂરિયાત વિભાગો છે. આધાર અને PAN જરૂરી છે; લાગુ વ્યવસાય માટે GSTIN છે. પેજનાં નિયંત્રણો વાપરો. હું દસ્તાવેજ ચકાસી કે અરજી સબમિટ કરી શકતો નથી.',
      pay: 'ચુકવણી ફોર્મ જોવા Pay EMI ખોલો. પેજ કહે છે કે તે પેમેન્ટ ગેટવે સાથે જોડાયેલું નથી, EMI જોઈ શકતું નથી અને ચુકવણી શરૂ કે સંગ્રહતું નથી.',
      account: 'Login પેજ પર મોબાઇલ નંબર અને OTP પ્રક્રિયા છે. સૂચનાઓ અનુસરો. હું અરજી શોધી, OTP પહોંચ્યો કે ખાતાની સ્થિતિની પુષ્ટિ કરી શકતો નથી.',
      stuck: 'દેખાતા ફીલ્ડ અથવા પેજ નિયંત્રણોમાં મદદ કરી શકું છું. જરૂરી ફીલ્ડ નામંજૂર થયું હોય તો ત્યાં લઈ જઈશ; નહીં તો તમે શું કરવા માંગતા હતા તે કહો.',
      contact: 'ગ્રાહક સહાય માટે Contact પેજ પર 1800-103-5800 અને info@namfin.in છે. ફરિયાદ માટે compliance@namfin.in પણ છે. વિકલ્પો માટે Contact Us ખોલો.',
      products: 'ઉત્પાદનની માહિતી અને હાલનાં પૂછપરછ/અરજી નિયંત્રણો માટે પ્રોડક્ટ પેજ પસંદ કરો.',
      documents: 'અરજી પેજ મુજબ આધાર અને PAN જરૂરી છે. JPG, PNG અથવા PDF (મહત્તમ 5 MB) અપલોડ કરો; લાગુ પડે તો GSTIN આપો. OTP વિનંતી કે સ્કૅનથી ચકાસણી સફળ થઈ હોવાનું સાબિત થતું નથી.',
      invalid: 'જરૂરી ફીલ્ડ તપાસો{field}. આગળ વધતાં પહેલાં તેને ભરો અથવા સુધારો.',
      invalidNoField: 'કેટલીક જરૂરી માહિતી તપાસવાની છે. આગળ વધતાં પહેલાં પેજનાં ચિહ્નિત ફીલ્ડ જુઓ.',
      allValid: 'ફોર્મમાં હાલમાં કોઈ દેખાતું અમાન્ય ફીલ્ડ નથી. માહિતી તપાસીને તૈયાર હો ત્યારે પેજનું બટન વાપરો; હું સબમિટ નહીં કરું.',
      unknown: 'આ પેજ અને હાલના લોન, ચુકવણી, લૉગિન અને સહાય માર્ગોમાં મદદ કરી શકું છું. પાત્રતા કે ખાતા/ચુકવણી સ્થિતિ તપાસી શકતો નથી.',
      unsaved: 'તમે દાખલ કરેલી માહિતી કદાચ સાચવાઈ ન હોય. આ પેજ છોડીને આગળ વધવું છે?',
      actionApply: 'લોન અરજી ખોલો', actionPay: 'EMI ચુકવણી ખોલો',
      actionLogin: 'Login ખોલો', actionContact: 'Contact Us ખોલો',
      actionProducts: 'લોન પ્રોડક્ટ્સ જુઓ', actionBranch: 'શાખા શોધો',
      actionDocs: 'દસ્તાવેજ જરૂરિયાત જુઓ', actionFocus: 'જરૂરી ફીલ્ડ તપાસો',
      actionBack: 'અરજીની વિગતો પર પાછા', actionSupport: 'ગ્રાહક સહાયનો સંપર્ક',
      contextPage: 'પેજ', contextAbout: 'અમારા વિશે', contextInvestor: 'રોકાણકાર સંબંધ',
      contextTeam: 'અમારી ટીમ', contextContact: 'સંપર્ક', contextPayment: 'EMI ચુકવણી',
      contextLogin: 'Login', contextApply: 'લોન અરજી', contextHome: 'હોમ',
      contextProduct: 'લોન પ્રોડક્ટ', contextResult: 'પ્રી-અપ્રૂવલ ડેમો'
    },
    ur: {
      title: 'مددگار ساتھی', subtitle: 'نامدیو فِن ویسٹ ویب سائٹ رہنما',
      open: 'مددگار ساتھی کھولیں', close: 'مددگار ساتھی بند کریں', send: 'پیغام بھیجیں',
      placeholder: 'اس صفحے کے بارے میں پوچھیں...', privacy: 'صرف ویب سائٹ رہنما۔ یہ اکاؤنٹ نہیں دیکھ سکتا، شناخت کی تصدیق یا فارم جمع نہیں کر سکتا۔',
      greeting: 'السلام علیکم! میں اس صفحے کو سمجھنے اور اگلا مفید قدم بتانے میں مدد کر سکتا ہوں۔',
      chipNext: 'اب مجھے کیا کرنا چاہیے؟', chipExplain: 'یہ صفحہ سمجھائیں',
      chipApply: 'قرض کی درخواست میں مدد', chipPay: 'قسط ادا کریں', chipAccount: 'میری درخواست تلاش کریں',
      chipDocs: 'کون سی دستاویزات؟', chipStuck: 'میں پھنس گیا ہوں', chipContact: 'معاونت سے رابطہ',
      chipProducts: 'قرض کے اختیارات دیکھیں', chipBranch: 'برانچ تلاش کریں',
      nextHome: 'Products سیکشن میں اپنی ضرورت کے مطابق قرض منتخب کریں، یا پہلے سے قرض اکاؤنٹ ہونے پر Pay EMI کھولیں۔',
      nextProduct: 'اس پروڈکٹ صفحے پر اہلیت اور دستاویزات دیکھیں، پھر موجودہ Apply یا Enquire بٹن استعمال کریں۔ قرض کی درخواست کا صفحہ بھی کھول سکتے ہیں۔',
      nextApply: 'Personal Details، Identity Verification اور Loan Requirement کے ضروری خانے پُر کریں، پھر صفحے کا Generate Pre-Sanction Score بٹن استعمال کریں۔ آدھار/PAN کی تصدیق صفحے کے طریقے سے کریں۔ نتیجہ ڈیمو پری اپروول ہے، حتمی منظوری نہیں۔',
      nextResult: 'یہ صفحہ نتیجے کو “DEMO PRE-APPROVAL GENERATED” کہتا ہے۔ یہ حتمی قرض منظوری یا قرض دہندہ کی تصدیق نہیں۔ معلومات دیکھنے کے لیے Back استعمال کریں یا سرکاری رہنمائی کے لیے رابطہ کریں۔',
      nextPayment: 'صفحہ بتاتا ہے کہ یہ ادائیگی کے گیٹ وے سے منسلک نہیں اور آپ کی قسط نہیں دیکھ سکتا۔ یہاں ادائیگی شروع نہیں ہوتی۔ ادائیگی سے پہلے سرکاری قرض اسٹیٹمنٹ یا نامدیو فِن ویسٹ سے تصدیق کریں۔',
      nextContact: 'متعلقہ Contact Us ٹیب منتخب کریں: رابطے کی معلومات، Branch Locator، Suggestion / Query یا Grievance Redressal۔ فارم واضح کرتے ہیں کہ معلومات کب نہیں بھیجی جاتیں۔',
      nextLogin: 'اس صفحے پر موبائل نمبر اور OTP کے مراحل پر عمل کریں۔ میں اکاؤنٹ نہیں دیکھ سکتا اور OTP نہیں منگوا یا تصدیق کر سکتا۔',
      nextInvestor: 'شراکت داروں، مالی معلومات، پالیسیوں، رپورٹس، ESG اور رجسٹرار کے لیے Investor لنکس یا صفحے کے حصے دیکھیں۔',
      nextTeam: 'کام کی جگہ اور ثقافت کے بارے میں پڑھیں، ٹیم البمز دیکھیں یا سرکاری مواقع کے لیے Careers کھولیں۔',
      nextAbout: 'کمپنی، بورڈ آف ڈائریکٹرز اور انتظامی ٹیم کے لیے About نیویگیشن استعمال کریں۔',
      nextGeneric: 'مطلوبہ معلومات کے لیے صفحے کا عنوان اور حصے دیکھیں۔ میں قرض، قسط، لاگ اِن یا رابطے کے صفحے میں بھی مدد کر سکتا ہوں۔',
      explain: 'آپ {page} دیکھ رہے ہیں۔ میں اس صفحے کی رہنمائی کر سکتا ہوں، لیکن نجی اکاؤنٹ یا درخواست کی معلومات نہیں دیکھ سکتا۔',
      apply: 'درخواست کے صفحے میں ذاتی معلومات، شناخت کی تصدیق اور قرض کی ضرورت کے حصے ہیں۔ آدھار اور PAN ضروری ہیں؛ متعلقہ کاروبار کے لیے GSTIN موجود ہے۔ صفحے کے اپنے طریقے استعمال کریں۔ میں دستاویزات کی تصدیق یا درخواست جمع نہیں کر سکتا۔',
      pay: 'ادائیگی فارم دیکھنے کے لیے Pay EMI کھولیں۔ صفحہ بتاتا ہے کہ یہ ادائیگی کے گیٹ وے سے منسلک نہیں، قسط معلوم نہیں کر سکتا اور ادائیگی شروع یا محفوظ نہیں کرتا۔',
      account: 'Login صفحے پر موبائل نمبر اور OTP کا طریقہ ہے۔ ہدایات پر عمل کریں۔ میں درخواست تلاش، OTP کی ترسیل یا اکاؤنٹ کی حالت کی تصدیق نہیں کر سکتا۔',
      stuck: 'میں نظر آنے والے خانوں یا صفحے کے کنٹرولز میں مدد کر سکتا ہوں۔ اگر ضروری خانہ مسترد ہوا تو وہاں لے جاؤں گا؛ ورنہ بتائیں آپ کیا کرنے کی کوشش کر رہے تھے۔',
      contact: 'صارفین کی مدد کے لیے Contact صفحے پر 1800-103-5800 اور info@namfin.in ہیں۔ شکایات کے لیے compliance@namfin.in بھی ہے۔ اختیارات کے لیے Contact Us کھولیں۔',
      products: 'مصنوعات کی تفصیل اور موجودہ درخواست/پوچھ گچھ کے کنٹرولز کے لیے پروڈکٹ صفحہ منتخب کریں۔',
      documents: 'درخواست صفحے کے مطابق آدھار اور PAN ضروری ہیں۔ JPG، PNG یا PDF (زیادہ سے زیادہ 5 MB) اپ لوڈ کریں؛ جہاں لاگو ہو GSTIN دیں۔ OTP یا اسکین سے تصدیق مکمل ہونا ثابت نہیں ہوتا۔',
      invalid: 'ضروری خانہ دیکھیں{field}۔ آگے بڑھنے سے پہلے اسے پُر یا درست کریں۔',
      invalidNoField: 'کچھ ضروری معلومات درکار ہیں۔ آگے بڑھنے سے پہلے صفحے پر نشان زد خانے دیکھیں۔',
      allValid: 'اس فارم میں فی الحال کوئی نظر آنے والا غلط خانہ نہیں۔ معلومات دیکھ کر تیار ہوں تو صفحے کا موجودہ بٹن استعمال کریں؛ میں فارم جمع نہیں کروں گا۔',
      unknown: 'میں اس صفحے اور موجودہ قرض، ادائیگی، لاگ اِن اور معاونت کے راستوں میں مدد کر سکتا ہوں۔ اہلیت یا اکاؤنٹ/ادائیگی کی حالت نہیں دیکھ سکتا۔',
      unsaved: 'آپ کی درج کردہ معلومات محفوظ نہ ہوئی ہوں۔ کیا اس صفحے سے آگے جانا ہے؟',
      actionApply: 'قرض کی درخواست کھولیں', actionPay: 'قسط کی ادائیگی کھولیں',
      actionLogin: 'Login کھولیں', actionContact: 'Contact Us کھولیں',
      actionProducts: 'قرض کی مصنوعات دیکھیں', actionBranch: 'برانچ تلاش کریں',
      actionDocs: 'دستاویزات کی ضروریات دیکھیں', actionFocus: 'ضروری خانے دیکھیں',
      actionBack: 'درخواست کی تفصیلات پر واپس', actionSupport: 'صارفین کی معاونت سے رابطہ',
      contextPage: 'صفحہ', contextAbout: 'ہمارے بارے میں', contextInvestor: 'سرمایہ کار تعلقات',
      contextTeam: 'ہماری ٹیم', contextContact: 'رابطہ', contextPayment: 'قسط کی ادائیگی',
      contextLogin: 'Login', contextApply: 'قرض کی درخواست', contextHome: 'ہوم',
      contextProduct: 'قرض کی مصنوعات', contextResult: 'پری اپروول ڈیمو'
    },
    pa: {
      title: 'ਮਦਦਗਾਰ ਸਾਥੀ', subtitle: 'ਨਾਮਦੇਵ ਫਿਨਵੈਸਟ ਵੈੱਬਸਾਈਟ ਗਾਈਡ',
      open: 'ਮਦਦਗਾਰ ਸਾਥੀ ਖੋਲ੍ਹੋ', close: 'ਮਦਦਗਾਰ ਸਾਥੀ ਬੰਦ ਕਰੋ', send: 'ਸੁਨੇਹਾ ਭੇਜੋ',
      placeholder: 'ਇਸ ਪੰਨੇ ਬਾਰੇ ਪੁੱਛੋ...', privacy: 'ਸਿਰਫ਼ ਵੈੱਬਸਾਈਟ ਗਾਈਡ। ਇਹ ਖਾਤੇ ਨਹੀਂ ਵੇਖ ਸਕਦਾ, ਪਛਾਣ ਦੀ ਪੁਸ਼ਟੀ ਜਾਂ ਫਾਰਮ ਜਮ੍ਹਾਂ ਨਹੀਂ ਕਰ ਸਕਦਾ।',
      greeting: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਮੈਂ ਇਸ ਪੰਨੇ ਨੂੰ ਸਮਝਣ ਅਤੇ ਅਗਲਾ ਲਾਭਦਾਇਕ ਕਦਮ ਦੱਸਣ ਵਿੱਚ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ।',
      chipNext: 'ਹੁਣ ਮੈਨੂੰ ਕੀ ਕਰਨਾ ਚਾਹੀਦਾ ਹੈ?', chipExplain: 'ਇਹ ਪੰਨਾ ਸਮਝਾਓ',
      chipApply: 'ਕਰਜ਼ੇ ਦੀ ਅਰਜ਼ੀ ਵਿੱਚ ਮਦਦ', chipPay: 'EMI ਭਰੋ', chipAccount: 'ਮੇਰੀ ਅਰਜ਼ੀ ਲੱਭੋ',
      chipDocs: 'ਕਿਹੜੇ ਦਸਤਾਵੇਜ਼?', chipStuck: 'ਮੈਂ ਫਸ ਗਿਆ ਹਾਂ', chipContact: 'ਸਹਾਇਤਾ ਨਾਲ ਸੰਪਰਕ',
      chipProducts: 'ਕਰਜ਼ੇ ਦੇ ਵਿਕਲਪ ਵੇਖੋ', chipBranch: 'ਸ਼ਾਖਾ ਲੱਭੋ',
      nextHome: 'Products ਭਾਗ ਵਿੱਚ ਆਪਣੀ ਲੋੜ ਦਾ ਕਰਜ਼ਾ ਚੁਣੋ, ਜਾਂ ਪਹਿਲਾਂ ਤੋਂ ਕਰਜ਼ਾ ਖਾਤਾ ਹੈ ਤਾਂ Pay EMI ਖੋਲ੍ਹੋ।',
      nextProduct: 'ਇਸ ਉਤਪਾਦ ਪੰਨੇ ਉੱਤੇ ਯੋਗਤਾ ਅਤੇ ਦਸਤਾਵੇਜ਼ਾਂ ਦੀ ਜਾਣਕਾਰੀ ਵੇਖੋ, ਫਿਰ ਮੌਜੂਦਾ Apply ਜਾਂ Enquire ਬਟਨ ਵਰਤੋ। ਕਰਜ਼ਾ ਅਰਜ਼ੀ ਪੰਨਾ ਵੀ ਖੋਲ੍ਹ ਸਕਦੇ ਹੋ।',
      nextApply: 'Personal Details, Identity Verification ਅਤੇ Loan Requirement ਦੇ ਲੋੜੀਂਦੇ ਖਾਨੇ ਭਰੋ, ਫਿਰ ਪੰਨੇ ਦਾ Generate Pre-Sanction Score ਬਟਨ ਵਰਤੋ। ਆਧਾਰ/PAN ਦੀ ਪੁਸ਼ਟੀ ਪੰਨੇ ਦੇ ਕੰਟਰੋਲਾਂ ਨਾਲ ਕਰੋ। ਨਤੀਜਾ ਡੈਮੋ ਪ੍ਰੀ-ਅਪਰੂਵਲ ਹੈ, ਅੰਤਿਮ ਮਨਜ਼ੂਰੀ ਨਹੀਂ।',
      nextResult: 'ਇਹ ਪੰਨਾ ਨਤੀਜੇ ਨੂੰ “DEMO PRE-APPROVAL GENERATED” ਕਹਿੰਦਾ ਹੈ। ਇਹ ਅੰਤਿਮ ਕਰਜ਼ਾ ਮਨਜ਼ੂਰੀ ਜਾਂ ਰਿਣਦਾਤਾ ਦੀ ਪੁਸ਼ਟੀ ਨਹੀਂ। ਜਾਣਕਾਰੀ ਵੇਖਣ ਲਈ Back ਵਰਤੋ ਜਾਂ ਸਰਕਾਰੀ ਸਲਾਹ ਲਈ ਸੰਪਰਕ ਕਰੋ।',
      nextPayment: 'ਪੰਨਾ ਕਹਿੰਦਾ ਹੈ ਕਿ ਇਹ ਭੁਗਤਾਨ ਗੇਟਵੇ ਨਾਲ ਜੁੜਿਆ ਨਹੀਂ ਅਤੇ EMI ਨਹੀਂ ਵੇਖ ਸਕਦਾ। ਇੱਥੇ ਭੁਗਤਾਨ ਸ਼ੁਰੂ ਨਹੀਂ ਹੁੰਦਾ। ਭੁਗਤਾਨ ਤੋਂ ਪਹਿਲਾਂ ਅਧਿਕਾਰਤ ਕਰਜ਼ਾ ਬਿਆਨ ਜਾਂ ਨਾਮਦੇਵ ਫਿਨਵੈਸਟ ਨਾਲ ਪੁਸ਼ਟੀ ਕਰੋ।',
      nextContact: 'ਸੰਬੰਧਿਤ Contact Us ਟੈਬ ਚੁਣੋ: ਸੰਪਰਕ ਜਾਣਕਾਰੀ, Branch Locator, Suggestion / Query ਜਾਂ Grievance Redressal। ਫਾਰਮ ਦੱਸਦੇ ਹਨ ਕਿ ਜਾਣਕਾਰੀ ਕਦੋਂ ਨਹੀਂ ਭੇਜੀ ਜਾਂਦੀ।',
      nextLogin: 'ਇਸ ਪੰਨੇ ਉੱਤੇ ਮੋਬਾਈਲ ਨੰਬਰ ਅਤੇ OTP ਦੇ ਕਦਮਾਂ ਦੀ ਪਾਲਣਾ ਕਰੋ। ਮੈਂ ਖਾਤਾ ਨਹੀਂ ਵੇਖ ਸਕਦਾ ਜਾਂ OTP ਮੰਗਵਾ/ਪੁਸ਼ਟੀ ਨਹੀਂ ਕਰ ਸਕਦਾ।',
      nextInvestor: 'ਭਾਈਵਾਲਾਂ, ਵਿੱਤੀ ਜਾਣਕਾਰੀ, ਨੀਤੀਆਂ, ਰਿਪੋਰਟਾਂ, ESG ਅਤੇ ਰਜਿਸਟਰਾਰ ਲਈ Investor ਲਿੰਕ ਜਾਂ ਪੰਨੇ ਦੇ ਭਾਗ ਵਰਤੋ।',
      nextTeam: 'ਕੰਮਕਾਜ ਅਤੇ ਸੱਭਿਆਚਾਰ ਬਾਰੇ ਪੜ੍ਹੋ, ਟੀਮ ਐਲਬਮ ਵੇਖੋ ਜਾਂ ਸਰਕਾਰੀ ਮੌਕਿਆਂ ਲਈ Careers ਖੋਲ੍ਹੋ।',
      nextAbout: 'ਕੰਪਨੀ, ਡਾਇਰੈਕਟਰ ਬੋਰਡ ਅਤੇ ਪ੍ਰਬੰਧਨ ਟੀਮ ਲਈ About ਨੈਵੀਗੇਸ਼ਨ ਵਰਤੋ।',
      nextGeneric: 'ਲੋੜੀਂਦੀ ਜਾਣਕਾਰੀ ਲਈ ਪੰਨੇ ਦਾ ਸਿਰਲੇਖ ਅਤੇ ਦਿਖਦੇ ਭਾਗ ਵੇਖੋ। ਮੈਂ ਕਰਜ਼ੇ, EMI, ਲੌਗਇਨ ਜਾਂ ਸੰਪਰਕ ਪੰਨੇ ਵਿੱਚ ਵੀ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ।',
      explain: 'ਤੁਸੀਂ {page} ਵੇਖ ਰਹੇ ਹੋ। ਮੈਂ ਇਸ ਪੰਨੇ ਬਾਰੇ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ, ਪਰ ਨਿੱਜੀ ਖਾਤੇ ਜਾਂ ਅਰਜ਼ੀ ਦੀ ਜਾਣਕਾਰੀ ਨਹੀਂ ਵੇਖ ਸਕਦਾ।',
      apply: 'ਅਰਜ਼ੀ ਪੰਨੇ ਵਿੱਚ ਨਿੱਜੀ ਵੇਰਵੇ, ਪਛਾਣ ਪੁਸ਼ਟੀ ਅਤੇ ਕਰਜ਼ੇ ਦੀ ਲੋੜ ਵਾਲੇ ਭਾਗ ਹਨ। ਆਧਾਰ ਅਤੇ PAN ਲਾਜ਼ਮੀ ਹਨ; ਲਾਗੂ ਕਾਰੋਬਾਰ ਲਈ GSTIN ਹੈ। ਪੰਨੇ ਦੇ ਕੰਟਰੋਲ ਵਰਤੋ। ਮੈਂ ਦਸਤਾਵੇਜ਼ ਪੁਸ਼ਟੀ ਜਾਂ ਅਰਜ਼ੀ ਜਮ੍ਹਾਂ ਨਹੀਂ ਕਰ ਸਕਦਾ।',
      pay: 'ਭੁਗਤਾਨ ਫਾਰਮ ਲਈ Pay EMI ਖੋਲ੍ਹੋ। ਪੰਨਾ ਕਹਿੰਦਾ ਹੈ ਕਿ ਇਹ ਗੇਟਵੇ ਨਾਲ ਜੁੜਿਆ ਨਹੀਂ, EMI ਨਹੀਂ ਵੇਖ ਸਕਦਾ ਅਤੇ ਭੁਗਤਾਨ ਸ਼ੁਰੂ ਜਾਂ ਸਟੋਰ ਨਹੀਂ ਕਰਦਾ।',
      account: 'Login ਪੰਨੇ ਉੱਤੇ ਮੋਬਾਈਲ ਨੰਬਰ ਅਤੇ OTP ਪ੍ਰਕਿਰਿਆ ਹੈ। ਹਦਾਇਤਾਂ ਮੰਨੋ। ਮੈਂ ਅਰਜ਼ੀ ਲੱਭਣ, OTP ਆਉਣ ਜਾਂ ਖਾਤੇ ਦੀ ਸਥਿਤੀ ਦੀ ਪੁਸ਼ਟੀ ਨਹੀਂ ਕਰ ਸਕਦਾ।',
      stuck: 'ਦਿਖਦੇ ਖਾਨਿਆਂ ਜਾਂ ਪੰਨੇ ਦੇ ਕੰਟਰੋਲਾਂ ਵਿੱਚ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ। ਜੇ ਲੋੜੀਂਦਾ ਖਾਨਾ ਰੱਦ ਹੋਇਆ ਤਾਂ ਉੱਥੇ ਲੈ ਜਾਵਾਂਗਾ; ਨਹੀਂ ਤਾਂ ਦੱਸੋ ਕਿ ਤੁਸੀਂ ਕੀ ਕਰ ਰਹੇ ਸੀ।',
      contact: 'ਗਾਹਕ ਸਹਾਇਤਾ ਲਈ Contact ਪੰਨੇ ਉੱਤੇ 1800-103-5800 ਅਤੇ info@namfin.in ਹਨ। ਸ਼ਿਕਾਇਤਾਂ ਲਈ compliance@namfin.in ਵੀ ਹੈ। ਵਿਕਲਪਾਂ ਲਈ Contact Us ਖੋਲ੍ਹੋ।',
      products: 'ਉਤਪਾਦ ਦੀ ਜਾਣਕਾਰੀ ਅਤੇ ਮੌਜੂਦਾ ਪੁੱਛਗਿੱਛ/ਅਰਜ਼ੀ ਕੰਟਰੋਲਾਂ ਲਈ ਉਤਪਾਦ ਪੰਨਾ ਚੁਣੋ।',
      documents: 'ਅਰਜ਼ੀ ਪੰਨੇ ਅਨੁਸਾਰ ਆਧਾਰ ਅਤੇ PAN ਲਾਜ਼ਮੀ ਹਨ। JPG, PNG ਜਾਂ PDF (ਵੱਧ ਤੋਂ ਵੱਧ 5 MB) ਅੱਪਲੋਡ ਕਰੋ; ਜਿੱਥੇ ਲਾਗੂ ਹੋਵੇ GSTIN ਦਿਓ। OTP ਜਾਂ ਸਕੈਨ ਨਾਲ ਪੁਸ਼ਟੀ ਪੂਰੀ ਹੋਣ ਦਾ ਸਬੂਤ ਨਹੀਂ ਮਿਲਦਾ।',
      invalid: 'ਲੋੜੀਂਦਾ ਖਾਨਾ ਵੇਖੋ{field}। ਅੱਗੇ ਵਧਣ ਤੋਂ ਪਹਿਲਾਂ ਇਸਨੂੰ ਭਰੋ ਜਾਂ ਠੀਕ ਕਰੋ।',
      invalidNoField: 'ਕੁਝ ਲੋੜੀਂਦੀ ਜਾਣਕਾਰੀ ਵੱਲ ਧਿਆਨ ਦਿਓ। ਅੱਗੇ ਵਧਣ ਤੋਂ ਪਹਿਲਾਂ ਪੰਨੇ ਦੇ ਨਿਸ਼ਾਨ ਲੱਗੇ ਖਾਨੇ ਵੇਖੋ।',
      allValid: 'ਇਸ ਫਾਰਮ ਵਿੱਚ ਇਸ ਵੇਲੇ ਕੋਈ ਦਿਖਦਾ ਗਲਤ ਖਾਨਾ ਨਹੀਂ। ਜਾਣਕਾਰੀ ਵੇਖ ਕੇ ਤਿਆਰ ਹੋਵੋ ਤਾਂ ਪੰਨੇ ਦਾ ਮੌਜੂਦਾ ਬਟਨ ਵਰਤੋ; ਮੈਂ ਜਮ੍ਹਾਂ ਨਹੀਂ ਕਰਾਂਗਾ।',
      unknown: 'ਮੈਂ ਇਸ ਪੰਨੇ ਅਤੇ ਮੌਜੂਦਾ ਕਰਜ਼ਾ, ਭੁਗਤਾਨ, ਲੌਗਇਨ ਅਤੇ ਸਹਾਇਤਾ ਰਾਹਾਂ ਵਿੱਚ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ। ਯੋਗਤਾ ਜਾਂ ਖਾਤਾ/ਭੁਗਤਾਨ ਸਥਿਤੀ ਨਹੀਂ ਵੇਖ ਸਕਦਾ।',
      unsaved: 'ਤੁਹਾਡੀ ਭਰੀ ਜਾਣਕਾਰੀ ਸ਼ਾਇਦ ਸੰਭਾਲੀ ਨਾ ਗਈ ਹੋਵੇ। ਕੀ ਇਸ ਪੰਨੇ ਤੋਂ ਅੱਗੇ ਜਾਣਾ ਹੈ?',
      actionApply: 'ਕਰਜ਼ਾ ਅਰਜ਼ੀ ਖੋਲ੍ਹੋ', actionPay: 'EMI ਭੁਗਤਾਨ ਖੋਲ੍ਹੋ',
      actionLogin: 'Login ਖੋਲ੍ਹੋ', actionContact: 'Contact Us ਖੋਲ੍ਹੋ',
      actionProducts: 'ਕਰਜ਼ਾ ਉਤਪਾਦ ਵੇਖੋ', actionBranch: 'ਸ਼ਾਖਾ ਲੱਭੋ',
      actionDocs: 'ਦਸਤਾਵੇਜ਼ ਲੋੜਾਂ ਵੇਖੋ', actionFocus: 'ਲੋੜੀਂਦੇ ਖਾਨੇ ਵੇਖੋ',
      actionBack: 'ਅਰਜ਼ੀ ਵੇਰਵਿਆਂ ਵੱਲ ਵਾਪਸ', actionSupport: 'ਗਾਹਕ ਸਹਾਇਤਾ ਨਾਲ ਸੰਪਰਕ',
      contextPage: 'ਪੰਨਾ', contextAbout: 'ਸਾਡੇ ਬਾਰੇ', contextInvestor: 'ਨਿਵੇਸ਼ਕ ਸੰਬੰਧ',
      contextTeam: 'ਸਾਡੀ ਟੀਮ', contextContact: 'ਸੰਪਰਕ', contextPayment: 'EMI ਭੁਗਤਾਨ',
      contextLogin: 'Login', contextApply: 'ਕਰਜ਼ਾ ਅਰਜ਼ੀ', contextHome: 'ਮੁੱਖ ਪੰਨਾ',
      contextProduct: 'ਕਰਜ਼ਾ ਉਤਪਾਦ', contextResult: 'ਪ੍ਰੀ-ਅਪਰੂਵਲ ਡੈਮੋ'
    },
    or: {
      title: 'ସହାୟକ ବନ୍ଧୁ', subtitle: 'ନାମଦେବ ଫିନଭେଷ୍ଟ ୱେବସାଇଟ୍ ମାର୍ଗଦର୍ଶକ',
      open: 'ସହାୟକ ବନ୍ଧୁ ଖୋଲନ୍ତୁ', close: 'ସହାୟକ ବନ୍ଧୁ ବନ୍ଦ କରନ୍ତୁ', send: 'ବାର୍ତ୍ତା ପଠାନ୍ତୁ',
      placeholder: 'ଏହି ପୃଷ୍ଠା ବିଷୟରେ ପଚାରନ୍ତୁ...', privacy: 'କେବଳ ୱେବସାଇଟ୍ ମାର୍ଗଦର୍ଶକ। ଏହା ଖାତା ଦେଖି, ପରିଚୟ ଯାଞ୍ଚ କିମ୍ବା ଫର୍ମ ଦାଖଲ କରିପାରେ ନାହିଁ।',
      greeting: 'ନମସ୍କାର! ଏହି ପୃଷ୍ଠା ବୁଝିବା ଏବଂ ପରବର୍ତ୍ତୀ ଉପଯୋଗୀ ପଦକ୍ଷେପ ଜାଣିବାରେ ମୁଁ ସାହାଯ୍ୟ କରିପାରିବି।',
      chipNext: 'ଏବେ କଣ କରିବି?', chipExplain: 'ଏହି ପୃଷ୍ଠା ବୁଝାନ୍ତୁ',
      chipApply: 'ଋଣ ଆବେଦନରେ ସାହାଯ୍ୟ', chipPay: 'EMI ଦିଅନ୍ତୁ', chipAccount: 'ମୋ ଆବେଦନ ଖୋଜନ୍ତୁ',
      chipDocs: 'କେଉଁ ଦଲିଲ?', chipStuck: 'ମୁଁ ଅଟକି ଯାଇଛି', chipContact: 'ସହାୟତା ସହ ଯୋଗାଯୋଗ',
      chipProducts: 'ଋଣ ବିକଳ୍ପ ଦେଖନ୍ତୁ', chipBranch: 'ଶାଖା ଖୋଜନ୍ତୁ',
      nextHome: 'Products ବିଭାଗରୁ ଆପଣଙ୍କ ଆବଶ୍ୟକତା ଅନୁସାରେ ଋଣ ବାଛନ୍ତୁ, କିମ୍ବା ପୂର୍ବରୁ ଋଣ ଖାତା ଥିଲେ Pay EMI ଖୋଲନ୍ତୁ।',
      nextProduct: 'ଏହି ଉତ୍ପାଦ ପୃଷ୍ଠାରେ ଯୋଗ୍ୟତା ଏବଂ ଦଲିଲ ସୂଚନା ପଢ଼ି, ମୌଜୁଦା Apply କିମ୍ବା Enquire ବଟନ୍ ବ୍ୟବହାର କରନ୍ତୁ। ଋଣ ଆବେଦନ ପୃଷ୍ଠାକୁ ମଧ୍ୟ ଯାଇପାରିବେ।',
      nextApply: 'Personal Details, Identity Verification ଏବଂ Loan Requirement ର ଆବଶ୍ୟକ ଘର ପୂରଣ କରି, ପୃଷ୍ଠାର Generate Pre-Sanction Score ବଟନ୍ ବ୍ୟବହାର କରନ୍ତୁ। ଆଧାର/PAN ଯାଞ୍ଚ ପାଇଁ ପୃଷ୍ଠାର ନିୟନ୍ତ୍ରଣ ଅନୁସରଣ କରନ୍ତୁ। ଫଳାଫଳ ଡେମୋ ପ୍ରି-ଅପ୍ରୁଭାଲ୍, ଅନ୍ତିମ ମଞ୍ଜୁରି ନୁହେଁ।',
      nextResult: 'ଏହି ପୃଷ୍ଠା ଫଳାଫଳକୁ “DEMO PRE-APPROVAL GENERATED” ବୋଲି ଦର୍ଶାଏ। ଏହା ଅନ୍ତିମ ଋଣ ମଞ୍ଜୁରି କିମ୍ବା ଋଣଦାତାଙ୍କ ପୁଷ୍ଟି ନୁହେଁ। ତଥ୍ୟ ସମୀକ୍ଷା ପାଇଁ Back ବ୍ୟବହାର କରନ୍ତୁ କିମ୍ବା ଅଧିକାରିକ ସହାୟତା ପାଇଁ ଯୋଗାଯୋଗ କରନ୍ତୁ।',
      nextPayment: 'ଏହି ପୃଷ୍ଠା ପେମେଣ୍ଟ ଗେଟୱେ ସହ ଯୋଡ଼ା ନାହିଁ ଏବଂ EMI ଖୋଜିପାରେ ନାହିଁ ବୋଲି କହେ। ଏଠାରେ ପେମେଣ୍ଟ ଆରମ୍ଭ ହୁଏ ନାହିଁ। ପେମେଣ୍ଟ ପୂର୍ବରୁ ଅଧିକାରିକ ଋଣ ବିବରଣୀ କିମ୍ବା ନାମଦେବ ଫିନଭେଷ୍ଟ ସହ ଯାଞ୍ଚ କରନ୍ତୁ।',
      nextContact: 'ଉପଯୁକ୍ତ Contact Us ଟ୍ୟାବ୍ ବାଛନ୍ତୁ: ଯୋଗାଯୋଗ ସୂଚନା, Branch Locator, Suggestion / Query କିମ୍ବା Grievance Redressal। ଫର୍ମଗୁଡ଼ିକ ତଥ୍ୟ ପଠାଯାଉଛି କି ନାହିଁ ସ୍ପଷ୍ଟ କରନ୍ତି।',
      nextLogin: 'ଏହି ପୃଷ୍ଠାର ମୋବାଇଲ୍ ନମ୍ବର ଏବଂ OTP ପଦକ୍ଷେପ ଅନୁସରଣ କରନ୍ତୁ। ମୁଁ ଖାତା ଦେଖି, OTP ମାଗି କିମ୍ବା ଯାଞ୍ଚ କରିପାରେ ନାହିଁ।',
      nextInvestor: 'ସହଭାଗୀ, ଆର୍ଥିକ ସୂଚନା, ନୀତି, ରିପୋର୍ଟ, ESG ଏବଂ ରେଜିଷ୍ଟ୍ରାର ସୂଚନା ପାଇଁ Investor ଲିଙ୍କ୍ କିମ୍ବା ପୃଷ୍ଠାର ବିଭାଗ ଦେଖନ୍ତୁ।',
      nextTeam: 'କାର୍ଯ୍ୟସ୍ଥଳ ଏବଂ ସଂସ୍କୃତି ପଢ଼ନ୍ତୁ, ଟିମ୍ ଆଲବମ୍ ଦେଖନ୍ତୁ କିମ୍ବା ଅଧିକାରିକ ସୁଯୋଗ ପାଇଁ Careers ଖୋଲନ୍ତୁ।',
      nextAbout: 'କମ୍ପାନୀ, ବୋର୍ଡ ଅଫ୍ ଡାଇରେକ୍ଟର୍ସ ଏବଂ ପରିଚାଳନା ଦଳ ପାଇଁ About ନାଭିଗେସନ୍ ବ୍ୟବହାର କରନ୍ତୁ।',
      nextGeneric: 'ଆବଶ୍ୟକ ସୂଚନା ପାଇଁ ପୃଷ୍ଠା ଶୀର୍ଷକ ଏବଂ ଦୃଶ୍ୟମାନ ବିଭାଗ ଦେଖନ୍ତୁ। ଋଣ, EMI, ଲଗଇନ୍ କିମ୍ବା ଯୋଗାଯୋଗ ପୃଷ୍ଠାରେ ମଧ୍ୟ ସାହାଯ୍ୟ କରିପାରିବି।',
      explain: 'ଆପଣ {page} ଦେଖୁଛନ୍ତି। ଏହି ପୃଷ୍ଠା ବିଷୟରେ ମୁଁ ସାହାଯ୍ୟ କରିପାରିବି, କିନ୍ତୁ ବ୍ୟକ୍ତିଗତ ଖାତା କିମ୍ବା ଆବେଦନ ସୂଚନା ଦେଖିପାରେ ନାହିଁ।',
      apply: 'ଆବେଦନ ପୃଷ୍ଠାରେ ବ୍ୟକ୍ତିଗତ ବିବରଣୀ, ପରିଚୟ ଯାଞ୍ଚ ଏବଂ ଋଣ ଆବଶ୍ୟକତା ବିଭାଗ ଅଛି। ଆଧାର ଏବଂ PAN ଆବଶ୍ୟକ; ପ୍ରଯୋଜ୍ୟ ବ୍ୟବସାୟ ପାଇଁ GSTIN ଅଛି। ପୃଷ୍ଠାର ନିୟନ୍ତ୍ରଣ ବ୍ୟବହାର କରନ୍ତୁ। ମୁଁ ଦଲିଲ ଯାଞ୍ଚ କିମ୍ବା ଆବେଦନ ଦାଖଲ କରିପାରେ ନାହିଁ।',
      pay: 'ପେମେଣ୍ଟ ଫର୍ମ ଦେଖିବାକୁ Pay EMI ଖୋଲନ୍ତୁ। ପୃଷ୍ଠା କହେ ଯେ ଏହା ପେମେଣ୍ଟ ଗେଟୱେ ସହ ଯୋଡ଼ା ନାହିଁ, EMI ଖୋଜିପାରେ ନାହିଁ ଏବଂ ପେମେଣ୍ଟ ଆରମ୍ଭ କିମ୍ବା ସଞ୍ଚୟ କରେ ନାହିଁ।',
      account: 'Login ପୃଷ୍ଠାରେ ମୋବାଇଲ୍ ନମ୍ବର ଏବଂ OTP ପ୍ରକ୍ରିୟା ଅଛି। ନିର୍ଦ୍ଦେଶ ଅନୁସରଣ କରନ୍ତୁ। ମୁଁ ଆବେଦନ ଖୋଜି, OTP ମିଳିବା କିମ୍ବା ଖାତା ସ୍ଥିତି ନିଶ୍ଚିତ କରିପାରେ ନାହିଁ।',
      stuck: 'ଦୃଶ୍ୟମାନ ଘର କିମ୍ବା ପୃଷ୍ଠା ନିୟନ୍ତ୍ରଣରେ ସାହାଯ୍ୟ କରିପାରିବି। ଆବଶ୍ୟକ ଘର ଅସ୍ୱୀକୃତ ହୋଇଥିଲେ ସେଠାକୁ ନେବି; ନଚେତ୍ ଆପଣ କଣ କରିବାକୁ ଚାହୁଁଥିଲେ କହନ୍ତୁ।',
      contact: 'ଗ୍ରାହକ ସହାୟତା ପାଇଁ Contact ପୃଷ୍ଠାରେ 1800-103-5800 ଏବଂ info@namfin.in ଅଛି। ଅଭିଯୋଗ ପାଇଁ compliance@namfin.in ଅଛି। ବିକଳ୍ପ ପାଇଁ Contact Us ଖୋଲନ୍ତୁ।',
      products: 'ଉତ୍ପାଦ ବିବରଣୀ ଏବଂ ମୌଜୁଦା ଆବେଦନ/ପଚାରା ନିୟନ୍ତ୍ରଣ ପାଇଁ ଉତ୍ପାଦ ପୃଷ୍ଠା ବାଛନ୍ତୁ।',
      documents: 'ଆବେଦନ ପୃଷ୍ଠା ଅନୁଯାୟୀ ଆଧାର ଏବଂ PAN ଆବଶ୍ୟକ। JPG, PNG କିମ୍ବା PDF (ସର୍ବାଧିକ 5 MB) ଅପଲୋଡ୍ କରନ୍ତୁ; ପ୍ରଯୋଜ୍ୟ ହେଲେ GSTIN ଦିଅନ୍ତୁ। OTP ଅନୁରୋଧ କିମ୍ବା ସ୍କାନ୍ ଦ୍ୱାରା ଯାଞ୍ଚ ସଫଳ ହୋଇଥିବା ପ୍ରମାଣ ମିଳେ ନାହିଁ।',
      invalid: 'ଆବଶ୍ୟକ ଘର ଯାଞ୍ଚ କରନ୍ତୁ{field}। ଆଗକୁ ବଢ଼ିବା ପୂର୍ବରୁ ଏହା ପୂରଣ କିମ୍ବା ସଠିକ୍ କରନ୍ତୁ।',
      invalidNoField: 'କିଛି ଆବଶ୍ୟକ ସୂଚନା ଯାଞ୍ଚ କରିବା ଦରକାର। ଆଗକୁ ବଢ଼ିବା ପୂର୍ବରୁ ଚିହ୍ନିତ ଘର ଦେଖନ୍ତୁ।',
      allValid: 'ଏହି ଫର୍ମରେ ବର୍ତ୍ତମାନ ଦୃଶ୍ୟମାନ ଅବୈଧ ଘର ନାହିଁ। ତଥ୍ୟ ଯାଞ୍ଚ କରି ପ୍ରସ୍ତୁତ ହେଲେ ପୃଷ୍ଠାର ବଟନ୍ ବ୍ୟବହାର କରନ୍ତୁ; ମୁଁ ଦାଖଲ କରିବି ନାହିଁ।',
      unknown: 'ଏହି ପୃଷ୍ଠା ଏବଂ ମୌଜୁଦା ଋଣ, ପେମେଣ୍ଟ, ଲଗଇନ୍ ଓ ସହାୟତା ରାସ୍ତାରେ ମୁଁ ସାହାଯ୍ୟ କରିପାରିବି। ଯୋଗ୍ୟତା କିମ୍ବା ଖାତା/ପେମେଣ୍ଟ ସ୍ଥିତି ଯାଞ୍ଚ କରିପାରେ ନାହିଁ।',
      unsaved: 'ଆପଣ ଦେଇଥିବା ସୂଚନା ସଞ୍ଚୟ ହୋଇନଥାଇପାରେ। ଏହି ପୃଷ୍ଠା ଛାଡ଼ି ଆଗକୁ ଯିବେ?',
      actionApply: 'ଋଣ ଆବେଦନ ଖୋଲନ୍ତୁ', actionPay: 'EMI ପେମେଣ୍ଟ ଖୋଲନ୍ତୁ',
      actionLogin: 'Login ଖୋଲନ୍ତୁ', actionContact: 'Contact Us ଖୋଲନ୍ତୁ',
      actionProducts: 'ଋଣ ଉତ୍ପାଦ ଦେଖନ୍ତୁ', actionBranch: 'ଶାଖା ଖୋଜନ୍ତୁ',
      actionDocs: 'ଦଲିଲ ଆବଶ୍ୟକତା ଦେଖନ୍ତୁ', actionFocus: 'ଆବଶ୍ୟକ ଘର ଯାଞ୍ଚ କରନ୍ତୁ',
      actionBack: 'ଆବେଦନ ବିବରଣୀକୁ ଫେରନ୍ତୁ', actionSupport: 'ଗ୍ରାହକ ସହାୟତା ସହ ଯୋଗାଯୋଗ',
      contextPage: 'ପୃଷ୍ଠା', contextAbout: 'ଆମ ବିଷୟରେ', contextInvestor: 'ନିବେଶକ ସମ୍ପର୍କ',
      contextTeam: 'ଆମ ଦଳ', contextContact: 'ଯୋଗାଯୋଗ', contextPayment: 'EMI ପେମେଣ୍ଟ',
      contextLogin: 'Login', contextApply: 'ଋଣ ଆବେଦନ', contextHome: 'ମୂଳପୃଷ୍ଠା',
      contextProduct: 'ଋଣ ଉତ୍ପାଦ', contextResult: 'ପ୍ରି-ଅପ୍ରୁଭାଲ୍ ଡେମୋ'
    }
  };

  const AVAILABLE_LANGUAGES = new Set(['en', 'hi', 'mr', 'gu', 'ur', 'pa', 'or']);
  const PRODUCT_ROUTES = new Set([
    'msme.html', 'two-wheeler.html', 'e-rickshaw.html', 'lap.html',
    'solar.html', 'tractor.html'
  ]);
  const KNOWN_ROUTES = new Set([
    'index.html', 'about.html', 'investor.html', 'team.html', 'contact.html',
    'payment.html', 'login.html', 'apply.html', ...PRODUCT_ROUTES
  ]);

  const currentLanguage = () => {
    const candidate = (
      localStorage.getItem('namfin_language') ||
      document.documentElement.lang ||
      'en'
    ).toLowerCase().split('-')[0];
    return AVAILABLE_LANGUAGES.has(candidate) ? candidate : 'en';
  };

  let language = currentLanguage();
  let copy = COPY[language] || COPY.en;

  const text = (key, values = {}) => {
    let result = copy[key] || COPY.en[key] || key;
    Object.entries(values).forEach(([name, value]) => {
      result = result.replace(`{${name}}`, value);
    });
    return result;
  };

  const getRoute = () => window.location.pathname.split('/').filter(Boolean).pop() || 'index.html';
  const getPageType = () => {
    const route = getRoute();
    if (route === 'apply.html') {
      const resultView = document.getElementById('approval-view');
      return resultView && !resultView.hidden ? 'result' : 'apply';
    }
    if (route === 'index.html' || route === '') return 'home';
    if (PRODUCT_ROUTES.has(route)) return 'product';
    if (route === 'about.html') return 'about';
    if (route === 'investor.html') return 'investor';
    if (route === 'team.html') return 'team';
    if (route === 'contact.html') return 'contact';
    if (route === 'payment.html') return 'payment';
    if (route === 'login.html') return 'login';
    return KNOWN_ROUTES.has(route) ? 'generic' : 'generic';
  };

  const PAGE_CONTEXT_KEYS = {
    home: 'contextHome', product: 'contextProduct', apply: 'contextApply',
    result: 'contextResult', payment: 'contextPayment', login: 'contextLogin',
    contact: 'contextContact', investor: 'contextInvestor', team: 'contextTeam',
    about: 'contextAbout', generic: 'contextPage'
  };
  const NEXT_MESSAGE_KEYS = {
    home: 'nextHome', product: 'nextProduct', apply: 'nextApply',
    result: 'nextResult', payment: 'nextPayment', login: 'nextLogin',
    contact: 'nextContact', investor: 'nextInvestor', team: 'nextTeam',
    about: 'nextAbout', generic: 'nextGeneric'
  };

  const findVisibleInvalidField = (form = document) => {
    const invalidFields = form.querySelectorAll('input:invalid, select:invalid, textarea:invalid');
    return Array.from(invalidFields).find((field) =>
      !field.disabled && field.type !== 'hidden' && field.getClientRects().length > 0
    ) || null;
  };

  const getFieldLabel = (field) => {
    if (!field) return '';
    const label = field.labels?.[0]?.textContent?.replace(/\s+/g, ' ').trim();
    return label || field.getAttribute('aria-label') || field.placeholder || '';
  };

  const hasUnsavedFormData = () => {
    return Array.from(document.querySelectorAll('form input, form select, form textarea')).some((field) => {
      if (field.disabled || field.type === 'hidden' || field.getClientRects().length === 0) return false;
      if (field.type === 'file') return Boolean(field.files?.length);
      if (field.type === 'checkbox' || field.type === 'radio') return field.checked !== field.defaultChecked;
      return field.value !== field.defaultValue;
    });
  };

  const widget = document.createElement('section');
  widget.className = 'helpful-buddy';
  widget.setAttribute('aria-label', 'Helpful Buddy');
  widget.innerHTML = `
    <section class="buddy-panel" id="helpfulBuddyPanel" role="dialog" aria-modal="false" aria-labelledby="buddyTitle" hidden>
      <header class="buddy-header">
        <span class="buddy-avatar" aria-hidden="true">
          <svg viewBox="0 0 32 32" fill="none" width="25" height="25">
            <path d="M6 18.5a10 10 0 1 1 20 0v3.2a2.3 2.3 0 0 1-2.3 2.3h-1.4v-7h3.5M6 17h3.5v7H8.3A2.3 2.3 0 0 1 6 21.7V17Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 25.5c1.1 1.1 2.4 1.5 4 1.5h2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <circle cx="19" cy="12" r="1" fill="currentColor"/>
          </svg>
        </span>
        <div class="buddy-heading">
          <h2 id="buddyTitle"></h2>
          <p id="buddySubtitle"></p>
        </div>
        <button class="buddy-close" id="buddyClose" type="button"></button>
      </header>
      <div class="buddy-context" id="buddyContext"></div>
      <div class="buddy-messages" id="buddyMessages" aria-live="polite" aria-relevant="additions text"></div>
      <div class="buddy-suggestions" id="buddySuggestions" aria-label="Suggested questions"></div>
      <form class="buddy-composer" id="buddyComposer">
        <input id="buddyInput" type="text" maxlength="500" autocomplete="off">
        <button type="submit" id="buddySend"></button>
      </form>
      <p class="buddy-privacy-note" id="buddyPrivacy"></p>
    </section>
    <button class="buddy-launcher" id="buddyLauncher" type="button" aria-controls="helpfulBuddyPanel" aria-expanded="false">
      <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M16 4.5c-6.3 0-11.5 4.8-11.5 10.8 0 2.4.8 4.6 2.3 6.4l-.9 5.8 6.2-2.7c1.2.4 2.5.6 3.9.6 6.3 0 11.5-4.8 11.5-10.7S22.3 4.5 16 4.5Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
        <path d="M10.5 16.2h.1m5.3 0h.1m5.3 0h.1" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/>
      </svg>
    </button>`;

  if (document.body) document.body.appendChild(widget);

  const panel = widget.querySelector('#helpfulBuddyPanel');
  const launcher = widget.querySelector('#buddyLauncher');
  const closeButton = widget.querySelector('#buddyClose');
  const messages = widget.querySelector('#buddyMessages');
  const suggestions = widget.querySelector('#buddySuggestions');
  const context = widget.querySelector('#buddyContext');
  const composer = widget.querySelector('#buddyComposer');
  const input = widget.querySelector('#buddyInput');
  const sendButton = widget.querySelector('#buddySend');
  let greeted = false;
  let pendingInvalidField = null;
  let lastFocus = null;

  const visibleHeading = () => {
    const headings = Array.from(document.querySelectorAll('h1'));
    const heading = headings.find((element) =>
      element.getClientRects().length > 0 && !element.closest('[hidden]')
    );
    return heading?.textContent.replace(/\s+/g, ' ').trim() || document.title;
  };

  const renderSuggestions = () => {
    const page = getPageType();
    let choices;
    if (page === 'apply') {
      choices = [['chipNext', 'next'], ['chipDocs', 'documents'], ['chipStuck', 'stuck'], ['chipContact', 'contact']];
    } else if (page === 'result') {
      choices = [['chipExplain', 'explain'], ['chipContact', 'contact'], ['chipApply', 'apply']];
    } else if (page === 'payment') {
      choices = [['chipNext', 'next'], ['chipApply', 'apply'], ['chipContact', 'contact']];
    } else if (page === 'login') {
      choices = [['chipNext', 'next'], ['chipAccount', 'account'], ['chipStuck', 'stuck'], ['chipContact', 'contact']];
    } else if (page === 'contact') {
      choices = [['chipNext', 'next'], ['chipBranch', 'branch'], ['chipStuck', 'stuck'], ['chipContact', 'contact']];
    } else if (page === 'product') {
      choices = [['chipNext', 'next'], ['chipApply', 'apply'], ['chipProducts', 'products'], ['chipPay', 'pay'], ['chipContact', 'contact']];
    } else if (page === 'home') {
      choices = [['chipNext', 'next'], ['chipProducts', 'products'], ['chipApply', 'apply'], ['chipPay', 'pay'], ['chipAccount', 'account'], ['chipContact', 'contact']];
    } else {
      choices = [['chipNext', 'next'], ['chipExplain', 'explain'], ['chipProducts', 'products'], ['chipPay', 'pay'], ['chipContact', 'contact']];
    }

    suggestions.replaceChildren();
    choices.forEach(([labelKey, intent]) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'buddy-chip';
      chip.textContent = text(labelKey);
      chip.dataset.intent = intent;
      suggestions.appendChild(chip);
    });
  };

  const renderLanguage = () => {
    copy = COPY[language] || COPY.en;
    launcher.setAttribute('aria-label', text('open'));
    closeButton.setAttribute('aria-label', text('close'));
    closeButton.textContent = '×';
    widget.querySelector('#buddyTitle').textContent = text('title');
    widget.querySelector('#buddySubtitle').textContent = text('subtitle');
    input.placeholder = text('placeholder');
    input.setAttribute('aria-label', text('placeholder'));
    sendButton.setAttribute('aria-label', text('send'));
    sendButton.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>';
    widget.querySelector('#buddyPrivacy').textContent = text('privacy');
    widget.querySelector('#buddyContext').innerHTML = '';
    const strong = document.createElement('strong');
    strong.textContent = `${text('contextPage')}: `;
    context.append(strong, document.createTextNode(visibleHeading()));
    widget.dir = language === 'ur' ? 'rtl' : 'auto';
    renderSuggestions();
  };

  const addMessage = (message, options = {}) => {
    const bubble = document.createElement('article');
    bubble.className = `buddy-message${options.user ? ' is-user' : ''}${options.alert ? ' is-alert' : ''}`;
    const paragraph = document.createElement('p');
    paragraph.textContent = message;
    bubble.appendChild(paragraph);

    if (options.actions?.length) {
      const actionGroup = document.createElement('div');
      actionGroup.className = 'buddy-message-actions';
      options.actions.forEach((action) => {
        if (action.href) {
          const link = document.createElement('a');
          link.className = 'buddy-action';
          link.href = action.href;
          link.textContent = action.label;
          link.dataset.buddyNavigation = '';
          actionGroup.appendChild(link);
        } else {
          const button = document.createElement('button');
          button.className = 'buddy-action';
          button.type = 'button';
          button.textContent = action.label;
          if (action.id) button.dataset.buddyAction = action.id;
          actionGroup.appendChild(button);
        }
      });
      bubble.appendChild(actionGroup);
    }

    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
  };

  const action = (key, href) => {
    const knownPage = href.split('#')[0];
    const existsInPageNavigation = Array.from(document.querySelectorAll('.quantum-nav a[href]'))
      .some((link) => link.getAttribute('href') === href);
    const knownDestination = KNOWN_ROUTES.has(knownPage);
    if (!existsInPageNavigation && !knownDestination) return null;
    if (href.includes('#') && knownPage === getRoute() && !document.querySelector(href.slice(href.indexOf('#')))) return null;
    return { label: text(key), href };
  };

  const navigationActions = (names) => names.map(([label, href]) => action(label, href)).filter(Boolean);

  const focusInvalidField = () => {
    const field = pendingInvalidField?.isConnected
      ? pendingInvalidField
      : findVisibleInvalidField(document);
    if (!field) {
      addMessage(text('allValid'));
      return;
    }
    field.scrollIntoView({ behavior: 'smooth', block: 'center' });
    field.focus({ preventScroll: true });
    field.classList.add('buddy-highlight');
    window.setTimeout(() => field.classList.remove('buddy-highlight'), 2800);
  };

  const responseFor = (intent) => {
    const page = getPageType();
    if (intent === 'next') {
      const reply = text(NEXT_MESSAGE_KEYS[page] || NEXT_MESSAGE_KEYS.generic);
      let actions = [];
      if (page === 'home') actions = navigationActions([['actionProducts', 'index.html#products'], ['actionPay', 'payment.html'], ['actionApply', 'apply.html']]);
      else if (page === 'product') actions = navigationActions([['actionApply', 'apply.html'], ['actionPay', 'payment.html']]);
      else if (page === 'apply' || page === 'result') actions = navigationActions([['actionContact', 'contact.html']]);
      else if (page === 'payment') actions = navigationActions([['actionContact', 'contact.html']]);
      else if (page === 'login') actions = navigationActions([['actionApply', 'apply.html'], ['actionContact', 'contact.html']]);
      else if (page === 'contact') actions = [{ label: text('actionBranch'), id: 'branch' }];
      else if (page === 'investor' || page === 'team' || page === 'about') actions = navigationActions([['actionProducts', 'index.html#products'], ['actionContact', 'contact.html']]);
      return { message: reply, actions };
    }

    if (intent === 'explain') {
      return { message: text('explain', { page: visibleHeading() }) };
    }
    if (intent === 'apply') {
      return {
        message: page === 'apply' || page === 'result' ? text('apply') : text('nextProduct'),
        actions: page === 'apply' || page === 'result'
          ? navigationActions([['actionDocs', 'apply.html#step-identity']])
          : navigationActions([['actionApply', 'apply.html']])
      };
    }
    if (intent === 'pay') {
      return { message: text('pay'), actions: navigationActions([['actionPay', 'payment.html']]) };
    }
    if (intent === 'account') {
      return { message: text('account'), actions: navigationActions([['actionLogin', 'login.html']]) };
    }
    if (intent === 'contact') {
      return { message: text('contact'), actions: navigationActions([['actionContact', 'contact.html']]) };
    }
    if (intent === 'products') {
      return { message: text('products'), actions: navigationActions([['actionProducts', 'index.html#products']]) };
    }
    if (intent === 'documents') {
      return {
        message: text('documents'),
        actions: page === 'apply'
          ? [{ label: text('actionFocus'), id: 'focus-invalid' }, { label: text('actionBack'), id: 'focus-personal' }]
          : navigationActions([['actionDocs', 'apply.html#step-identity']])
      };
    }
    if (intent === 'branch') {
      if (page !== 'contact') {
        return { message: text('contact'), actions: navigationActions([['actionBranch', 'contact.html']]) };
      }
      return { message: text('nextContact'), actions: [{ label: text('actionBranch'), id: 'branch' }] };
    }
    if (intent === 'stuck') {
      const field = findVisibleInvalidField(document);
      if (field) {
        pendingInvalidField = field;
        const fieldLabel = getFieldLabel(field);
        return {
          message: text('invalid', { field: fieldLabel ? `: ${fieldLabel}` : '' }),
          actions: [{ label: text('actionFocus'), id: 'focus-invalid' }]
        };
      }
      return {
        message: text('stuck'),
        actions: [{ label: text('actionFocus'), id: 'focus-invalid' }, ...navigationActions([['actionSupport', 'contact.html']])]
      };
    }
    return { message: text('unknown') };
  };

  const intentFromQuestion = (question) => {
    const normalized = question.normalize('NFKC').toLowerCase();
    if (/document|aadhaar|aadhar|\bpan\b|\bgstin\b|कागज|दस्तावेज|आधार|कागदपत्र|દસ્તાવેજ|આધાર|دستاویز|آدھار|ਦਸਤਾਵੇਜ਼|ଆଧାର/.test(normalized)) return 'documents';
    if (/branch|location|शाखा|शाखे|શાખા|برانچ|ਸ਼ਾਖਾ|ଶାଖା/.test(normalized)) return 'branch';
    if (/emi|payment|pay|पेमेंट|भुगतान|ईएमआई|हप्ता|भरणा|ચુકવણી|હપ્તો|قسط|ادائیگی|ਕਿਸ਼ਤ|ਭੁਗਤਾਨ|କିସ୍ତି|ଦେୟ/.test(normalized)) return 'pay';
    if (/application|status|login|account|otp|आवेदन|लॉग.?इन|खाता|અરજી|ખાતું|درخواست|اکاؤنٹ|ਅਰਜ਼ੀ|ਖਾਤਾ|ଆବେଦନ|ଖାତା/.test(normalized)) return 'account';
    if (/apply|loan|लोन|ऋण|कर्ज|कर्ज़|કરજ|લોન|قرض|ਕਰਜ਼|ଋଣ|ଆବେଦନ/.test(normalized)) return 'apply';
    if (/contact|support|help|संपर्क|मदद|सहायता|संपर्क|મદદ|સંપર્ક|مدد|رابطہ|ਮਦਦ|ਸੰਪਰਕ|ସହାୟତା|ଯୋଗାଯୋଗ/.test(normalized)) return 'contact';
    if (/product|option|विकल्प|उत्पाद|पर्याय|पर्याय|વિકલ્પ|مصنوعات|اختیار|ਵਿਕਲਪ|ବିକଳ୍ପ/.test(normalized)) return 'products';
    if (/stuck|error|issue|problem|अटक|समस्या|चूक|अडकलो|અટવ|સમસ્યા|پھنس|مسئلہ|ਫਸ|ਸਮੱਸਿਆ|ଅଟକ|ସମସ୍ୟା/.test(normalized)) return 'stuck';
    if (/explain|page|पेज|पृष्ठ|समझ|પેજ|صفحه|صفحہ|ਪੰਨਾ|ପୃଷ୍ଠା/.test(normalized)) return 'explain';
    return 'next';
  };

  const openBuddy = () => {
    lastFocus = document.activeElement;
    panel.hidden = false;
    launcher.setAttribute('aria-expanded', 'true');
    renderLanguage();
    if (!greeted) {
      addMessage(text('greeting'));
      const page = getPageType();
      addMessage(text(NEXT_MESSAGE_KEYS[page] || NEXT_MESSAGE_KEYS.generic));
      greeted = true;
    }
    input.focus();
  };

  const closeBuddy = () => {
    panel.hidden = true;
    launcher.setAttribute('aria-expanded', 'false');
    launcher.focus();
  };

  const ask = (intent, question = '') => {
    if (question) addMessage(question, { user: true });
    const response = responseFor(intent);
    addMessage(response.message, { actions: response.actions });
  };

  launcher.addEventListener('click', openBuddy);
  closeButton.addEventListener('click', closeBuddy);
  widget.addEventListener('click', (event) => {
    const chip = event.target.closest('[data-intent]');
    if (chip) {
      ask(chip.dataset.intent);
      return;
    }
    const buddyAction = event.target.closest('[data-buddy-action]');
    if (!buddyAction) return;
    if (buddyAction.dataset.buddyAction === 'focus-invalid') {
      focusInvalidField();
    } else if (buddyAction.dataset.buddyAction === 'focus-personal') {
      const target = document.getElementById('step-personal');
      target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      target?.classList.add('buddy-highlight');
      window.setTimeout(() => target?.classList.remove('buddy-highlight'), 2800);
    } else if (buddyAction.dataset.buddyAction === 'branch') {
      const tab = document.getElementById('contactTabBranch');
      tab?.click();
      tab?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      tab?.classList.add('buddy-highlight');
      window.setTimeout(() => tab?.classList.remove('buddy-highlight'), 2800);
    }
  });

  composer.addEventListener('submit', (event) => {
    event.preventDefault();
    const question = input.value.trim();
    if (!question) return;
    ask(intentFromQuestion(question), question);
    input.value = '';
  });

  widget.addEventListener('click', (event) => {
    const link = event.target.closest('a[data-buddy-navigation]');
    if (!link) return;
    const url = new URL(link.href, window.location.href);
    if (url.origin !== window.location.origin) return;
    const sameDocument = url.pathname === window.location.pathname;
    if (!sameDocument && hasUnsavedFormData() && !window.confirm(text('unsaved'))) {
      event.preventDefault();
    }
  });

  document.addEventListener('invalid', (event) => {
    if (!event.target.matches('input, select, textarea')) return;
    pendingInvalidField = event.target;
    if (!panel.hidden) {
      addMessage(text('invalid', {
        field: getFieldLabel(event.target) ? `: ${getFieldLabel(event.target)}` : ''
      }), { alert: true, actions: [{ label: text('actionFocus'), id: 'focus-invalid' }] });
    } else {
      launcher.setAttribute('aria-description', text('invalidNoField'));
    }
  }, true);

  document.addEventListener('submit', (event) => {
    window.setTimeout(() => {
      const invalid = findVisibleInvalidField(event.target);
      if (!invalid) return;
      pendingInvalidField = invalid;
      if (!panel.hidden) {
        addMessage(text('invalid', {
          field: getFieldLabel(invalid) ? `: ${getFieldLabel(invalid)}` : ''
        }), { alert: true, actions: [{ label: text('actionFocus'), id: 'focus-invalid' }] });
      }
    }, 0);
  }, true);

  widget.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !panel.hidden) {
      event.stopPropagation();
      closeBuddy();
    }
  });

  window.addEventListener('namfin:languagechange', (event) => {
    const changedLanguage = event.detail?.language;
    if (!AVAILABLE_LANGUAGES.has(changedLanguage)) return;
    language = changedLanguage;
    renderLanguage();
  });

  window.addEventListener('storage', (event) => {
    if (event.key !== 'namfin_language') return;
    language = currentLanguage();
    renderLanguage();
  });

  const refreshPageContext = () => {
    if (panel.hidden) return;
    renderLanguage();
    if (greeted) {
      addMessage(text(NEXT_MESSAGE_KEYS[getPageType()] || NEXT_MESSAGE_KEYS.generic));
    }
  };

  window.addEventListener('hashchange', refreshPageContext);
  window.addEventListener('popstate', refreshPageContext);
  document.addEventListener('DOMContentLoaded', renderLanguage, { once: true });
  renderLanguage();
})();
