/**
 * NAMDEV FINVEST LIMITED — MINIMALIST BLACK & WHITE PRODUCTS ENGINE
 * Solar ROI, LAP LTV Engine, Tractor Crop Cycles, 2-Wheeler EV Bonus, MSME Limits
 */

(function () {
  'use strict';

  function formatINR(val) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(Math.round(val));
  }

  function formatLakhCrore(val) {
    if (val >= 10000000) {
      return `₹${(val / 10000000).toFixed(2)} Cr`;
    } else if (val >= 100000) {
      return `₹${(val / 100000).toFixed(2)} Lakh`;
    }
    return formatINR(val);
  }

  function calculateEMI(P, annualRate, tenureMonths) {
    const r = annualRate / 12 / 100;
    const n = tenureMonths;
    const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return Math.round(emi);
  }

  // ===================================================================
  // 1. SOLAR ROI & ENERGY SAVINGS ENGINE
  // ===================================================================
  const solarBillSlider = document.getElementById('solarBillSlider');
  const solarBillDisplay = document.getElementById('solarBillDisplay');
  const solarCapacityVal = document.getElementById('solarCapacityVal');
  const solarLoanCostVal = document.getElementById('solarLoanCostVal');
  const solarSubsidyVal = document.getElementById('solarSubsidyVal');
  const solarMonthlySavingsVal = document.getElementById('solarMonthlySavingsVal');
  const solarEmiVal = document.getElementById('solarEmiVal');
  const solarNetProfitVal = document.getElementById('solarNetProfitVal');

  function updateSolarWidget() {
    if (!solarBillSlider) return;
    const bill = parseFloat(solarBillSlider.value);
    if (solarBillDisplay) solarBillDisplay.innerText = formatINR(bill);

    let kw = Math.max(1, Math.round(bill / 850));
    if (kw > 10) kw = 10;

    const totalCost = kw * 55000;

    let subsidy = 30000;
    if (kw === 2) subsidy = 60000;
    else if (kw >= 3) subsidy = 78000;

    const loanAmount = Math.max(10000, totalCost - subsidy);
    const emi = calculateEMI(loanAmount, 8.99, 48);
    const monthlySolarSavings = Math.round(bill * 0.9);
    const netMonthlyProfit = monthlySolarSavings - emi;

    if (solarCapacityVal) solarCapacityVal.innerText = `${kw} kW`;
    if (solarLoanCostVal) solarLoanCostVal.innerText = formatINR(totalCost);
    if (solarSubsidyVal) solarSubsidyVal.innerText = formatINR(subsidy);
    if (solarMonthlySavingsVal) solarMonthlySavingsVal.innerText = formatINR(monthlySolarSavings);
    if (solarEmiVal) solarEmiVal.innerText = formatINR(emi);
    if (solarNetProfitVal) {
      if (netMonthlyProfit >= 0) {
        solarNetProfitVal.innerText = `+${formatINR(netMonthlyProfit)} / mo Net Offset`;
        solarNetProfitVal.style.color = '#ffffff';
      } else {
        solarNetProfitVal.innerText = `${formatINR(Math.abs(netMonthlyProfit))} / mo Out-of-pocket`;
        solarNetProfitVal.style.color = '#a1a1aa';
      }
    }
  }

  if (solarBillSlider) {
    solarBillSlider.addEventListener('input', () => {
      updateSolarWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
    updateSolarWidget();
  }

  // ===================================================================
  // 2. TWO WHEELER ON-ROAD & DOWN PAYMENT ENGINE
  // ===================================================================
  const twPriceSlider = document.getElementById('twPriceSlider');
  const twPriceDisplay = document.getElementById('twPriceDisplay');
  const twDownPaymentSlider = document.getElementById('twDownPaymentSlider');
  const twDownPaymentDisplay = document.getElementById('twDownPaymentDisplay');
  const twLoanAmountVal = document.getElementById('twLoanAmountVal');
  const twDownPaymentVal = document.getElementById('twDownPaymentVal');
  const twEmiVal = document.getElementById('twEmiVal');

  function updateTwoWheelerWidget() {
    if (!twPriceSlider || !twDownPaymentSlider) return;
    const price = parseFloat(twPriceSlider.value);
    const downPct = parseFloat(twDownPaymentSlider.value);

    if (twPriceDisplay) twPriceDisplay.innerText = formatINR(price);
    if (twDownPaymentDisplay) twDownPaymentDisplay.innerText = `${downPct}%`;

    const downPayment = Math.round(price * (downPct / 100));
    const loanAmount = price - downPayment;
    const emi = calculateEMI(loanAmount, 9.99, 24);

    if (twLoanAmountVal) twLoanAmountVal.innerText = formatINR(loanAmount);
    if (twDownPaymentVal) twDownPaymentVal.innerText = formatINR(downPayment);
    if (twEmiVal) twEmiVal.innerText = formatINR(emi);
  }

  if (twPriceSlider && twDownPaymentSlider) {
    twPriceSlider.addEventListener('input', () => {
      updateTwoWheelerWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
    twDownPaymentSlider.addEventListener('input', () => {
      updateTwoWheelerWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(750, 'sine', 0.01);
    });
    updateTwoWheelerWidget();
  }

  // ===================================================================
  // 3. E-RICKSHAW EMI ESTIMATE
  // ===================================================================
  const erLoanAmountSlider = document.getElementById('erLoanAmountSlider');
  const erInterestRateSlider = document.getElementById('erInterestRateSlider');
  const erTenureSlider = document.getElementById('erTenureSlider');
  const erLoanAmountDisplay = document.getElementById('erLoanAmountDisplay');
  const erInterestRateDisplay = document.getElementById('erInterestRateDisplay');
  const erTenureDisplay = document.getElementById('erTenureDisplay');
  const erEmiDisplay = document.getElementById('erEmiDisplay');
  const erPrincipalDisplay = document.getElementById('erPrincipalDisplay');
  const erInterestTotalDisplay = document.getElementById('erInterestTotalDisplay');
  const erTotalPayableDisplay = document.getElementById('erTotalPayableDisplay');

  function updateErickshawWidget() {
    if (!erLoanAmountSlider || !erInterestRateSlider || !erTenureSlider) return;

    const principal = Number(erLoanAmountSlider.value);
    const annualRate = Number(erInterestRateSlider.value);
    const tenureMonths = Number(erTenureSlider.value);
    const emi = calculateEMI(principal, annualRate, tenureMonths);
    const totalInterest = emi * tenureMonths - principal;
    const totalPayable = emi * tenureMonths;

    if (erLoanAmountDisplay) erLoanAmountDisplay.innerText = formatINR(principal);
    if (erInterestRateDisplay) erInterestRateDisplay.innerText = `${annualRate}%`;
    if (erTenureDisplay) erTenureDisplay.innerText = `${tenureMonths} months`;
    if (erEmiDisplay) erEmiDisplay.innerText = formatINR(emi);
    if (erPrincipalDisplay) erPrincipalDisplay.innerText = formatINR(principal);
    if (erInterestTotalDisplay) erInterestTotalDisplay.innerText = formatINR(totalInterest);
    if (erTotalPayableDisplay) erTotalPayableDisplay.innerText = formatINR(totalPayable);
  }

  [erLoanAmountSlider, erInterestRateSlider, erTenureSlider].forEach((slider) => {
    if (!slider) return;
    slider.addEventListener('input', () => {
      updateErickshawWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
  });
  if (erLoanAmountSlider && erInterestRateSlider && erTenureSlider) updateErickshawWidget();

  // ===================================================================
  // 4. LAP (LOAN AGAINST PROPERTY) LTV & EQUITY ENGINE
  // ===================================================================
  const lapPropSlider = document.getElementById('lapPropSlider');
  const lapPropDisplay = document.getElementById('lapPropDisplay');
  const lapTypeSelect = document.getElementById('lapTypeSelect');
  const lapSanctionVal = document.getElementById('lapSanctionVal');
  const lapLtvVal = document.getElementById('lapLtvVal');
  const lapEmiVal = document.getElementById('lapEmiVal');

  function updateLapWidget() {
    if (!lapPropSlider) return;
    const propVal = parseFloat(lapPropSlider.value);
    if (lapPropDisplay) lapPropDisplay.innerText = formatLakhCrore(propVal);

    let ltv = 0.65;
    if (lapTypeSelect) {
      const type = lapTypeSelect.value;
      if (type === 'commercial') ltv = 0.55;
      else if (type === 'industrial') ltv = 0.50;
    }

    const sanctionLimit = Math.round(propVal * ltv);
    const emi = calculateEMI(sanctionLimit, 10.25, 120);

    if (lapSanctionVal) lapSanctionVal.innerText = formatLakhCrore(sanctionLimit);
    if (lapLtvVal) lapLtvVal.innerText = `${Math.round(ltv * 100)}% LTV`;
    if (lapEmiVal) lapEmiVal.innerText = formatINR(emi);
  }

  if (lapPropSlider) {
    lapPropSlider.addEventListener('input', () => {
      updateLapWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
    if (lapTypeSelect) {
      lapTypeSelect.addEventListener('change', () => {
        updateLapWidget();
        if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
      });
    }
    updateLapWidget();
  }

  // ===================================================================
  // 5. TRACTOR & AGRI CROP-CYCLE REPAYMENT ENGINE
  // ===================================================================
  const tractorPriceSlider = document.getElementById('tractorPriceSlider');
  const tractorPriceDisplay = document.getElementById('tractorPriceDisplay');
  const tractorFreqSelect = document.getElementById('tractorFreqSelect');
  const tractorLoanVal = document.getElementById('tractorLoanVal');
  const tractorInstallmentVal = document.getElementById('tractorInstallmentVal');
  const tractorFreqLabel = document.getElementById('tractorFreqLabel');

  function updateTractorWidget() {
    if (!tractorPriceSlider) return;
    const price = parseFloat(tractorPriceSlider.value);
    if (tractorPriceDisplay) tractorPriceDisplay.innerText = formatLakhCrore(price);

    const loanAmount = Math.round(price * 0.85);
    const monthlyEmi = calculateEMI(loanAmount, 10.99, 48);

    let freq = 'monthly';
    if (tractorFreqSelect) freq = tractorFreqSelect.value;

    let installment = monthlyEmi;
    let label = 'Monthly Installment';

    if (freq === 'quarterly') {
      installment = Math.round(monthlyEmi * 2.95);
      label = 'Quarterly Installment';
    } else if (freq === 'harvest') {
      installment = Math.round(monthlyEmi * 5.85);
      label = 'Half-Yearly Harvest Installment (Kharif / Rabi)';
    }

    if (tractorLoanVal) tractorLoanVal.innerText = formatLakhCrore(loanAmount);
    if (tractorInstallmentVal) tractorInstallmentVal.innerText = formatINR(installment);
    if (tractorFreqLabel) tractorFreqLabel.innerText = label;
  }

  if (tractorPriceSlider) {
    tractorPriceSlider.addEventListener('input', () => {
      updateTractorWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
    if (tractorFreqSelect) {
      tractorFreqSelect.addEventListener('change', () => {
        updateTractorWidget();
        if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
      });
    }
    updateTractorWidget();
  }

  // ===================================================================
  // 5. MSME REVENUE TO WORKING CAPITAL ESTIMATOR
  // ===================================================================
  const msmeRevSlider = document.getElementById('msmeRevSlider');
  const msmeRevDisplay = document.getElementById('msmeRevDisplay');
  const msmeLimitVal = document.getElementById('msmeLimitVal');
  const msmeEmiVal = document.getElementById('msmeEmiVal');

  function updateMsmeWidget() {
    if (!msmeRevSlider) return;
    const turnover = parseFloat(msmeRevSlider.value);
    if (msmeRevDisplay) msmeRevDisplay.innerText = formatLakhCrore(turnover);

    const creditLimit = Math.min(5000000, Math.round(turnover * 0.20));
    const emi = calculateEMI(creditLimit, 11.5, 36);

    if (msmeLimitVal) msmeLimitVal.innerText = formatLakhCrore(creditLimit);
    if (msmeEmiVal) msmeEmiVal.innerText = formatINR(emi);
  }

  if (msmeRevSlider) {
    msmeRevSlider.addEventListener('input', () => {
      updateMsmeWidget();
      if (window.namfinSFX) window.namfinSFX.playClick(700, 'sine', 0.01);
    });
    updateMsmeWidget();
  }
})();
