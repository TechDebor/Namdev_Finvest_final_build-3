/**
 * NAMDEV FINVEST LIMITED — QUANTUM EMI CALCULATOR ENGINE
 * Multi-Product Financial Simulation & Amortization Analytics
 */

(function () {
  'use strict';

  // Product configurations
  const PRODUCT_SPECS = {
    msme: {
      name: 'MSME Business Loan',
      defaultAmount: 800000,
      minAmount: 50000,
      maxAmount: 5000000,
      stepAmount: 50000,
      defaultRate: 11.5,
      minRate: 10.5,
      maxRate: 18.0,
      stepRate: 0.25,
      defaultTenure: 36,
      minTenure: 12,
      maxTenure: 84,
      stepTenure: 6,
      unit: 'Months',
    },
    tw: {
      name: 'Two Wheeler Loan',
      defaultAmount: 95000,
      minAmount: 25000,
      maxAmount: 300000,
      stepAmount: 5000,
      defaultRate: 9.99,
      minRate: 8.99,
      maxRate: 15.0,
      stepRate: 0.25,
      defaultTenure: 24,
      minTenure: 12,
      maxTenure: 48,
      stepTenure: 6,
      unit: 'Months',
    },
    lap: {
      name: 'Loan Against Property (LAP)',
      defaultAmount: 2500000,
      minAmount: 500000,
      maxAmount: 25000000,
      stepAmount: 100000,
      defaultRate: 10.25,
      minRate: 9.75,
      maxRate: 16.0,
      stepRate: 0.25,
      defaultTenure: 60,
      minTenure: 24,
      maxTenure: 180,
      stepTenure: 12,
      unit: 'Months',
    },
    solar: {
      name: 'Solar & Clean Tech Loan',
      defaultAmount: 250000,
      minAmount: 50000,
      maxAmount: 2500000,
      stepAmount: 25000,
      defaultRate: 8.99,
      minRate: 8.49,
      maxRate: 13.5,
      stepRate: 0.25,
      defaultTenure: 36,
      minTenure: 12,
      maxTenure: 60,
      stepTenure: 6,
      unit: 'Months',
    },
    tractor: {
      name: 'Tractor & Agri Loan',
      defaultAmount: 550000,
      minAmount: 100000,
      maxAmount: 1500000,
      stepAmount: 25000,
      defaultRate: 10.99,
      minRate: 9.99,
      maxRate: 15.5,
      stepRate: 0.25,
      defaultTenure: 48,
      minTenure: 12,
      maxTenure: 60,
      stepTenure: 6,
      unit: 'Months',
    },
  };

  let currentProduct = 'msme';

  // Indian Rupee Formatter
  function formatINR(number) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(number);
  }

  function formatLakhCrore(val) {
    if (val >= 10000000) {
      return `₹${(val / 10000000).toFixed(2)} Cr`;
    } else if (val >= 100000) {
      return `₹${(val / 100000).toFixed(2)} Lakh`;
    }
    return formatINR(val);
  }

  // Calculate Equated Monthly Installment (EMI)
  function calculateEMI(P, annualRate, tenureMonths) {
    const r = annualRate / 12 / 100;
    const n = tenureMonths;
    const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = emi * n;
    const totalInterest = totalPayment - P;

    return {
      monthlyEMI: Math.round(emi),
      totalPayment: Math.round(totalPayment),
      totalInterest: Math.round(totalInterest),
      principalShare: Math.round((P / totalPayment) * 100),
      interestShare: Math.round((totalInterest / totalPayment) * 100),
    };
  }

  // Initialize Elements
  const amtSlider = document.getElementById('calcAmountSlider');
  const amtDisplay = document.getElementById('calcAmountDisplay');
  const amtMinLabel = document.getElementById('calcAmountMin');
  const amtMaxLabel = document.getElementById('calcAmountMax');

  const rateSlider = document.getElementById('calcRateSlider');
  const rateDisplay = document.getElementById('calcRateDisplay');
  const rateMinLabel = document.getElementById('calcRateMin');
  const rateMaxLabel = document.getElementById('calcRateMax');

  const tenureSlider = document.getElementById('calcTenureSlider');
  const tenureDisplay = document.getElementById('calcTenureDisplay');
  const tenureMinLabel = document.getElementById('calcTenureMin');
  const tenureMaxLabel = document.getElementById('calcTenureMax');

  const emiOutput = document.getElementById('calcMonthlyEmiVal');
  const principalValOutput = document.getElementById('calcPrincipalVal');
  const interestValOutput = document.getElementById('calcInterestVal');
  const totalValOutput = document.getElementById('calcTotalVal');

  const barPrincipal = document.getElementById('calcBarPrincipal');
  const barInterest = document.getElementById('calcBarInterest');

  const applyBtn = document.getElementById('calcApplyBtn');

  function updateProductUI(prodKey) {
    const spec = PRODUCT_SPECS[prodKey];
    if (!spec || !amtSlider) return;

    currentProduct = prodKey;

    amtSlider.min = spec.minAmount;
    amtSlider.max = spec.maxAmount;
    amtSlider.step = spec.stepAmount;
    amtSlider.value = spec.defaultAmount;
    if (amtMinLabel) amtMinLabel.innerText = formatLakhCrore(spec.minAmount);
    if (amtMaxLabel) amtMaxLabel.innerText = formatLakhCrore(spec.maxAmount);

    rateSlider.min = spec.minRate;
    rateSlider.max = spec.maxRate;
    rateSlider.step = spec.stepRate;
    rateSlider.value = spec.defaultRate;
    if (rateMinLabel) rateMinLabel.innerText = `${spec.minRate}%`;
    if (rateMaxLabel) rateMaxLabel.innerText = `${spec.maxRate}%`;

    tenureSlider.min = spec.minTenure;
    tenureSlider.max = spec.maxTenure;
    tenureSlider.step = spec.stepTenure;
    tenureSlider.value = spec.defaultTenure;
    if (tenureMinLabel) tenureMinLabel.innerText = `${spec.minTenure} Mo`;
    if (tenureMaxLabel) tenureMaxLabel.innerText = `${spec.maxTenure} Mo`;

    recalculate();
  }

  function recalculate() {
    if (!amtSlider || !rateSlider || !tenureSlider) return;

    const principal = parseFloat(amtSlider.value);
    const rate = parseFloat(rateSlider.value);
    const tenure = parseInt(tenureSlider.value, 10);

    if (amtDisplay) amtDisplay.innerText = formatLakhCrore(principal);
    if (rateDisplay) rateDisplay.innerText = `${rate.toFixed(2)}% p.a.`;
    if (tenureDisplay) tenureDisplay.innerText = `${tenure} Months`;

    const result = calculateEMI(principal, rate, tenure);

    if (emiOutput) emiOutput.innerText = formatINR(result.monthlyEMI);
    if (principalValOutput) principalValOutput.innerText = formatLakhCrore(principal);
    if (interestValOutput) interestValOutput.innerText = formatLakhCrore(result.totalInterest);
    if (totalValOutput) totalValOutput.innerText = formatLakhCrore(result.totalPayment);

    if (barPrincipal && barInterest) {
      barPrincipal.style.width = `${result.principalShare}%`;
      barInterest.style.width = `${result.interestShare}%`;
    }

    if (applyBtn) {
      applyBtn.setAttribute('data-product', currentProduct);
      applyBtn.setAttribute('data-amount', principal);
    }
  }

  // Bind Listeners
  if (amtSlider) {
    amtSlider.addEventListener('input', () => {
      recalculate();
      if (window.namfinSFX) window.namfinSFX.playClick(900, 'sine', 0.01);
    });
  }

  if (rateSlider) {
    rateSlider.addEventListener('input', () => {
      recalculate();
      if (window.namfinSFX) window.namfinSFX.playClick(950, 'sine', 0.01);
    });
  }

  if (tenureSlider) {
    tenureSlider.addEventListener('input', () => {
      recalculate();
      if (window.namfinSFX) window.namfinSFX.playClick(1000, 'sine', 0.01);
    });
  }

  // Product Tab Switchers
  const tabButtons = document.querySelectorAll('.calc-tab-btn');
  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
      tabButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      const prodKey = btn.getAttribute('data-product');
      updateProductUI(prodKey);
    });
  });

  // Hero Quick Simulator (on Homepage)
  const heroSlider = document.getElementById('heroQuickSlider');
  const heroValDisplay = document.getElementById('heroSliderVal');
  const heroEmiDisplay = document.getElementById('heroQuickEmiVal');

  if (heroSlider && heroValDisplay && heroEmiDisplay) {
    function updateHeroSim() {
      const p = parseFloat(heroSlider.value);
      heroValDisplay.innerText = formatLakhCrore(p);
      const res = calculateEMI(p, 11.5, 36);
      heroEmiDisplay.innerText = formatINR(res.monthlyEMI);
    }
    heroSlider.addEventListener('input', () => {
      updateHeroSim();
      if (window.namfinSFX) window.namfinSFX.playClick(850, 'sine', 0.015);
    });
    updateHeroSim();
  }

  // Initial Run
  if (amtSlider) {
    updateProductUI('msme');
  }

  window.namfinCalculator = {
    calculateEMI,
    formatINR,
    formatLakhCrore,
    updateProductUI,
  };
})();
