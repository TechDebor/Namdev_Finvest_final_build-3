import re
import os
import glob

# Map of pages to exact Unsplash Photo IDs representing Indian context
photo_map = {
    'msme.html': 'I_Znq8FwMSg', # Indian woman sari shop
    'tractor.html': 'lV55D_U5l50', # Young Indian farmer
    'two-wheeler.html': 'i_zT3AhCbDY', # Indian scooter rider
    'lap.html': 'q1nXStYVVPI', # Indian family
    'solar.html': '-jFGeFpBRr8', # Solar house
    'index.html': 'I_Znq8FwMSg', # Indian shop for main hero
    'about.html': '-AuaxSIXv64', # Indian office team
    'team.html': 'nWh-Dj3u1Gs', # Another Indian diverse group
    'contact.html': 'j_fG6t49yM4' # Generic busy street / Indian office context (using known ID or a safe one)
}

# The generic base URL to prepend
base_url = "https://images.unsplash.com/photo-"
params = "?auto=format&fit=crop&w=2400&q=80"

for file, photo_id in photo_map.items():
    if not os.path.exists(file):
        continue
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Find the main hero background image
        # This matches: <img src="https://images.unsplash.com/photo-XXX?..." ...>
        # inside the div with absolute inset 0
        pattern = r'(<div style="position: absolute; inset: 0; z-index: -1;[^>]*>\s*<img[^>]*src=")(https://images\.unsplash\.com/photo-[a-zA-Z0-9\-_]+)(\?[^"]*)(")'
        
        # Function to replace with new ID
        def replace_img(match):
            prefix = match.group(1)
            # The new URL replaces the old photo ID URL
            new_url = base_url + photo_id
            suffix = params + match.group(4)
            return prefix + new_url + suffix

        new_content = re.sub(pattern, replace_img, content)
        
        # If there are gallery images in team.html, let's swap them to Indian ones too
        if file == 'team.html':
            # Three specific gallery images
            gallery_imgs = ['-AuaxSIXv64', 'nWh-Dj3u1Gs', 'I_Znq8FwMSg']
            # Find all <img src="https://images.unsplash.com/photo-...
            img_pattern = r'src="https://images\.unsplash\.com/photo-[a-zA-Z0-9\-_]+\?[^"]*"'
            matches = re.findall(img_pattern, new_content)
            
            # Skip the first one which is the hero (already updated above or about to be)
            # Find all others and replace
            replace_count = 0
            for i, m in enumerate(matches):
                if i > 0 and replace_count < 3: # Skip hero
                    new_src = f'src="https://images.unsplash.com/photo-{gallery_imgs[replace_count]}{params}"'
                    new_content = new_content.replace(m, new_src, 1)
                    replace_count += 1
        
        # For about.html, replace the generic profile placeholder IDs with Indian-looking portraits if possible
        if file == 'about.html':
            # Just some safe IDs for generic professional portraits (Indian context)
            portraits = ['YnO6NgX5Nfs', 'rDEOVtE7vOs'] 
            img_pattern = r'src="https://images\.unsplash\.com/photo-[a-zA-Z0-9\-_]+\?[^"]*"'
            matches = re.findall(img_pattern, new_content)
            replace_count = 0
            for i, m in enumerate(matches):
                # skip hero
                if i > 0 and replace_count < 2:
                    new_src = f'src="https://images.unsplash.com/photo-{portraits[replace_count]}?auto=format&fit=crop&w=400&q=80"'
                    new_content = new_content.replace(m, new_src, 1)
                    replace_count += 1

        with open(file, 'w') as f:
            f.write(new_content)
        print(f"Updated Indian imagery for {file}")
            
    except Exception as e:
        print(f"Error on {file}: {e}")

