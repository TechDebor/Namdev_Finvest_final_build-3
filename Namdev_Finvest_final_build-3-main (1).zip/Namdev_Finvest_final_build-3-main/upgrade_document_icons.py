import re
import time

with open('apply.html', 'r') as f:
    content = f.read()

# 1. Update Aadhaar Icon to be more premium (Red/Gold gradient)
new_aadhaar = '''<span class="doc-illustration aadhaar" style="background: linear-gradient(135deg, rgba(234, 172, 57, 0.15), rgba(209, 51, 113, 0.15)) !important; border: 1px solid rgba(234, 172, 57, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <path fill="url(#gradA1)" d="M22.5,45A27.5,27.5 0 0,1 77.5,45A27.5,27.5 0 0,1 22.5,45M10,45A40,40 0 0,0 90,45A40,40 0 0,0 10,45" />
  <path fill="url(#gradA2)" d="M35,45A15,15 0 0,1 65,45A15,15 0 0,1 35,45M25,45A25,25 0 0,0 75,45A25,25 0 0,0 25,45" />
  <defs>
    <linearGradient id="gradA1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#eaac39" /><stop offset="100%" stop-color="#d13371" /></linearGradient>
    <linearGradient id="gradA2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#d13371" /><stop offset="100%" stop-color="#eaac39" /></linearGradient>
  </defs>
</svg>
</span>'''

# 2. Update PAN Icon (Deep Blue/Cyan sleek card)
new_pan = '''<span class="doc-illustration pan" style="background: linear-gradient(135deg, rgba(51, 62, 156, 0.15), rgba(41, 171, 226, 0.15)) !important; border: 1px solid rgba(51, 62, 156, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradP)" xmlns="http://www.w3.org/2000/svg">
  <rect x="2" y="4" width="20" height="16" rx="3" ry="3" />
  <circle cx="8" cy="10" r="3" fill="#fff" />
  <rect x="14" y="9" width="6" height="2" fill="#fff" />
  <rect x="14" y="13" width="4" height="2" fill="#fff" />
  <defs>
    <linearGradient id="gradP" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#333e9c" /><stop offset="100%" stop-color="#29abe2" /></linearGradient>
  </defs>
</svg>
</span>'''

# 3. Update Udyam Icon (Vibrant Emerald/Lime green)
new_udyam = '''<span class="doc-illustration udyam" style="background: linear-gradient(135deg, rgba(29, 168, 94, 0.15), rgba(124, 218, 36, 0.15)) !important; border: 1px solid rgba(29, 168, 94, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradU)" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
  <defs>
    <linearGradient id="gradU" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1da85e" /><stop offset="100%" stop-color="#7cda24" /></linearGradient>
  </defs>
</svg>
</span>'''

# 4. Update GSTIN Icon (Rich Purple/Orange receipt/hex)
new_gst = '''<span class="doc-illustration gst" style="background: linear-gradient(135deg, rgba(238, 155, 34, 0.15), rgba(234, 84, 85, 0.15)) !important; border: 1px solid rgba(238, 155, 34, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradG)" xmlns="http://www.w3.org/2000/svg">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
  <polyline points="14 2 14 8 20 8" fill="#fff" />
  <line x1="16" y1="13" x2="8" y2="13" stroke="#fff" stroke-width="2" />
  <line x1="16" y1="17" x2="8" y2="17" stroke="#fff" stroke-width="2" />
  <line x1="10" y1="9" x2="8" y2="9" stroke="#fff" stroke-width="2" />
  <defs>
    <linearGradient id="gradG" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#ee9b22" /><stop offset="100%" stop-color="#ea5455" /></linearGradient>
  </defs>
</svg>
</span>'''


# Replace the old spans with the new highly-visible premium SVG spans
content = re.sub(r'<span class="doc-illustration aadhaar">.*?</span>', new_aadhaar, content, flags=re.DOTALL)
content = re.sub(r'<span class="doc-illustration pan">.*?</span>', new_pan, content, flags=re.DOTALL)
content = re.sub(r'<span class="doc-illustration udyam">.*?</span>', new_udyam, content, flags=re.DOTALL)
content = re.sub(r'<span class="doc-illustration gst">.*?</span>', new_gst, content, flags=re.DOTALL)

# Add some overarching CSS to make sure .doc-illustration containers look stunning in both themes
global_icon_fix = """
  /* ==========================================================================
     PREMIUM DOCUMENT ICONS FIX
     ========================================================================== */
  .doc-illustration {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: 48px !important;
    height: 48px !important;
    border-radius: 12px !important;
    flex: 0 0 48px !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05), inset 0 2px 4px rgba(255,255,255,0.1) !important;
  }
"""

if 'PREMIUM DOCUMENT ICONS FIX' not in content:
    content = content.replace('</style>', global_icon_fix + '\n</style>')

# Cache bust
timestamp = str(int(time.time()))
content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)

with open('apply.html', 'w') as f:
    f.write(content)
print("Icons upgraded to highly visible, bold premium SVGs.")

