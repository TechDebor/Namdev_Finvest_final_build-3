import glob
import re
import time

html_files = glob.glob('*.html')

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # 1. Clean the Login Button
        # Find the login anchor tag and replace its inline styles completely
        # It looks like: <a href="login.html" class="nav-link" style="...">Login <svg...</a>
        login_pattern = r'<a href="login\.html" class="nav-link"[^>]*>Login'
        clean_login = '<a href="login.html" class="nav-link login-btn">Login'
        content = re.sub(login_pattern, clean_login, content)

        # 2. Clean the Pay EMI Button
        # It looks like: <a href="payment.html" class="btn-quantum" style="...">Pay EMI</a>
        pay_emi_pattern = r'<a href="payment\.html" class="btn-quantum"[^>]*>Pay EMI</a>'
        clean_pay_emi = '<a href="payment.html" class="btn-quantum pay-emi-btn">Pay EMI</a>'
        content = re.sub(pay_emi_pattern, clean_pay_emi, content)

        # 3. Clean the nav-link tags from inline white-space: nowrap
        content = re.sub(r'class="nav-link" style="white-space: nowrap;?"', 'class="nav-link"', content)
        
        # 4. Clean brand-title and brand-sub
        content = re.sub(r'class="brand-title" style="white-space: nowrap;?"', 'class="brand-title"', content)
        content = re.sub(r'class="brand-sub" style="white-space: nowrap; font-size: 0\.65rem;?"', 'class="brand-sub"', content)
        
        # 5. Clean btn-quantum inline styles
        content = re.sub(r'class="btn-quantum" style="white-space: nowrap; flex-shrink: 0;?"', 'class="btn-quantum"', content)
        content = re.sub(r'class="btn-quantum" style="white-space: nowrap; flex-shrink: 0; padding: 8px 20px; border-radius: 50px; font-weight: 600;?"', 'class="btn-quantum"', content)
        
        # 6. Ensure the Login SVG has a proper class instead of inline style
        svg_pattern = r'Login\s*<svg[^>]*style="[^"]*"([^>]*)>'
        content = re.sub(svg_pattern, r'Login <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="login-icon"\1>', content)

        # Bust Cache
        timestamp = str(int(time.time()))
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'href="css/style\.css"', f'href="css/style.css?v={timestamp}"', content)

        with open(file, 'w') as f:
            f.write(content)
            
    except Exception as e:
        print(f"Error on {file}: {e}")

print("HTML completely deep-cleaned.")

# Now let's inject the clean CSS definitions for these elements
css_clean = """
/* ==========================================================================
   DEEP CLEAN NAVBAR & ANIMATIONS
   ========================================================================== */
.nav-link.login-btn {
  font-weight: 700 !important;
  margin-right: 0 !important; /* Fixed the massive gap */
}
.login-icon {
  margin-left: 6px !important;
  transform: translateY(1px); /* Perfect vertical alignment for the arrow */
}

/* Ensure no wrapping anywhere */
.nav-link, .brand-title, .brand-sub, .btn-quantum, .login-btn {
  white-space: nowrap !important;
}

/* Ensure flex doesn't crush buttons */
.btn-quantum, .login-btn, .brand-quantum {
  flex-shrink: 0 !important;
}

/* Global Card Animations */
.info-card, .feature-node, .bento-card, .criteria-card, .pipeline-node {
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
  will-change: transform;
}

.info-card:hover, .feature-node:hover, .bento-card:hover, .criteria-card:hover, .pipeline-node:hover {
  transform: translateY(-8px) scale(1.02) !important;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08) !important;
  border-color: var(--grad-c1, var(--brand)) !important;
}

[data-theme="dark"] .info-card:hover, 
[data-theme="dark"] .feature-node:hover, 
[data-theme="dark"] .bento-card:hover {
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4) !important;
}

/* Pay EMI sizing */
.pay-emi-btn {
  padding: 8px 18px !important;
  border-radius: 50px !important;
  font-size: 0.85rem !important;
}
"""

with open('css/style.css', 'a') as f:
    f.write("\n" + css_clean)
print("CSS deep-clean and animations injected.")
