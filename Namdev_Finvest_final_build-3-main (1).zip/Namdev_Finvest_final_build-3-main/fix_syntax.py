with open('payment.html', 'r') as f:
    content = f.read()

import re
# We just want to replace the whole script block at the end with the correct one.
script_start = content.find('<script>')
script_end = content.find('</script>') + len('</script>')

correct_script = """<script>
    document.addEventListener('DOMContentLoaded', () => {
      const payBtn = document.getElementById('payBtn');
      const modal = document.getElementById('paymentModal');
      const processing = document.getElementById('paymentProcessing');
      const success = document.getElementById('paymentSuccess');
      const txnId = document.getElementById('txnId');
      
      if (payBtn && modal) {
        payBtn.addEventListener('click', (e) => {
          e.preventDefault();
          if (window.namfinSFX) window.namfinSFX.playQuantumBeep();
          
          modal.classList.add('active');
          processing.style.display = 'block';
          success.style.display = 'none';
          
          setTimeout(() => {
            if (window.namfinSFX) window.namfinSFX.playClick(1000, 'triangle', 0.15);
            processing.style.display = 'none';
            success.style.display = 'block';
            txnId.innerText = Math.floor(100000000 + Math.random() * 900000000);
          }, 2000);
        });
        
        const closeBtn = modal.querySelector('.modal-close-btn');
        if (closeBtn) {
          closeBtn.addEventListener('click', () => {
             modal.classList.remove('active');
             if (window.namfinSFX) window.namfinSFX.playClick(400);
          });
        }
        
        modal.addEventListener('click', (e) => {
          if (e.target === modal) {
            modal.classList.remove('active');
          }
        });
      }
    });
  </script>"""

if script_start != -1 and script_end != -1:
    content = content[:script_start] + correct_script + content[script_end:]

with open('payment.html', 'w') as f:
    f.write(content)
