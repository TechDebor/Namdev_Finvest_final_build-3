import re
import time

with open('/Users/shubhbanna/Downloads/namdev_loan_preapproval_with_result (2) 2.html', 'r', encoding='utf-8') as f:
    original = f.read()

# 1. Extract pieces
style_match = re.search(r'<style>(.*?)</style>', original, re.DOTALL)
script_match = re.search(r'<script>(.*?)</script>', original, re.DOTALL)
body_match = re.search(r'<body>(.*?)</body>', original, re.DOTALL)

original_css = style_match.group(1)
original_js = script_match.group(1)
original_html = body_match.group(1)

# 2. Modify Javascript: redirect to namfindesk.html on continue
original_js = original_js.replace(
    "$('#continue-application').addEventListener('click',()=>{navigateBack()});",
    "$('#continue-application').addEventListener('click',()=>{ window.location.href = 'namfindesk.html'; });"
)

# 3. Adapt the CSS for Dark Mode & Namdev variables
adapted_css = original_css.replace(
    ':root{--ink:#0c1e43;--soft:#556c8e;--line:#dbe4f2;--purple:#6d56ed;--rose:#da3476;--green:#29ab6b;--input:#f7f9fd;--card:#fff;--header:#f4f7fc}',
    ':root{--ink:var(--text-primary);--soft:var(--text-secondary);--line:var(--border);--purple:var(--grad-c1);--rose:var(--grad-c3);--green:#29ab6b;--input:transparent;--card:transparent;--header:transparent;}'
)
adapted_css = re.sub(r'body\{[^}]+\}', 'body { margin: 0; min-height: 100vh; }', adapted_css)
adapted_css = adapted_css.replace(
    '.screen{max-width:1480px;margin:auto;background:rgba(255,255,255,.987);border:1px solid #e8edf6;border-radius:18px;box-shadow:0 16px 60px #59331625;padding:26px 28px 18px 28px;min-height:calc(100vh - 36px);position:relative;overflow:hidden}',
    '.screen{max-width:1200px;margin: 0 auto !important; background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.05); backdrop-filter: blur(32px); -webkit-backdrop-filter: blur(32px); border: 1px solid rgba(128,128,128,0.2); border-radius: 28px; box-shadow: 0 40px 80px rgba(0,0,0,0.15); padding: 40px; position:relative; overflow:hidden;}'
)

# Dark mode overrides & general theme integration
adapted_css += """
[data-theme="dark"] .screen { background: rgba(9, 9, 11, 0.55); border: 1px solid rgba(255,255,255,0.08); }
[data-theme="light"] .screen { background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(0,0,0,0.06); }
dialog { background: var(--bg-card) !important; color: var(--ink) !important; border-color: var(--line) !important; }
.toast { background: var(--bg-card) !important; color: var(--ink) !important; border-color: var(--line) !important; }
.eyebrow { background: var(--bg-surface) !important; border-color: var(--line) !important; color: var(--ink) !important; }
h1, h2, h3, h4, p, label { color: var(--ink) !important; }
.subtitle, .section-head p { color: var(--soft) !important; }

/* REFINED & BALANCED UI (CLEAN, NO HARSH STROKES) */
.section, .verify-tile, .result-tile, .action-block {
    background: rgba(var(--bg-surface-rgb, 255,255,255), 0.6) !important;
    border: 1px solid rgba(128, 128, 128, 0.08) !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.02) !important;
    border-radius: 16px !important;
}
[data-theme="dark"] .section, [data-theme="dark"] .verify-tile, [data-theme="dark"] .result-tile, [data-theme="dark"] .action-block {
    background: rgba(25, 25, 30, 0.4) !important;
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
}

.entry {
    background: rgba(var(--bg-card-rgb, 255,255,255), 0.8) !important;
    border: 1px solid rgba(128, 128, 128, 0.15) !important;
    border-radius: 10px !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.01) !important;
    transition: all 0.25s ease !important;
}
[data-theme="dark"] .entry {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid rgba(255, 255, 255, 0.08) !important;
}
.entry:focus-within {
    background: var(--bg-surface) !important;
    border-color: rgba(var(--grad-c1-rgb, 99, 102, 241), 0.5) !important;
    box-shadow: 0 0 0 3px rgba(var(--grad-c1-rgb, 99, 102, 241), 0.1) !important;
}

.upload-box {
    background: rgba(128, 128, 128, 0.03) !important;
    border: 1px dashed rgba(128, 128, 128, 0.2) !important;
    border-radius: 12px !important;
}
[data-theme="dark"] .upload-box { border-color: rgba(255, 255, 255, 0.1) !important; }
.screen { border: 1px solid rgba(128, 128, 128, 0.1) !important; }

/* PREMIUM DOCUMENT ICONS FIX */
.doc-illustration {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: 48px !important;
    height: 48px !important;
    border-radius: 12px !important;
    flex: 0 0 48px !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05), inset 0 2px 4px rgba(255,255,255,0.1) !important;
}
"""

# 4. Inject Premium High-Visibility Icons directly into the HTML
new_aadhaar = '''<span class="doc-illustration aadhaar" style="background: linear-gradient(135deg, rgba(234, 172, 57, 0.15), rgba(209, 51, 113, 0.15)) !important; border: 1px solid rgba(234, 172, 57, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <path fill="url(#gradA1)" d="M22.5,45A27.5,27.5 0 0,1 77.5,45A27.5,27.5 0 0,1 22.5,45M10,45A40,40 0 0,0 90,45A40,40 0 0,0 10,45" />
  <path fill="url(#gradA2)" d="M35,45A15,15 0 0,1 65,45A15,15 0 0,1 35,45M25,45A25,25 0 0,0 75,45A25,25 0 0,0 25,45" />
  <defs>
    <linearGradient id="gradA1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#eaac39" /><stop offset="100%" stop-color="#d13371" /></linearGradient>
    <linearGradient id="gradA2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#d13371" /><stop offset="100%" stop-color="#eaac39" /></linearGradient>
  </defs>
</svg>
</span>'''
new_pan = '''<span class="doc-illustration pan" style="background: linear-gradient(135deg, rgba(51, 62, 156, 0.15), rgba(41, 171, 226, 0.15)) !important; border: 1px solid rgba(51, 62, 156, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradP)" xmlns="http://www.w3.org/2000/svg">
  <rect x="2" y="4" width="20" height="16" rx="3" ry="3" />
  <circle cx="8" cy="10" r="3" fill="#fff" />
  <rect x="14" y="9" width="6" height="2" fill="#fff" />
  <rect x="14" y="13" width="4" height="2" fill="#fff" />
  <defs>
    <linearGradient id="gradP" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#333e9c" /><stop offset="100%" stop-color="#29abe2" /></linearGradient>
  </defs>
</svg>
</span>'''
new_udyam = '''<span class="doc-illustration udyam" style="background: linear-gradient(135deg, rgba(29, 168, 94, 0.15), rgba(124, 218, 36, 0.15)) !important; border: 1px solid rgba(29, 168, 94, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradU)" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
  <defs>
    <linearGradient id="gradU" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1da85e" /><stop offset="100%" stop-color="#7cda24" /></linearGradient>
  </defs>
</svg>
</span>'''
new_gst = '''<span class="doc-illustration gst" style="background: linear-gradient(135deg, rgba(238, 155, 34, 0.15), rgba(234, 84, 85, 0.15)) !important; border: 1px solid rgba(238, 155, 34, 0.3) !important;">
<svg width="28" height="28" viewBox="0 0 24 24" fill="url(#gradG)" xmlns="http://www.w3.org/2000/svg">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
  <polyline points="14 2 14 8 20 8" fill="#fff" />
  <line x1="16" y1="13" x2="8" y2="13" stroke="#fff" stroke-width="2" />
  <line x1="16" y1="17" x2="8" y2="17" stroke="#fff" stroke-width="2" />
  <line x1="10" y1="9" x2="8" y2="9" stroke="#fff" stroke-width="2" />
  <defs>
    <linearGradient id="gradG" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#ee9b22" /><stop offset="100%" stop-color="#ea5455" /></linearGradient>
  </defs>
</svg>
</span>'''

original_html = re.sub(r'<span class="doc-illustration aadhaar">.*?</span>', new_aadhaar, original_html, flags=re.DOTALL)
original_html = re.sub(r'<span class="doc-illustration pan">.*?</span>', new_pan, original_html, flags=re.DOTALL)
original_html = re.sub(r'<span class="doc-illustration udyam">.*?</span>', new_udyam, original_html, flags=re.DOTALL)
original_html = re.sub(r'<span class="doc-illustration gst">.*?</span>', new_gst, original_html, flags=re.DOTALL)

# Remove the close application button
original_html = re.sub(r'<button class="close-application".*?</button>', '', original_html)

# 5. Bring in Global Header & Footer from index.html
with open('index.html', 'r') as f:
    idx = f.read()

header = re.search(r'(.*?)<section class="hero-quantum"', idx, re.DOTALL).group(1)
footer = re.search(r'(<footer class="quantum-footer">.*)', idx, re.DOTALL).group(1)

header = re.sub(r'<title>.*?</title>', '<title>Instant Loan Apply | Namdev Finvest</title>', header)

# Put it all together inside the properly padded container
full_body = f"""
<style>
  .apply-container-cyber {{
    min-height: 100vh;
    position: relative;
    background: var(--bg-dark);
    overflow-x: hidden;
    padding-top: 140px !important;
    padding-bottom: 60px !important;
  }}
  .cyber-orb {{
    position: absolute;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.4;
    z-index: 0;
    animation: floatOrb 15s infinite alternate ease-in-out;
  }}
  .orb-pink {{ width: 500px; height: 500px; background: var(--grad-c3); top: -100px; left: -100px; }}
  .orb-blue {{ width: 600px; height: 600px; background: var(--grad-c1); bottom: -150px; right: -100px; }}
  
  {adapted_css}
</style>

<div class="apply-container-cyber">
  <div class="cyber-orb orb-pink"></div>
  <div class="cyber-orb orb-blue"></div>
  {original_html}
</div>

<script>
  {original_js}
</script>
"""

# Cache bust
timestamp = str(int(time.time()))
header = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', header)
header = re.sub(r'src="js/main\.js\?v=\d+"', f'src="js/main.js?v={timestamp}"', header)

with open('apply.html', 'w') as f:
    f.write(header + full_body + footer)

print("apply.html updated with full Result journey & redirect.")
