with open('los-bre-engine.html', 'r') as f:
    content = f.read()

script_to_add = """
// Auto-populate from URL and start
window.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('name')) document.getElementById('name').value = params.get('name');
    if (params.get('mobile')) document.getElementById('mobile').value = params.get('mobile');
    if (params.get('amount')) document.getElementById('amount').value = params.get('amount');
    if (params.get('product')) {
      const sel = document.getElementById('product');
      for(let i=0; i<sel.options.length; i++){
         if(sel.options[i].text.includes(params.get('product'))) sel.selectedIndex = i;
      }
    }
    
    if (params.get('autoStart') === 'true') {
        setTimeout(() => startRun(true), 1000);
    }
});
"""

content = content.replace('resetAll();\n</script>', 'resetAll();\n' + script_to_add + '\n</script>')

with open('los-bre-engine.html', 'w') as f:
    f.write(content)
