with open('index.html', 'r') as f:
    content = f.read()

about_section = """
    <!-- ===================================================================
         ABOUT US & WHY CHOOSE US
         =================================================================== -->
    <section id="about" class="section-stage" style="background: var(--bg-surface);">
      <div class="container">
        <div class="section-head">
          <div class="card-header-tag" style="display: inline-block; margin-bottom: 12px;">ABOUT US</div>
          <h2 class="section-title">Empowering with <span class="highlight">Care, Compassion and Confidence</span></h2>
          <p class="section-subtitle">As a distinguished non-banking finance entity, Namdev Finvest is committed to delivering reliable and innovative financial solutions. We are officially recognised and regulated by the Reserve Bank of India, ensuring that we meet the highest standards of integrity and service excellence.</p>
        </div>

        <div class="bento-grid">
          <div class="bento-card bento-col-3" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <div class="bento-icon-wrapper">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            </div>
            <h3 class="bento-title" style="font-size: 1.1rem;">Quick & Easy Process</h3>
          </div>
          <div class="bento-card bento-col-3" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <div class="bento-icon-wrapper">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
            </div>
            <h3 class="bento-title" style="font-size: 1.1rem;">Attractive Interest Rates</h3>
          </div>
          <div class="bento-card bento-col-3" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <div class="bento-icon-wrapper">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
            </div>
            <h3 class="bento-title" style="font-size: 1.1rem;">Multi Repayment Options</h3>
          </div>
          <div class="bento-card bento-col-3" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <div class="bento-icon-wrapper">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            </div>
            <h3 class="bento-title" style="font-size: 1.1rem;">Minimal Documentation</h3>
          </div>
        </div>
      </div>
    </section>
"""

content = content.replace(
    '<!-- ===================================================================\n         JOURNEY (PROCESS PROCESS)\n         =================================================================== -->',
    about_section + '\n    <!-- ===================================================================\n         JOURNEY (PROCESS PROCESS)\n         =================================================================== -->'
)

with open('index.html', 'w') as f:
    f.write(content)
