import re
import time

css_upgrade = """
/* ==========================================================================
   HERO SECTION ULTRA-PREMIUM REDESIGN
   ========================================================================== */
.hero-quantum {
  min-height: 90vh !important;
  display: flex;
  align-items: center;
  position: relative;
}

/* Background Blending */
.hero-quantum::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, var(--bg-dark) 0%, transparent 50%, var(--bg-dark) 100%),
              linear-gradient(0deg, var(--bg-dark) 0%, transparent 30%);
  z-index: -1;
  pointer-events: none;
}

[data-theme="dark"] .hero-quantum::before {
  background: linear-gradient(90deg, var(--bg-dark) 0%, rgba(9,9,11,0.6) 50%, var(--bg-dark) 100%),
              linear-gradient(0deg, var(--bg-dark) 0%, transparent 30%);
}

.hero-headline {
  font-size: clamp(3rem, 5vw, 4.2rem) !important;
  line-height: 1.05 !important;
  font-weight: 800 !important;
  letter-spacing: -0.04em !important;
  margin-bottom: 24px !important;
  color: var(--text-primary);
}

.hero-lead {
  font-size: 1.15rem !important;
  line-height: 1.6 !important;
  color: var(--text-secondary);
  max-width: 90%;
  margin-bottom: 32px !important;
}

/* Glassmorphic Metrics Strip */
.hero-metrics-strip {
  display: flex !important;
  gap: 32px !important;
  background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.4) !important;
  backdrop-filter: blur(24px) !important;
  -webkit-backdrop-filter: blur(24px) !important;
  border: 1px solid rgba(128, 128, 128, 0.2) !important;
  padding: 24px 32px !important;
  border-radius: 20px !important;
  box-shadow: 0 20px 40px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.4) !important;
  margin-top: 40px !important;
}

[data-theme="dark"] .hero-metrics-strip {
  background: rgba(9, 9, 11, 0.4) !important;
  border-color: rgba(255,255,255,0.1) !important;
  box-shadow: 0 20px 40px rgba(0,0,0,0.3) !important;
}

.metric-value {
  font-size: 2rem !important;
  font-weight: 800 !important;
  letter-spacing: -0.02em !important;
  background: linear-gradient(135deg, var(--text-primary), var(--text-muted));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.metric-label {
  font-size: 0.8rem !important;
  font-weight: 600 !important;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-muted);
}

/* Floating Simulator Card */
.hologram-card {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  border-radius: 24px !important;
  padding: 36px !important;
  box-shadow: 0 30px 60px rgba(0,0,0,0.1), 0 0 0 1px rgba(var(--grad-c1-rgb, 99, 102, 241), 0.1) !important;
  position: relative;
  overflow: hidden;
  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
.hologram-card:hover {
  transform: translateY(-10px) !important;
  box-shadow: 0 40px 80px rgba(var(--grad-c1-rgb, 99, 102, 241), 0.15) !important;
}

/* Cool animated border pulse */
.hologram-card::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 24px;
  padding: 2px;
  background: linear-gradient(135deg, var(--grad-c1), var(--grad-c3), transparent 60%);
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: 0.5;
  pointer-events: none;
}

.sim-result-box {
  background: var(--bg-surface) !important;
  border: 1px solid var(--border) !important;
  border-radius: 16px !important;
  padding: 20px !important;
  display: flex !important;
  justify-content: space-between !important;
  align-items: center !important;
  margin: 24px 0 !important;
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
}

.sim-emi-amt {
  font-size: 2.2rem !important;
  font-weight: 800 !important;
  letter-spacing: -0.03em !important;
  color: var(--grad-c1, var(--brand)) !important;
}

.floating-nano-badge {
  background: var(--bg-elevated) !important;
  border: 1px solid var(--border) !important;
  box-shadow: 0 15px 30px rgba(0,0,0,0.08) !important;
  border-radius: 12px !important;
  padding: 12px 16px !important;
  display: flex !important;
  align-items: center !important;
  gap: 12px !important;
  backdrop-filter: blur(12px) !important;
  animation: floatUpDown 6s infinite ease-in-out !important;
}
.badge-top-left { animation-delay: 0s !important; }
.badge-bottom-right { animation-delay: -3s !important; }

@keyframes floatUpDown {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-15px); }
  100% { transform: translateY(0px); }
}

.nano-icon-circle {
  background: var(--bg-surface) !important;
  color: var(--text-primary) !important;
}
"""

try:
    with open('css/style.css', 'a') as f:
        f.write("\n" + css_upgrade)
    print("CSS Upgrades injected.")
except Exception as e:
    print(e)


# 2. Modify index.html background image opacity and brightness to make it pop
try:
    with open('index.html', 'r') as f:
        content = f.read()
        
    # Replace the dim grayscale background with a richer one
    old_bg = '<div style="position: absolute; inset: 0; z-index: -1; opacity: 0.25;">\n        <img src="https://images.unsplash.com/photo-I_Znq8FwMSg?auto=format&fit=crop&w=2400&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(100%);">\n      </div>'
    new_bg = '<div style="position: absolute; inset: 0; z-index: -2; opacity: 0.85;">\n        <img src="https://images.unsplash.com/photo-I_Znq8FwMSg?auto=format&fit=crop&w=2400&q=80" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(20%);">\n      </div>'
    
    if old_bg in content:
        content = content.replace(old_bg, new_bg)
    else:
        # Fallback regex if slight formatting difference
        content = re.sub(
            r'<div style="position: absolute; inset: 0; z-index: -1; opacity: 0.25;">\s*<img src="[^"]+" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale\(100%\);">\s*</div>',
            new_bg,
            content
        )
        
    # Also fix metric strip grid if any inline styles were conflicting
    # In index.html, hero-metrics-strip is just a div. The new CSS forces flex.
    
    # Cache bust
    timestamp = str(int(time.time()))
    content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
    
    with open('index.html', 'w') as f:
        f.write(content)
    print("index.html background updated.")
except Exception as e:
    print(e)
