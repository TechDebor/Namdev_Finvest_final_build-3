#!/bin/bash

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$APP_DIR/Namdev_MERN_App/server"
SITE_PID=""
API_PID=""

cleanup() {
  if [ -n "$SITE_PID" ] && kill -0 "$SITE_PID" 2>/dev/null; then
    kill "$SITE_PID" 2>/dev/null
    wait "$SITE_PID" 2>/dev/null
  fi
  if [ -n "$API_PID" ] && kill -0 "$API_PID" 2>/dev/null; then
    kill "$API_PID" 2>/dev/null
    wait "$API_PID" 2>/dev/null
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

cd "$APP_DIR" || exit 1
echo "=================================================="
echo "STARTING NAMDEV FINVEST"
echo "=================================================="

if ! curl -fsS --max-time 2 http://127.0.0.1:5000/api/health >/dev/null 2>&1; then
  if ! command -v node >/dev/null 2>&1; then
    echo "Node.js is required to start the verification API."
    exit 1
  fi
  if [ ! -d "$BACKEND_DIR/node_modules" ]; then
    echo "Backend dependencies are missing. Run npm install in $BACKEND_DIR."
    exit 1
  fi

  echo "Starting verification API on http://127.0.0.1:5000/"
  (cd "$BACKEND_DIR" && node server.js) >/tmp/namdev-finvest-api.log 2>&1 &
  API_PID=$!
  api_ready=false
  for attempt in $(seq 1 20); do
    if curl -fsS --max-time 1 http://127.0.0.1:5000/api/health >/dev/null 2>&1; then
      api_ready=true
      break
    fi
    if ! kill -0 "$API_PID" 2>/dev/null; then
      break
    fi
    sleep 1
  done
  if [ "$api_ready" != true ]; then
    echo "Verification API did not start. Recent server output:"
    tail -n 20 /tmp/namdev-finvest-api.log
    exit 1
  fi
else
  echo "Verification API is already running."
fi

if curl -fsS --max-time 2 http://127.0.0.1:8000/login.html 2>/dev/null | grep -q 'auth-layout'; then
  echo "Website is already running at http://localhost:8000/"
else
  if curl -fsS --max-time 1 http://127.0.0.1:8000/ >/dev/null 2>&1; then
    echo "Port 8000 is serving another site. Stop it before starting Namdev Finvest."
    exit 1
  fi
  echo "Starting website on http://localhost:8000/"
  python3 -m http.server 8000 > "$APP_DIR/server_logs.txt" 2>&1 &
  SITE_PID=$!
  sleep 1
  if ! curl -fsS --max-time 2 http://127.0.0.1:8000/login.html >/dev/null 2>&1; then
    echo "Website server did not start. Check $APP_DIR/server_logs.txt."
    exit 1
  fi
fi

echo "Opening the Namdev Finvest website..."
open "http://localhost:8000/index.html"
echo "The app is live. Press Ctrl+C to stop services started by this launcher."

WAIT_PID="${SITE_PID:-$API_PID}"
if [ -n "$WAIT_PID" ]; then
  wait "$WAIT_PID"
fi
