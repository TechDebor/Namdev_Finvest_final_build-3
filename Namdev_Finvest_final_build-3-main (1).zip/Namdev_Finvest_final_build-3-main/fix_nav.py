import re

files_to_update = ['index.html', 'msme.html', 'welcome-dashboard.html']

new_nav_css = """
    /* Simple Dropdown for Corporate Tabs */
    .dropdown-menu-simple {
      position: absolute;
      top: 100%;
      left: 0;
      background: var(--bg-surface, #ffffff);
      border: 1px solid var(--border, #e2e8f0);
      border-radius: 8px;
      padding: 10px 0;
      min-width: 220px;
      opacity: 0;
      visibility: hidden;
      transform: translateY(10px);
      transition: all 0.3s ease;
      box-shadow: 0 10px 25px rgba(0,0,0,0.05);
      z-index: 100;
    }
    
    .nav-item-dropdown:hover .dropdown-menu-simple {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    
    .dropdown-menu-simple li {
      list-style: none;
    }
    
    .dropdown-menu-simple a {
      display: block;
      padding: 8px 20px;
      color: var(--text-primary, #1a202c);
      text-decoration: none;
      font-size: 0.85rem;
      font-weight: 500;
      transition: background 0.2s, color 0.2s;
    }
    
    .dropdown-menu-simple a:hover {
      background: var(--bg, #f4f6fa);
      color: var(--brand, #5149dc);
    }
"""

new_nav_html = """
            <ul class="nav-menu">
              <li class="nav-item-dropdown">
                <a href="#about" class="nav-link">About <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="#">Get to Know Us</a></li>
                  <li><a href="#">Board of Directors</a></li>
                  <li><a href="#">Management Team</a></li>
                </ul>
              </li>

              <li class="nav-item-dropdown">
                <a href="#products" class="nav-link">Products <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-quantum">
                  <li>
                    <a href="msme.html" class="dropdown-link-quantum">
                      <div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
                      <div class="dropdown-info"><span class="dropdown-name">MSME Business Loans</span><span class="dropdown-sub">Capital up to ₹50 Lakhs</span></div>
                    </a>
                  </li>
                  <li>
                    <a href="two-wheeler.html" class="dropdown-link-quantum">
                      <div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="5" cy="17" r="3"></circle><circle cx="19" cy="17" r="3"></circle><path d="M5 14h5l3-6h4"></path><path d="M14 8h3"></path></svg></div>
                      <div class="dropdown-info"><span class="dropdown-name">Two Wheeler Loans</span><span class="dropdown-sub">ICE & Smart EV Bikes</span></div>
                    </a>
                  </li>
                  <li>
                    <a href="lap.html" class="dropdown-link-quantum">
                      <div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
                      <div class="dropdown-info"><span class="dropdown-name">Loan Against Property (LAP)</span><span class="dropdown-sub">Unlock up to ₹2.5 Crore</span></div>
                    </a>
                  </li>
                  <li>
                    <a href="solar.html" class="dropdown-link-quantum">
                      <div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line></svg></div>
                      <div class="dropdown-info"><span class="dropdown-name">Solar & Clean Energy</span><span class="dropdown-sub">100% Rooftop Green Finance</span></div>
                    </a>
                  </li>
                  <li>
                    <a href="tractor.html" class="dropdown-link-quantum">
                      <div class="dropdown-icon-box"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="12" rx="2"></rect><circle cx="7" cy="15" r="3"></circle><circle cx="17" cy="15" r="3"></circle><path d="M3 8v-2a2 2 0 0 1 2-2h4"></path></svg></div>
                      <div class="dropdown-info"><span class="dropdown-name">Tractor & Agri Loans</span><span class="dropdown-sub">Mechanizing Bharat</span></div>
                    </a>
                  </li>
                </ul>
              </li>

              <li class="nav-item-dropdown">
                <a href="#investor" class="nav-link" style="color: #ff4757;">Investor <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="#">Growth Partners</a></li>
                  <li><a href="#">Codes and Policies</a></li>
                  <li><a href="#">Annual Report</a></li>
                  <li><a href="#">ESG</a></li>
                  <li><a href="#">Registrar & Transfer Agent</a></li>
                  <li><a href="#">Disclosure Under Regulation 62...</a></li>
                  <li><a href="#">Composition of Board</a></li>
                  <li><a href="#">Financial Performance</a></li>
                  <li><a href="#">Credit Rating</a></li>
                </ul>
              </li>

              <li class="nav-item-dropdown">
                <a href="#team" class="nav-link">Our Team <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="#">Life at Namdev</a></li>
                  <li><a href="#">Gallery</a></li>
                  <li><a href="#">Employee Testimonials</a></li>
                  <li><a href="#">Career</a></li>
                </ul>
              </li>

              <li><a href="#" class="nav-link">Media</a></li>
              <li><a href="#" class="nav-link">Blog</a></li>
              <li><a href="#" class="nav-link">Contact</a></li>
            </ul>
"""

for file in files_to_update:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Add CSS if not present
        if 'dropdown-menu-simple' not in content:
            content = content.replace('</head>', f'<style>{new_nav_css}</style>\n</head>')

        # Replace Nav Menu
        # The regex targets everything between <ul class="nav-menu"> and the closing </ul> 
        # before the </nav> tag
        pattern = r'<ul class="nav-menu">.*?</nav>'
        # We need to replace just the <ul>...</ul> block
        
        # A safer replace based on finding the ul block
        start_idx = content.find('<ul class="nav-menu">')
        if start_idx != -1:
            end_idx = content.find('</nav>', start_idx)
            if end_idx != -1:
                # Need to find the exact closing </ul> of nav-menu, but replacing up to </nav> and re-adding </nav> is easier
                content = content[:start_idx] + new_nav_html + '\n          </nav>' + content[end_idx+6:]

        with open(file, 'w') as f:
            f.write(content)
            
        print(f"Updated {file}")
    except Exception as e:
        print(f"Failed on {file}: {e}")

