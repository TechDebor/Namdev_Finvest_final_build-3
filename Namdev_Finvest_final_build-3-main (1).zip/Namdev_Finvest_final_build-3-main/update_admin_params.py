import re

with open('namfindesk.html', 'r') as f:
    html = f.read()

# 1. New HTML for BRE View
new_bre_html = """    <div id="view-bre" class="content-area">
      <h1 class="page-title">DEBOR Engine - Comprehensive Rule Configuration</h1>
      <div style="margin-bottom: 20px; padding: 15px; background: #f0fdf4; border-left: 4px solid var(--success); border-radius: 4px; font-size: 14px; color: #166534;">
        <strong>Live Production Engine:</strong> Parameters defined here dynamically adjust Straight-Through Processing (STP) triggers across all integrated Namfindesk APIs.
      </div>

      <div style="display: flex; gap: 20px;">
        <!-- Left Panel: Products -->
        <div style="width: 250px; background: #fff; border: 1px solid var(--border); border-radius: 12px; overflow: hidden; height: fit-content; flex-shrink: 0;">
          <div style="padding: 15px; font-weight: bold; background: #f8fafc; border-bottom: 1px solid var(--border);">Global Policy Modules</div>
          <div class="nav-item" id="nav-mod-lap" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('lap')">🏢 Loan Against Property</div>
          <div class="nav-item" id="nav-mod-tractor" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('tractor')">🚜 Tractor Loan</div>
          <div class="nav-item" id="nav-mod-solar" style="margin: 0; border-radius: 0; color: var(--text); border-bottom: 1px solid var(--border);" onclick="loadProductConfig('solar')">☀️ Solar / Clean Energy</div>
          <div class="nav-item" id="nav-mod-msme" style="margin: 0; border-radius: 0; color: var(--text);" onclick="loadProductConfig('msme')">🏪 MSME Business Loan</div>
        </div>

        <!-- Right Panel: Parameters -->
        <div style="flex: 1; background: #fff; border: 1px solid var(--border); border-radius: 12px; padding: 25px; display: flex; flex-direction: column;">
          <h2 style="margin-top: 0;" id="bre-product-title">Configuring: Loan Against Property (LAP)</h2>
          
          <div style="height: 520px; overflow-y: auto; padding-right: 15px; display: flex; flex-direction: column; gap: 20px;">
            
            <!-- Category 1: Product Economics -->
            <div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: #f8fafc;">
              <h3 style="margin-top:0; font-size: 14px; color: var(--primary);">💰 Core Product Limits & LTV</h3>
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Min Loan Amount (₹)</label><input type="number" id="bre-min" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max Loan Amount (₹)</label><input type="number" id="bre-max" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max LTV Limit (%)</label><input type="number" id="bre-ltv" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max Tenure (Months)</label><input type="number" id="bre-tenure" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Min Property Age (Years)</label><input type="number" id="bre-propage" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
              </div>
            </div>

            <!-- Category 2: Credit Risk -->
            <div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: #f8fafc;">
              <h3 style="margin-top:0; font-size: 14px; color: var(--primary);">📊 Credit, Bureau & Affordability Rules</h3>
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Min CIBIL Score Auto-Pass</label><input type="number" id="bre-cibil" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max Allowed FOIR (%)</label><input type="number" id="bre-foir" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Min Annual Income (₹)</label><input type="number" id="bre-income" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max Banking Bounces (6m)</label><input type="number" id="bre-bounces" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Max Inquiries (30 days)</label><input type="number" id="bre-inq" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
              </div>
            </div>

            <!-- Category 3: Identity & Compliance -->
            <div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: #f8fafc;">
              <h3 style="margin-top:0; font-size: 14px; color: var(--primary);">🔍 KYC & Compliance Engine Strictness</h3>
              <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">OCR Name Match Threshold (%)</label><input type="number" id="bre-ocrmatch" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Dedupe Fuzzy Logic Strictness (%)</label><input type="number" id="bre-dedupe" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
              </div>
            </div>

            <!-- Category 4: Workflow & Automation -->
            <div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: #f8fafc;">
              <h3 style="margin-top:0; font-size: 14px; color: var(--primary);">⚙️ Automation & Routing Controls</h3>
              <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                <div>
                  <label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">Enable Straight-Through-Processing (STP)</label>
                  <select id="bre-stp" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border); background:#fff;">
                    <option value="true">YES - Auto Disburse if 0 Deviations</option>
                    <option value="false">NO - Always Route to Ops Checker</option>
                  </select>
                </div>
                <div><label style="font-size:11px; font-weight:bold; color:var(--text-muted); display:block; margin-bottom:4px;">SLA Escalation Timeout (Mins)</label><input type="number" id="bre-sla" class="input-group input" style="width:100%; padding:8px; border-radius:6px; border:1px solid var(--border);"></div>
              </div>
            </div>

          </div>

          <div style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 20px; text-align: right;">
            <button class="btn btn-outline" style="margin-right: 10px;">Discard Changes</button>
            <button class="btn btn-success" onclick="saveBREConfig()">🚀 Deploy Rules to DEBOR Engine</button>
          </div>
        </div>
      </div>
    </div>
"""

# Replace old view-bre
pattern_bre_html = r'<div id="view-bre" class="content-area">.*?<!-- FULL SCREEN RESOLVE UI -->'
html = re.sub(pattern_bre_html, new_bre_html + '\n  <!-- FULL SCREEN RESOLVE UI -->', html, flags=re.DOTALL)

# 2. Update JS Logic
new_js_logic = """
    // --- BRE CONFIGURATION LOGIC ---
    let currentConfigProduct = 'lap';
    const defaultConfigs = {
      lap: { title: "Loan Against Property (LAP)", ltv: 65, tenure: 180, min: 500000, max: 20000000, propage: 15, foir: 50, cibil: 700, income: 300000, bounces: 1, inq: 2, ocrmatch: 85, dedupe: 90, stp: "true", sla: 5 },
      tractor: { title: "Tractor Loan", ltv: 85, tenure: 84, min: 200000, max: 2500000, propage: 0, foir: 60, cibil: 650, income: 250000, bounces: 2, inq: 3, ocrmatch: 80, dedupe: 85, stp: "true", sla: 5 },
      solar: { title: "Solar & Clean Energy", ltv: 90, tenure: 120, min: 100000, max: 5000000, propage: 0, foir: 65, cibil: 680, income: 350000, bounces: 1, inq: 2, ocrmatch: 85, dedupe: 90, stp: "true", sla: 10 },
      msme: { title: "MSME Business Loan", ltv: 80, tenure: 60, min: 100000, max: 5000000, propage: 0, foir: 55, cibil: 700, income: 500000, bounces: 0, inq: 1, ocrmatch: 90, dedupe: 95, stp: "true", sla: 5 }
    };

    function loadProductConfig(productKey) {
      currentConfigProduct = productKey;
      
      // Update UI active state
      ['lap', 'tractor', 'solar', 'msme'].forEach(k => document.getElementById('nav-mod-'+k).style.background = (k===productKey) ? '#eef2ff' : 'transparent');
      
      let storedConfig = JSON.parse(localStorage.getItem('namfin_bre_configs') || '{}');
      let config = storedConfig[productKey] || defaultConfigs[productKey];
      
      document.getElementById('bre-product-title').innerText = "Configuring: " + defaultConfigs[productKey].title;
      document.getElementById('bre-ltv').value = config.ltv;
      document.getElementById('bre-tenure').value = config.tenure;
      document.getElementById('bre-min').value = config.min;
      document.getElementById('bre-max').value = config.max;
      document.getElementById('bre-propage').value = config.propage;
      
      document.getElementById('bre-cibil').value = config.cibil;
      document.getElementById('bre-foir').value = config.foir;
      document.getElementById('bre-income').value = config.income;
      document.getElementById('bre-bounces').value = config.bounces;
      document.getElementById('bre-inq').value = config.inq;
      
      document.getElementById('bre-ocrmatch').value = config.ocrmatch;
      document.getElementById('bre-dedupe').value = config.dedupe;
      
      document.getElementById('bre-stp').value = config.stp;
      document.getElementById('bre-sla').value = config.sla;
    }

    function saveBREConfig() {
      let storedConfig = JSON.parse(localStorage.getItem('namfin_bre_configs') || '{}');
      storedConfig[currentConfigProduct] = {
        ltv: document.getElementById('bre-ltv').value,
        tenure: document.getElementById('bre-tenure').value,
        min: document.getElementById('bre-min').value,
        max: document.getElementById('bre-max').value,
        propage: document.getElementById('bre-propage').value,
        cibil: document.getElementById('bre-cibil').value,
        foir: document.getElementById('bre-foir').value,
        income: document.getElementById('bre-income').value,
        bounces: document.getElementById('bre-bounces').value,
        inq: document.getElementById('bre-inq').value,
        ocrmatch: document.getElementById('bre-ocrmatch').value,
        dedupe: document.getElementById('bre-dedupe').value,
        stp: document.getElementById('bre-stp').value,
        sla: document.getElementById('bre-sla').value
      };
      localStorage.setItem('namfin_bre_configs', JSON.stringify(storedConfig));
      alert("✅ Configuration for " + defaultConfigs[currentConfigProduct].title + " deployed to DEBOR Engine successfully!");
    }
"""

pattern_js = r'// --- BRE CONFIGURATION LOGIC ---.*?// Populate Mock Leaderboard Data'
html = re.sub(pattern_js, new_js_logic + '\n    // Populate Mock Leaderboard Data', html, flags=re.DOTALL)

with open('namfindesk.html', 'w') as f:
    f.write(html)
