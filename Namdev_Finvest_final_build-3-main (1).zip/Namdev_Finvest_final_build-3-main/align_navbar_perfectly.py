import glob
import re
import time

css_fix = """
/* ==========================================================================
   ULTIMATE NAVBAR ALIGNMENT FIX
   ========================================================================== */
.nav-inner {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 10px 24px !important;
  gap: 20px !important;
}

.nav-menu {
  display: flex !important;
  align-items: center !important;
  gap: 16px !important;
  margin: 0 !important;
  padding: 0 !important;
  flex: 1 !important;
  justify-content: center !important;
}

.nav-actions {
  display: flex !important;
  align-items: center !important;
  gap: 12px !important;
  justify-content: flex-end !important;
}

.nav-link {
  line-height: 1 !important;
  display: inline-flex !important;
  align-items: center !important;
}

.btn-quantum {
  line-height: 1 !important;
  display: inline-flex !important;
  align-items: center !important;
  padding: 10px 20px !important;
}

.brand-text {
  line-height: 1.1 !important;
  justify-content: center !important;
}
"""

try:
    with open('css/style.css', 'r') as f:
        content = f.read()
    if "ULTIMATE NAVBAR ALIGNMENT FIX" not in content:
        with open('css/style.css', 'a') as f:
            f.write("\n" + css_fix)
        print("Ultimate alignment CSS injected.")
except Exception as e:
    print(f"Error on CSS: {e}")

# 2. Fix inline HTML issues
html_files = glob.glob('*.html')
timestamp = str(int(time.time()))

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Remove the massive margin-right on Login
        content = content.replace('style="margin-right: 20px; font-weight: 700; display: inline-flex; align-items: center;"', 'style="font-weight: 700; display: inline-flex; align-items: center;"')
        
        # Remove margin-left on Pay EMI list item
        content = re.sub(r'<li style="margin-left: 8px;">\s*<a href="payment\.html"', '<li><a href="payment.html"', content)
        content = re.sub(r'<li style="margin-left: 15px;">\s*<a href="payment\.html"', '<li><a href="payment.html"', content)

        # Remove any inline styles from ul.nav-menu that might override our new CSS
        content = re.sub(r'<ul class="nav-menu"[^>]*>', '<ul class="nav-menu">', content)

        # Bust cache
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'href="css/style\.css"', f'href="css/style.css?v={timestamp}"', content)
        
        with open(file, 'w') as f:
            f.write(content)
            
    except Exception as e:
        print(f"Error modifying {file}: {e}")

print("HTML alignment fixed and cache busted.")
