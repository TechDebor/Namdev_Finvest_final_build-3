import re
import time

with open('apply.html', 'r') as f:
    content = f.read()

# Remove the previous extreme borderless CSS block
content = re.sub(r'/\* ==========================================================================\s*PREMIUM BORDERLESS UI \(NO BLACK STROKES\).*?</style>', '</style>', content, flags=re.DOTALL)

# Add a much more balanced, Apple-style / Modern FinTech UI
balanced_css = """
  /* ==========================================================================
     REFINED & BALANCED UI (CLEAN, NO HARSH STROKES)
     ========================================================================== */
  
  /* Sections / Cards */
  .section, .verify-tile {
    background: rgba(var(--bg-surface-rgb, 255,255,255), 0.6) !important;
    border: 1px solid rgba(128, 128, 128, 0.08) !important; /* Extremely faint structural line, not black */
    box-shadow: 0 4px 15px rgba(0,0,0,0.02) !important;
    border-radius: 16px !important;
  }
  
  [data-theme="dark"] .section, [data-theme="dark"] .verify-tile {
    background: rgba(25, 25, 30, 0.4) !important;
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
  }

  /* Fill in the blanks (Inputs) */
  .entry {
    background: rgba(var(--bg-card-rgb, 255,255,255), 0.8) !important;
    border: 1px solid rgba(128, 128, 128, 0.15) !important; /* Soft faint border */
    border-radius: 10px !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.01) !important;
    transition: all 0.25s ease !important;
  }
  
  [data-theme="dark"] .entry {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid rgba(255, 255, 255, 0.08) !important;
  }

  .entry:focus-within {
    background: var(--bg-surface) !important;
    border-color: rgba(var(--grad-c1-rgb, 99, 102, 241), 0.5) !important;
    box-shadow: 0 0 0 3px rgba(var(--grad-c1-rgb, 99, 102, 241), 0.1) !important;
  }
  
  /* Upload Box */
  .upload-box {
    background: rgba(128, 128, 128, 0.03) !important;
    border: 1px dashed rgba(128, 128, 128, 0.2) !important;
    border-radius: 12px !important;
  }
  [data-theme="dark"] .upload-box {
    border-color: rgba(255, 255, 255, 0.1) !important;
  }

  /* Main Apply Screen Panel */
  .screen {
    border: 1px solid rgba(128, 128, 128, 0.1) !important;
  }
"""

content = content.replace('</style>', balanced_css + '\n</style>')

# Cache bust
timestamp = str(int(time.time()))
content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)

with open('apply.html', 'w') as f:
    f.write(content)

print("Restored balanced UI aesthetics.")
