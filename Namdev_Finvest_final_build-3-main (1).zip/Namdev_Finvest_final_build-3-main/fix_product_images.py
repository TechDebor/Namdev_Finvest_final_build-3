import re
import os

images = {
    'msme.html': 'https://images.unsplash.com/photo-1556761175-5973dc0f32b7?auto=format&fit=crop&w=2400&q=80', 
    'two-wheeler.html': 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=2400&q=80', 
    'lap.html': 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2400&q=80', 
    'solar.html': 'https://images.unsplash.com/photo-1509391366360-1f9509e98822?auto=format&fit=crop&w=2400&q=80', 
    'tractor.html': 'https://images.unsplash.com/photo-1592982537447-6f2a6a0c5c58?auto=format&fit=crop&w=2400&q=80'
}

for file, img in images.items():
    if not os.path.exists(file):
        continue
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        if '<div style="position: absolute; inset: 0; z-index: -1' in content:
            print(f"Image already in {file}, skipping")
            continue
            
        pattern = r'(<section[^>]*class="product-hero"[^>]*>)'
        match = re.search(pattern, content)
        
        if match:
            section_tag = match.group(1)
            new_section_tag = section_tag
            if 'position: relative' not in new_section_tag:
                if 'style="' in new_section_tag:
                    new_section_tag = new_section_tag.replace('style="', 'style="position: relative; overflow: hidden; ')
                else:
                    new_section_tag = new_section_tag.replace('>', ' style="position: relative; overflow: hidden;">')
                    
            bg_div = f"""
      <div style="position: absolute; inset: 0; z-index: -1; opacity: 0.2;">
        <img src="{img}" style="width: 100%; height: 100%; object-fit: cover; filter: grayscale(80%);">
      </div>
"""
            content = content.replace(section_tag, new_section_tag + bg_div)
            content = content.replace('<div class="container">', '<div class="container" style="position: relative; z-index: 1;">', 1)
            content = content.replace('<div class="product-hero-grid">', '<div class="product-hero-grid" style="position: relative; z-index: 1;">', 1)

            with open(file, 'w') as f:
                f.write(content)
            print(f"Added premium background to {file}")
            
    except Exception as e:
        print(f"Error on {file}: {e}")
