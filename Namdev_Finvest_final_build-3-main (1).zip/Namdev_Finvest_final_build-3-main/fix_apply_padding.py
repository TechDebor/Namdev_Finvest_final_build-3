import re
import time

with open('apply.html', 'r') as f:
    content = f.read()

# Fix margin collapse and overlap by moving spacing from margin to padding
content = re.sub(
    r'\.apply-container-cyber\s*\{([^\}]+)\}',
    r'.apply-container-cyber {\1 padding-top: 140px !important; padding-bottom: 60px !important; }',
    content
)

content = re.sub(
    r'\.screen\{max-width:1200px;margin: 140px auto 60px auto;',
    r'.screen{max-width:1200px;margin: 0 auto;',
    content
)

# Also ensure .screen has !important on its margin just in case
if 'margin: 0 auto !important;' not in content:
    content = content.replace('margin: 0 auto;', 'margin: 0 auto !important;')

# Cache bust
timestamp = str(int(time.time()))
content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)

with open('apply.html', 'w') as f:
    f.write(content)
print("Fixed navbar overlap issue on apply.html")
