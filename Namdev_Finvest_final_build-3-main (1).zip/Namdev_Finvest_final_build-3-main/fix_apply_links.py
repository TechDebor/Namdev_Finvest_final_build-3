import glob
import re

html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # The instant apply button currently looks like:
        # <button class="btn-quantum" data-open-modal data-product="msme"> Instant Apply ... </button>
        # We need to change it to an anchor link pointing to apply.html
        
        old_btn_pattern = r'<button class="btn-quantum"[^>]*data-open-modal[^>]*>\s*Instant Apply\s*<svg[^>]*>.*?</svg>\s*</button>'
        new_btn = '<a href="apply.html" class="btn-quantum" style="text-decoration: none;">Instant Apply <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>'
        
        content = re.sub(old_btn_pattern, new_btn, content, flags=re.DOTALL)
        
        with open(file, 'w') as f:
            f.write(content)
    except Exception as e:
        print(f"Error on {file}: {e}")
print("Linked Instant Apply buttons to apply.html")
