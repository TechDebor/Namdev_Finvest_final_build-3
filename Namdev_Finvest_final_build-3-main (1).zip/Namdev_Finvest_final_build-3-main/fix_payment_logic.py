with open('payment.html', 'r') as f:
    content = f.read()

# Replace the alert button with a form submit
content = content.replace(
    '''<div style="margin-top: 24px;">''',
    '''<form id="paymentForm" style="margin-top: 24px;">'''
)
# Wait, the bento grid is split into two columns (7 and 5)
# If I wrap the whole thing in a form, it needs to wrap both columns.
