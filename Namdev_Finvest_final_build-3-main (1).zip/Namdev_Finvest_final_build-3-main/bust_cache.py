import glob
import time

html_files = glob.glob('*.html')
timestamp = str(int(time.time()))

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # Replace both style.css and components.css to break cache
        # It might currently be "css/style.css" or "css/style.css?v=..."
        import re
        content = re.sub(r'href="css/style\.css[^"]*"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'href="css/components\.css[^"]*"', f'href="css/components.css?v={timestamp}"', content)
        content = re.sub(r'src="js/main\.js[^"]*"', f'src="js/main.js?v={timestamp}"', content)
        
        with open(file, 'w') as f:
            f.write(content)
        print(f"Cache busted for {file}")
    except Exception as e:
        print(f"Error on {file}: {e}")

