import re

# Correct Header with full nav and action buttons (copied exactly from index.html)
head_nav_actions = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Namdev Finvest | {TITLE}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;800&family=Space+Grotesk:wght@400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/components.css">
  <style>
    /* Simple Dropdown for Corporate Tabs */
    .dropdown-menu-simple { position: absolute; top: 100%; left: 0; background: var(--bg-surface, #ffffff); border: 1px solid var(--border, #e2e8f0); border-radius: 8px; padding: 10px 0; min-width: 220px; opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.3s ease; box-shadow: 0 10px 25px rgba(0,0,0,0.05); z-index: 100; }
    .nav-item-dropdown:hover .dropdown-menu-simple { opacity: 1; visibility: visible; transform: translateY(0); }
    .dropdown-menu-simple li { list-style: none; }
    .dropdown-menu-simple a { display: block; padding: 8px 20px; color: var(--text-primary, #1a202c); text-decoration: none; font-size: 0.85rem; font-weight: 500; transition: background 0.2s, color 0.2s; }
    .dropdown-menu-simple a:hover { background: var(--bg, #f4f6fa); color: var(--brand, #5149dc); }
    
    .section-stage { padding: 80px 20px; }
    .content-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; max-width: 1200px; margin: 0 auto; }
    .info-card { background: var(--bg-surface); border: 1px solid var(--border); padding: 30px; border-radius: 12px; transition: transform 0.3s; }
    .info-card:hover { transform: translateY(-5px); border-color: var(--brand); }
  </style>
</head>
<body>
  <!-- Ambient Minimalist Monochrome Layer -->
  <div class="ambient-glow-layer"><div class="glow-orb glow-orb-1"></div><div class="glow-orb glow-orb-2"></div></div>
  <div class="cyber-grid-bg"></div>
  <canvas id="cyberGridCanvas" class="cyber-grid-canvas"></canvas>

  <div class="app-container">
    <header class="quantum-nav">
      <div class="container">
        <div class="nav-inner">
          <a href="index.html" class="brand-quantum">
            <div class="brand-emblem">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>
              </svg>
            </div>
            <div class="brand-text">
              <span class="brand-title">NAMDEV FINVEST</span>
              <span class="brand-sub">NBFC // RBI REGISTERED</span>
            </div>
          </a>

          <nav>
            <ul class="nav-menu">
              <li class="nav-item-dropdown">
                <a href="about.html" class="nav-link">About <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="about.html#who-we-are">Get to Know Us</a></li>
                  <li><a href="about.html#board">Board of Directors</a></li>
                  <li><a href="about.html#management">Management Team</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="index.html#products" class="nav-link">Products <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-quantum">
                  <li><a href="msme.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">MSME Business Loans</span></div></a></li>
                  <li><a href="two-wheeler.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Two Wheeler Loans</span></div></a></li>
                  <li><a href="lap.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Loan Against Property (LAP)</span></div></a></li>
                  <li><a href="solar.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Solar & Clean Energy</span></div></a></li>
                  <li><a href="tractor.html" class="dropdown-link-quantum"><div class="dropdown-info"><span class="dropdown-name">Tractor & Agri Loans</span></div></a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="investor.html" class="nav-link" style="color: var(--brand);">Investor <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="investor.html#partners">Growth Partners</a></li>
                  <li><a href="investor.html#policies">Codes and Policies</a></li>
                  <li><a href="investor.html#reports">Annual Report</a></li>
                  <li><a href="investor.html#esg">ESG</a></li>
                  <li><a href="investor.html#rta">Registrar & Transfer Agent</a></li>
                  <li><a href="investor.html#disclosures">Disclosure Under Regulation 62...</a></li>
                  <li><a href="investor.html#financials">Financial Performance</a></li>
                </ul>
              </li>
              <li class="nav-item-dropdown">
                <a href="team.html" class="nav-link">Our Team <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline; margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg></a>
                <ul class="dropdown-menu-simple">
                  <li><a href="team.html#culture">Life at Namdev</a></li>
                  <li><a href="team.html#gallery">Gallery</a></li>
                  <li><a href="team.html#careers">Career - Apply for positions</a></li>
                </ul>
              </li>
              <li><a href="contact.html" class="nav-link">Contact</a></li>
              <li style="margin-left: 15px;"><a href="payment.html" class="btn-quantum" style="padding: 8px 16px; font-size: 0.85rem; text-decoration: none;">Pay EMI</a></li>
            </ul>
          </nav>

          <div class="nav-actions">
            <!-- THEME TOGGLE BUTTON -->
            <button id="themeToggleBtn" class="icon-toggle-btn" aria-label="Toggle Theme">
              <svg class="sun-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: none;"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
              <svg class="moon-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
            </button>
            <button id="audioToggleBtn" class="icon-toggle-btn" aria-label="Toggle Audio Sound FX">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
            </button>
            <button class="btn-quantum" data-open-modal data-product="msme">
              Instant Apply
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </button>
            <button id="mobileNavToggle" class="mobile-nav-toggle" aria-label="Open Navigation">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
          </div>
        </div>
      </div>
    </header>

    <!-- Mobile Drawer -->
    <div id="mobileDrawer" class="mobile-drawer">
      <div class="mobile-drawer-header">
        <div class="brand-text">
          <span class="brand-title">NAMDEV FINVEST</span>
          <span class="brand-sub">MINIMALIST MOBILE</span>
        </div>
        <button id="mobileDrawerClose" class="mobile-drawer-close">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <ul class="mobile-menu-links">
        <li><a href="index.html" class="mobile-link">Home Hub</a></li>
        <li><a href="msme.html" class="mobile-link">MSME Business Loans</a></li>
        <li><a href="two-wheeler.html" class="mobile-link">Two Wheeler Loans</a></li>
        <li><a href="lap.html" class="mobile-link">Loan Against Property</a></li>
        <li><a href="solar.html" class="mobile-link">Solar Finance</a></li>
        <li><a href="about.html" class="mobile-link">About Us</a></li>
        <li><a href="investor.html" class="mobile-link">Investor Relations</a></li>
        <li><a href="team.html" class="mobile-link">Our Team</a></li>
        <li><a href="contact.html" class="mobile-link">Contact</a></li>
        <li><a href="payment.html" class="mobile-link" style="color: var(--brand);">Pay EMI</a></li>
      </ul>
    </div>
"""

footer = """
    <footer class="quantum-footer">
      <div class="container">
        <div class="footer-bottom-bar" style="border: none; padding-top: 0;">
          <div>© 2026 Namdev Finvest Limited • CIN: U65921RJ1997PLC047090</div>
          <div class="status-indicator-strip"><span class="pulse-dot"></span> 137+ BRANCHES ACTIVE</div>
        </div>
      </div>
    </footer>
  </div>

  <script src="js/main.js"></script>
  <script src="js/products.js"></script>
</body>
</html>
"""

# Bulletproof wrapper for hero section that works with their flex CSS (which defaults to row unless constrained)
def wrap_hero(section_id, badge, title, desc):
    return f"""
    <section class="hero-quantum" id="{section_id}" style="justify-content: center; align-items: center; text-align: center; min-height: 50vh;">
      <div class="hero-grid" style="width: 100%; display: block;">
        <div class="hero-content-col" style="margin: 0 auto; max-width: 900px;">
          <div class="hero-badge-row" style="justify-content: center;">
            <span class="badge-quantum">{badge}</span>
          </div>
          <h1 class="hero-headline">{title}</h1>
          <p class="hero-lead">{desc}</p>
        </div>
      </div>
    </section>
"""

# ABOUT
about_hero = wrap_hero("who-we-are", "ESTABLISHED 2013", "Empowering Rural Bharat.", "Namdev Finvest Limited is a fast-growing RBI-registered NBFC dedicated to driving financial inclusion across India's underbanked sectors. With AUM crossing ₹1,200 Cr, we specialize in MSME, Green Finance, and Asset-backed lending.")
about_content = head_nav_actions.replace("{TITLE}", "About Us") + about_hero + """
    <section class="section-stage" id="board">
      <div class="container">
        <h2 style="text-align:center; font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px; color: var(--text-primary);">Board of Directors & Management</h2>
        <div class="content-grid">
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Jitendra Tanwar</h3>
            <p style="color: var(--brand); font-size: 0.9rem; font-weight:bold;">Managing Director & CEO</p>
            <p style="margin-top: 15px;">A visionary leader driving Namdev Finvest's mission to bridge the credit gap in semi-urban and rural geographies through innovative underwriting.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Independent Directors</h3>
            <p style="color: var(--brand); font-size: 0.9rem; font-weight:bold;">Corporate Governance</p>
            <p style="margin-top: 15px;">Our board comprises distinguished veterans from the banking, finance, and regulatory sectors ensuring the highest standards of ESG and governance.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:5px;">Core Management</h3>
            <p style="color: var(--brand); font-size: 0.9rem; font-weight:bold;">Execution Leaders</p>
            <p style="margin-top: 15px;">A robust team of domain experts leading Credit, Operations, Compliance, and Technology, delivering a seamless 10-minute digital lending experience.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('about.html', 'w') as f: f.write(about_content)


# INVESTOR
invest_hero = wrap_hero("partners", "CAPITAL PARTNERS", "Growth & Investors.", "Namdev Finvest is backed by globally respected institutional investors and development finance institutions. We recently raised $19 Million in Pre-Series C funding led by Maj Invest to deepen our presence in rural India.")
investor_content = head_nav_actions.replace("{TITLE}", "Investor Relations") + invest_hero + """
    <section class="section-stage">
      <div class="container">
        <div class="content-grid">
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Maj Invest</h3>
            <p>Lead Investor - Pre-Series C</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">Incofin</h3>
            <p>Global Impact Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">BII</h3>
            <p>British International Investment</p>
          </div>
          <div class="info-card" style="text-align: center;">
            <h3 style="font-size: 1.5rem; margin-bottom: 10px;">FMO & IIX</h3>
            <p>Development Finance Partners</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section-stage" id="disclosures">
      <div class="container">
        <h2 style="font-family: 'Syne'; font-size: 2.5rem; margin-bottom: 40px; color: var(--text-primary);">Disclosures & ESG</h2>
        <div class="content-grid">
          <div class="info-card" id="esg">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">ESG Commitment</h3>
            <p>Namdev Finvest Pvt. Ltd. earned the GOLD-level Client Protection certification from MFR for its high standards in social and environmental performance.</p>
          </div>
          <div class="info-card" id="financials">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Financial Performance</h3>
            <p>AUM crossed ₹1,200 Cr mark in FY24. Successfully raised USD 37 million (324 crore) from globally respected partners through listed NCDs and ECB structures.</p>
          </div>
          <div class="info-card" id="rta">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">RTA, DT & GRO</h3>
            <p>Access official documentation regarding Registrar & Transfer Agent details, Debenture Trustees, and Grievance Redressal Officers.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('investor.html', 'w') as f: f.write(investor_content)


# TEAM
team_hero = wrap_hero("culture", "LIFE AT NAMDEV", "Build the Future of Finance.", "Join a dynamic team of over 1,000+ professionals spread across 137+ branches in Rajasthan, Gujarat, MP, Punjab, and Delhi NCR. We are mechanizing Bharat and funding green transitions.")
team_content = head_nav_actions.replace("{TITLE}", "Our Team") + team_hero + """
    <section class="section-stage" id="careers">
      <div class="container">
        <div class="content-grid">
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Careers at Namdev</h3>
            <p style="margin-bottom: 25px;">We are always looking for ambitious Credit Managers, Branch Managers, and Technology experts.</p>
            <a href="https://namdevcareers.peoplestrong.com/" target="_blank" class="btn-quantum" style="text-decoration:none; padding:10px 20px; font-size:0.9rem;">View Open Roles</a>
          </div>
          <div class="info-card" id="gallery">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Gallery & Culture</h3>
            <p>Experience our vibrant branch culture, offsites, and the impact we create on the ground with our MSME partners and Solar adopters.</p>
          </div>
          <div class="info-card">
            <h3 style="font-size:1.5rem; margin-bottom:10px;">Employee Testimonials</h3>
            <p>Hear directly from our branch leaders and credit officers about their rapid career growth journeys within Namdev Finvest.</p>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('team.html', 'w') as f: f.write(team_content)


# CONTACT
contact_hero = wrap_hero("support", "24/7 SUPPORT", "Contact Us.", "Whether you need a new loan, support with your EMI, or want to locate your nearest branch, our team is ready to assist you.")
contact_content = head_nav_actions.replace("{TITLE}", "Contact Us") + contact_hero + """
    <section class="section-stage">
      <div class="container">
        <div class="content-grid" style="grid-template-columns: 1fr 1fr;">
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Corporate Headquarters</h3>
            <p style="font-size: 1.1rem; margin-bottom: 10px;">"Namdev House", Plot No. 21</p>
            <p style="font-size: 1.1rem; margin-bottom: 10px;">Neer Sagar-A, Bhankrota</p>
            <p style="font-size: 1.1rem; margin-bottom: 30px;">Jaipur, Rajasthan - 302026</p>
            
            <h4 style="color: var(--brand); margin-bottom: 5px;">Toll Free</h4>
            <p style="font-size: 1.5rem; font-weight: bold; margin-bottom: 20px; color: var(--text-primary);">1800-103-5800</p>
            
            <h4 style="color: var(--brand); margin-bottom: 5px;">Email</h4>
            <p style="font-size: 1.2rem; font-weight: bold; color: var(--text-primary);">info@namfin.in</p>
          </div>
          <div class="info-card">
            <h3 style="font-size: 1.8rem; margin-bottom: 20px;">137+ Branches Across India</h3>
            <p style="margin-bottom: 20px;">We are expanding rapidly to serve you better. Find us in:</p>
            <ul style="color: var(--text-primary); font-size: 1.1rem; line-height: 2; padding-left: 20px; font-weight: 600;">
              <li>Rajasthan</li>
              <li>Gujarat</li>
              <li>Madhya Pradesh</li>
              <li>Punjab</li>
              <li>Haryana</li>
              <li>Delhi NCR</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
""" + footer
with open('contact.html', 'w') as f: f.write(contact_content)


# Finally, inject the correct navigation (with nav-actions) back into all other files that got mangled by fix_nav.py
import glob
html_files = glob.glob('*.html')
correct_nav_block = head_nav_actions[head_nav_actions.find('<div class="nav-inner">'):head_nav_actions.find('</header>')]

for file in html_files:
    if file in ['about.html', 'investor.html', 'team.html', 'contact.html']:
        continue
    try:
        with open(file, 'r') as f:
            content = f.read()
        
        # Replace the mangled nav-inner
        s_idx = content.find('<div class="nav-inner">')
        if s_idx != -1:
            # We want to replace up to the end of <div class="nav-inner">...</div> which is right before </header>
            # The safest way is to replace between <div class="nav-inner"> and </header>
            e_idx = content.find('</header>', s_idx)
            if e_idx != -1:
                content = content[:s_idx] + correct_nav_block + content[e_idx:]
                
        # Also ensure Mobile Drawer is present and complete
        if "id=\"mobileDrawer\"" not in content and file != "index.html":
            # inject mobile drawer before footer
            f_idx = content.find('<footer')
            if f_idx != -1:
                drawer_block = head_nav_actions[head_nav_actions.find('<!-- Mobile Drawer -->'):head_nav_actions.find('    <footer')]
                # if the drawer_block isn't empty, insert it
                if "mobileDrawer" in drawer_block:
                    content = content[:f_idx] + drawer_block + content[f_idx:]
                
        with open(file, 'w') as f:
            f.write(content)
        print(f"Restored full nav and actions in {file}")
    except Exception as e:
        print(f"Failed to restore nav in {file}: {e}")

