import time
import glob
import re

css_fix = """
/* ==========================================================================
   NAVBAR WRAPPING & SPACING FIX
   ========================================================================== */
.nav-menu {
  flex-wrap: nowrap !important;
  gap: 8px !important;
}
.nav-link, .brand-title, .brand-sub, .btn-quantum {
  white-space: nowrap !important;
}
.brand-text, .btn-quantum, .nav-actions, .brand-quantum {
  flex-shrink: 0 !important;
}
.brand-sub {
  font-size: 0.65rem !important;
  letter-spacing: 0.08em !important;
}
"""

try:
    with open('css/style.css', 'r') as f:
        content = f.read()
    if "NAVBAR WRAPPING & SPACING FIX" not in content:
        with open('css/style.css', 'a') as f:
            f.write("\n" + css_fix)
        print("CSS wrap fix injected.")
except Exception as e:
    print(f"Error on CSS: {e}")

# Bust cache again to ensure it applies instantly
timestamp = str(int(time.time()))
for file in glob.glob('*.html'):
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
        content = re.sub(r'href="css/style\.css"', f'href="css/style.css?v={timestamp}"', content)
        
        with open(file, 'w') as f:
            f.write(content)
    except Exception as e:
        pass
print("Cache busted.")

