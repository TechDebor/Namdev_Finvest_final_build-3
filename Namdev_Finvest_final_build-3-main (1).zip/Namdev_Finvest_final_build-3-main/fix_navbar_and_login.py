import glob
import re

# 1. Bruteforce Fix Navbar Wrapping in HTML
html_files = glob.glob('*.html')
for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()
            
        # Force white-space nowrap directly on the anchor tags
        content = content.replace('class="nav-link"', 'class="nav-link" style="white-space: nowrap;"')
        content = content.replace('class="brand-title"', 'class="brand-title" style="white-space: nowrap;"')
        content = content.replace('class="brand-sub"', 'class="brand-sub" style="white-space: nowrap; font-size: 0.65rem;"')
        content = content.replace('class="btn-quantum"', 'class="btn-quantum" style="white-space: nowrap; flex-shrink: 0;"')
        
        # Clean up double styles if they occur
        content = content.replace('style="white-space: nowrap;" style="', 'style="white-space: nowrap; ')
        
        # Fix the spacing of Pay EMI so it looks like a proper button
        content = content.replace('<li style="margin-left: 15px;"><a href="payment.html" class="btn-quantum"', 
                                  '<li style="margin-left: 8px;"><a href="payment.html" class="btn-quantum" style="white-space: nowrap; flex-shrink: 0; padding: 8px 20px; border-radius: 50px; font-weight: 600;"')

        # Reduce nav-menu gap to prevent overflow on 13" laptops
        content = re.sub(r'<ul class="nav-menu".*?>', '<ul class="nav-menu" style="display: flex; gap: 12px; align-items: center; margin: 0; padding: 0;">', content)

        with open(file, 'w') as f:
            f.write(content)
            
    except Exception as e:
        print(e)

# 2. Redesign login.html to be ultra-futuristic
with open('index.html', 'r') as f:
    idx = f.read()
header_match = re.search(r'(.*?)<section class="hero-quantum"', idx, re.DOTALL)
footer_match = re.search(r'(<footer class="quantum-footer">.*)', idx, re.DOTALL)

if header_match and footer_match:
    header = header_match.group(1)
    footer = footer_match.group(1)
    
    # Ensure title is correct
    header = re.sub(r'<title>.*?</title>', '<title>Namdev Finvest | Futuristic Login</title>', header)
    
    futuristic_login_body = """
    <style>
      .login-container-cyber {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        background: var(--bg-dark);
      }
      .cyber-orb {
        position: absolute;
        border-radius: 50%;
        filter: blur(80px);
        opacity: 0.5;
        z-index: 0;
        animation: floatOrb 10s infinite alternate ease-in-out;
      }
      .orb-pink { width: 400px; height: 400px; background: var(--grad-c3); top: -100px; left: -100px; }
      .orb-blue { width: 500px; height: 500px; background: var(--grad-c1); bottom: -150px; right: -100px; }
      
      @keyframes floatOrb {
        0% { transform: translate(0, 0) scale(1); }
        100% { transform: translate(50px, 50px) scale(1.1); }
      }

      .login-glass-panel {
        position: relative;
        z-index: 10;
        width: 100%;
        max-width: 480px;
        background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.05);
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 24px;
        padding: 48px;
        box-shadow: 0 30px 60px rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.1);
      }
      
      [data-theme="dark"] .login-glass-panel {
        background: rgba(9, 9, 11, 0.6);
        border: 1px solid rgba(255,255,255,0.05);
      }
      [data-theme="light"] .login-glass-panel {
        background: rgba(255, 255, 255, 0.8);
        border: 1px solid rgba(0,0,0,0.05);
      }

      .input-cyber {
        width: 100%;
        padding: 16px 20px;
        border-radius: 12px;
        background: rgba(128,128,128,0.1);
        border: 1px solid transparent;
        color: var(--text-primary);
        font-size: 1rem;
        outline: none;
        transition: all 0.3s;
        margin-bottom: 20px;
      }
      
      .input-cyber:focus {
        border-color: var(--grad-c1);
        background: rgba(128,128,128,0.15);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
      }
      
      .btn-cyber-login {
        width: 100%;
        padding: 16px;
        border-radius: 12px;
        border: none;
        background: var(--theme-btn-grad);
        color: #fff;
        font-size: 1.1rem;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
        box-shadow: 0 8px 25px var(--theme-btn-glow);
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
      }
      .btn-cyber-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px var(--theme-btn-glow);
      }
    </style>

    <div class="login-container-cyber">
      <div class="cyber-orb orb-pink"></div>
      <div class="cyber-orb orb-blue"></div>
      
      <div class="login-glass-panel">
        <div style="text-align: center; margin-bottom: 40px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" style="width: 48px; height: 48px; margin-bottom: 16px; color: var(--text-primary);">
            <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
            <polyline points="2 17 12 22 22 17"></polyline>
            <polyline points="2 12 12 17 22 12"></polyline>
          </svg>
          <h1 style="font-family: 'Syne', sans-serif; font-size: 2rem; margin-bottom: 8px;">Portal Access</h1>
          <p style="color: var(--text-muted); font-size: 0.95rem;">Enter your credentials to access the Namdev Finvest unified dashboard.</p>
        </div>
        
        <form onsubmit="event.preventDefault(); document.getElementById('logLoad').style.display='block'; setTimeout(()=>window.location.href='namfindesk.html', 1500);">
          <div>
            <label style="display: block; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; color: var(--text-secondary);">Employee ID / Email</label>
            <input type="text" class="input-cyber" placeholder="e.g. NAM-4920" required>
          </div>
          
          <div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <label style="font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-secondary);">Password</label>
              <a href="#" class="highlight" style="font-size: 0.85rem; text-decoration: none; font-weight: 600;">Recover</a>
            </div>
            <input type="password" class="input-cyber" placeholder="••••••••" required>
          </div>
          
          <button type="submit" class="btn-cyber-login" style="margin-top: 10px;">
            Authenticate
            <svg id="logLoad" style="display: none; animation: spin 1s linear infinite;" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
          </button>
        </form>
        
        <div style="text-align: center; margin-top: 30px; font-size: 0.85rem; color: var(--text-muted);">
          Protected by AES-256 Encryption & RBI Guidelines.
        </div>
      </div>
    </div>
    """
    
    with open('login.html', 'w') as f:
        f.write(header + futuristic_login_body + footer)
    print("Futuristic login.html created.")
