import re
import time

# Extract header and footer from index.html to maintain the navbar and structure
with open('index.html', 'r') as f:
    idx = f.read()

header_match = re.search(r'(.*?)<section class="hero-quantum"', idx, re.DOTALL)
footer_match = re.search(r'(<footer class="quantum-footer">.*)', idx, re.DOTALL)

if header_match and footer_match:
    header = header_match.group(1)
    footer = footer_match.group(1)
    
    # Ensure title is correct
    header = re.sub(r'<title>.*?</title>', '<title>Namdev Finvest | Mobile OTP Login</title>', header)
    
    new_login_body = """
    <style>
      .login-container-cyber {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        background: var(--bg-dark);
      }
      .cyber-orb {
        position: absolute;
        border-radius: 50%;
        filter: blur(90px);
        opacity: 0.5;
        z-index: 0;
        animation: floatOrb 12s infinite alternate ease-in-out;
      }
      .orb-pink { width: 450px; height: 450px; background: var(--grad-c3); top: -100px; left: -100px; }
      .orb-blue { width: 550px; height: 550px; background: var(--grad-c1); bottom: -150px; right: -100px; }
      
      @keyframes floatOrb {
        0% { transform: translate(0, 0) scale(1); }
        100% { transform: translate(60px, 60px) scale(1.15); }
      }

      .login-glass-panel {
        position: relative;
        z-index: 10;
        width: 100%;
        max-width: 440px;
        background: rgba(var(--bg-card-rgb, 255, 255, 255), 0.05);
        backdrop-filter: blur(32px);
        -webkit-backdrop-filter: blur(32px);
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 28px;
        padding: 48px 40px;
        box-shadow: 0 40px 80px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.2);
        overflow: hidden;
      }
      
      [data-theme="dark"] .login-glass-panel {
        background: rgba(9, 9, 11, 0.55);
        border: 1px solid rgba(255,255,255,0.08);
      }
      [data-theme="light"] .login-glass-panel {
        background: rgba(255, 255, 255, 0.75);
        border: 1px solid rgba(0,0,0,0.06);
      }

      /* Step Transition Logic */
      .login-step {
        display: none;
        animation: slideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      }
      .login-step.active {
        display: block;
      }
      @keyframes slideIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
      }

      /* Custom Input Styles */
      .mobile-input-group {
        display: flex;
        align-items: center;
        background: rgba(128,128,128,0.1);
        border: 1px solid rgba(128,128,128,0.2);
        border-radius: 14px;
        padding: 6px 12px;
        margin-bottom: 24px;
        transition: all 0.3s;
      }
      .mobile-input-group:focus-within {
        border-color: var(--grad-c1);
        background: rgba(128,128,128,0.15);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
      }
      .country-code {
        font-weight: 700;
        font-size: 1.1rem;
        color: var(--text-primary);
        padding-right: 12px;
        border-right: 1px solid rgba(128,128,128,0.3);
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .input-mobile {
        flex: 1;
        background: transparent;
        border: none;
        padding: 12px;
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--text-primary);
        outline: none;
        letter-spacing: 2px;
      }
      .input-mobile::placeholder {
        color: var(--text-muted);
        font-weight: 500;
        letter-spacing: 0;
      }

      /* OTP Grid */
      .otp-grid {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 24px;
      }
      .otp-input {
        width: 48px;
        height: 56px;
        border-radius: 12px;
        background: rgba(128,128,128,0.1);
        border: 1px solid rgba(128,128,128,0.2);
        text-align: center;
        font-size: 1.5rem;
        font-weight: 800;
        color: var(--text-primary);
        outline: none;
        transition: all 0.2s;
      }
      .otp-input:focus {
        border-color: var(--grad-c1);
        background: rgba(128,128,128,0.15);
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.2);
        transform: translateY(-2px);
      }

      .btn-cyber-login {
        width: 100%;
        padding: 16px;
        border-radius: 14px;
        border: none;
        background: var(--theme-btn-grad);
        color: #fff;
        font-size: 1.1rem;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
        box-shadow: 0 8px 25px var(--theme-btn-glow);
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
      }
      .btn-cyber-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px var(--theme-btn-glow);
      }

      /* Decorative */
      .lock-icon-wrapper {
        width: 64px;
        height: 64px;
        background: linear-gradient(135deg, rgba(var(--grad-c1-rgb,99,102,241), 0.1), rgba(var(--grad-c3-rgb,236,72,153), 0.1));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 24px auto;
        color: var(--grad-c1);
      }
    </style>

    <div class="login-container-cyber">
      <div class="cyber-orb orb-pink"></div>
      <div class="cyber-orb orb-blue"></div>
      
      <div class="login-glass-panel">
        
        <!-- STEP 1: MOBILE NUMBER -->
        <div id="step-mobile" class="login-step active">
          <div class="lock-icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="32" height="32">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
            </svg>
          </div>
          <div style="text-align: center; margin-bottom: 32px;">
            <h1 style="font-family: 'Syne', sans-serif; font-size: 1.8rem; margin-bottom: 8px;">Welcome to Namdev</h1>
            <p style="color: var(--text-muted); font-size: 0.95rem;">Enter your mobile number to access your unified dashboard.</p>
          </div>
          
          <form onsubmit="sendOTP(event)">
            <label style="display: block; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 10px; color: var(--text-secondary);">Mobile Number</label>
            <div class="mobile-input-group">
              <div class="country-code">
                <span>🇮🇳</span> +91
              </div>
              <input type="tel" id="mobileNumber" class="input-mobile" placeholder="Enter 10 digits" maxlength="10" pattern="[0-9]{10}" required autocomplete="off">
            </div>
            
            <button type="submit" id="btnSendOTP" class="btn-cyber-login">
              <span>Send Secure OTP</span>
              <svg id="spinnerMobile" style="display: none; animation: spin 1s linear infinite;" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
            </button>
          </form>
          <div style="text-align: center; margin-top: 24px; font-size: 0.8rem; color: var(--text-muted);">
            By proceeding, you agree to our <a href="#" style="color: var(--text-primary); font-weight: 600;">T&C</a> and <a href="#" style="color: var(--text-primary); font-weight: 600;">Privacy Policy</a>.
          </div>
        </div>

        <!-- STEP 2: OTP VERIFICATION -->
        <div id="step-otp" class="login-step">
          <div class="lock-icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="32" height="32">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
          </div>
          <div style="text-align: center; margin-bottom: 32px;">
            <h1 style="font-family: 'Syne', sans-serif; font-size: 1.8rem; margin-bottom: 8px;">Verify OTP</h1>
            <p style="color: var(--text-muted); font-size: 0.95rem;">We've sent a 6-digit code to <br><b id="displayMobile" style="color: var(--text-primary);">+91 99999 99999</b> <span style="color: var(--grad-c1); cursor: pointer; font-size: 0.85rem; margin-left: 8px;" onclick="goBack()">Edit</span></p>
          </div>
          
          <form onsubmit="verifyOTP(event)">
            <div class="otp-grid" id="otpInputs">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
              <input type="text" class="otp-input" maxlength="1" required autocomplete="off">
            </div>
            
            <div style="text-align: right; margin-bottom: 24px;">
              <a href="#" style="color: var(--text-secondary); font-size: 0.85rem; text-decoration: none; font-weight: 600;" onclick="resendOTP(this)">Resend OTP in <span id="timer">00:30</span></a>
            </div>
            
            <button type="submit" id="btnVerifyOTP" class="btn-cyber-login">
              <span>Verify & Login</span>
              <svg id="spinnerOTP" style="display: none; animation: spin 1s linear infinite;" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
            </button>
          </form>
        </div>
        
      </div>
    </div>

    <!-- Interactive Logic -->
    <script>
      // OTP Input Auto-focus Logic
      const otpInputs = document.querySelectorAll('.otp-input');
      otpInputs.forEach((input, index) => {
        input.addEventListener('keyup', (e) => {
          if (e.key >= 0 && e.key <= 9) {
            if (index < otpInputs.length - 1) {
              otpInputs[index + 1].focus();
            }
          } else if (e.key === 'Backspace') {
            if (index > 0) {
              otpInputs[index - 1].focus();
            }
          }
        });
        
        // Prevent non-numeric
        input.addEventListener('keypress', (e) => {
          if (e.key < '0' || e.key > '9') {
            e.preventDefault();
          }
        });
      });

      function sendOTP(e) {
        e.preventDefault();
        const mobile = document.getElementById('mobileNumber').value;
        if (mobile.length !== 10) return;
        
        const btn = document.getElementById('btnSendOTP');
        const spinner = document.getElementById('spinnerMobile');
        
        // UI Loading State
        btn.querySelector('span').style.opacity = '0.5';
        spinner.style.display = 'block';
        
        // Simulate API Call
        setTimeout(() => {
          document.getElementById('displayMobile').innerText = '+91 ' + mobile;
          document.getElementById('step-mobile').classList.remove('active');
          document.getElementById('step-otp').classList.add('active');
          
          btn.querySelector('span').style.opacity = '1';
          spinner.style.display = 'none';
          
          // Focus first OTP box
          setTimeout(() => otpInputs[0].focus(), 100);
          startTimer();
        }, 800);
      }
      
      function verifyOTP(e) {
        e.preventDefault();
        // Check if all filled
        let filled = true;
        otpInputs.forEach(input => { if (!input.value) filled = false; });
        if (!filled) return;
        
        const btn = document.getElementById('btnVerifyOTP');
        const spinner = document.getElementById('spinnerOTP');
        
        btn.querySelector('span').style.opacity = '0.5';
        spinner.style.display = 'block';
        
        // Simulate verification success -> redirect
        setTimeout(() => {
          window.location.href = 'namfindesk.html';
        }, 1200);
      }
      
      function goBack() {
        document.getElementById('step-otp').classList.remove('active');
        document.getElementById('step-mobile').classList.add('active');
        // Clear OTPs
        otpInputs.forEach(input => input.value = '');
      }
      
      let timerInterval;
      function startTimer() {
        clearInterval(timerInterval);
        let timeLeft = 30;
        const timerDisplay = document.getElementById('timer');
        
        timerInterval = setInterval(() => {
          timeLeft--;
          if (timeLeft <= 0) {
            clearInterval(timerInterval);
            timerDisplay.parentElement.innerHTML = 'Didn\\'t receive? <a href="#" style="color: var(--grad-c1);" onclick="resendOTP(this)">Resend Now</a>';
          } else {
            timerDisplay.innerText = '00:' + (timeLeft < 10 ? '0' : '') + timeLeft;
          }
        }, 1000);
      }
      
      function resendOTP(el) {
        el.parentElement.innerHTML = 'Resend OTP in <span id="timer">00:30</span>';
        startTimer();
      }
    </script>
    """
    
    # Cache bust script for the HTML page too
    timestamp = str(int(time.time()))
    header = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', header)
    
    with open('login.html', 'w') as f:
        f.write(header + new_login_body + footer)
    print("Rebuilt login.html with Mobile + OTP Flow")
