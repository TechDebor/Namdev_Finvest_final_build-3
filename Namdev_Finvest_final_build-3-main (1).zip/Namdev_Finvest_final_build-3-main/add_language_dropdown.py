import glob
import re
import time

lang_html = """
            <!-- LANGUAGE SWITCHER -->
            <div class="nav-item-dropdown" style="display: flex; align-items: center; margin-right: 4px;">
              <button class="icon-toggle-btn" aria-label="Change Language" style="cursor: pointer;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
              </button>
              <ul class="dropdown-menu-simple" style="min-width: 160px; right: 0; left: auto; top: 45px;">
                <li><a href="#" onclick="alert('Language changed to English'); return false;">English</a></li>
                <li><a href="#" onclick="alert('भाषा बदलकर हिंदी कर दी गई है। (Language changed to Hindi)'); return false;">हिंदी (Hindi)</a></li>
                <li><a href="#" onclick="alert('भाषा मराठीत बदलली आहे. (Language changed to Marathi)'); return false;">मराठी (Marathi)</a></li>
                <li><a href="#" onclick="alert('ભાષા ગુજરાતીમાં બદલાઈ ગઈ છે. (Language changed to Gujarati)'); return false;">ગુજરાતી (Gujarati)</a></li>
                <li><a href="#" onclick="alert('زبان اردو میں تبدیل کر دی گئی ہے۔ (Language changed to Urdu)'); return false;">اردو (Urdu)</a></li>
                <li><a href="#" onclick="alert('ਭਾਸ਼ਾ ਪੰਜਾਬੀ ਵਿੱਚ ਬਦਲ ਦਿੱਤੀ ਗਈ ਹੈ। (Language changed to Punjabi)'); return false;">ਪੰਜਾਬੀ (Punjabi)</a></li>
                <li><a href="#" onclick="alert('ଭାଷା ଓଡ଼ିଆକୁ ପରିବର୍ତ୍ତିତ ହୋଇଛି। (Language changed to Odia)'); return false;">ଓଡ଼ିଆ (Odia)</a></li>
              </ul>
            </div>
            """

html_files = glob.glob('*.html')
timestamp = str(int(time.time()))

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Check if already added
        if '<!-- LANGUAGE SWITCHER -->' not in content:
            # Inject right before the themeToggleBtn
            target = '<button id="themeToggleBtn"'
            if target in content:
                content = content.replace(target, lang_html + target)
                
                # Bust cache
                content = re.sub(r'href="css/style\.css\?v=\d+"', f'href="css/style.css?v={timestamp}"', content)
                content = re.sub(r'href="css/style\.css"', f'href="css/style.css?v={timestamp}"', content)
                
                with open(file, 'w') as f:
                    f.write(content)
                print(f"Added language dropdown to {file}")
    except Exception as e:
        print(f"Error on {file}: {e}")

