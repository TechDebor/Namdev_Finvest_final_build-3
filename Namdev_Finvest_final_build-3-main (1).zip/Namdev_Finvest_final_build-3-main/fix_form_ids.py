import glob

for f in glob.glob('*.html'):
    if f == 'whatsapp-simulator.html' or f == 'los-bre-engine.html':
        continue
        
    with open(f, 'r') as file:
        content = file.read()
    
    content = content.replace(
        '<input type="text" class="input-quantum-field" placeholder="e.g. Shubh Sharma" required>',
        '<input type="text" id="modalName" class="input-quantum-field" placeholder="e.g. Shubh Sharma" required>'
    )
    content = content.replace(
        '<input type="tel" class="input-quantum-field" placeholder="e.g. 9876543210" required>',
        '<input type="tel" id="modalPhone" class="input-quantum-field" placeholder="e.g. 9876543210" required>'
    )
    
    with open(f, 'w') as file:
        file.write(content)
