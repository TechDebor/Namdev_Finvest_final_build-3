import glob
import re

bulletproof_theme = """
  <!-- UNIVERSAL ANTIGRAVITY THEME ENFORCEMENT -->
  <style>
    :root {
      --bg: #050505 !important;
      --bg-surface: #111111 !important;
      --bg-card: rgba(255,255,255,0.03) !important;
      --text-primary: #ffffff !important;
      --text-secondary: #a0aec0 !important;
      --text-muted: #718096 !important;
      --brand: #ffffff !important;
      --border: rgba(255,255,255,0.1) !important;
      --accent: #5149dc !important;
    }
    body { background-color: var(--bg) !important; color: var(--text-primary) !important; }
    h1, h2, h3, h4, h5, h6 { color: var(--text-primary) !important; }
    p, li, span, div { color: inherit; } 
    
    /* Global fixes for layout breakage */
    .hero-quantum { 
      display: flex !important; 
      flex-direction: column !important; 
      justify-content: center !important; 
      align-items: center !important; 
      text-align: center !important; 
    }
    .hero-quantum > div.container {
      width: 100% !important;
      max-width: 900px !important;
      margin: 0 auto !important;
      display: block !important;
    }
  </style>
"""

all_html_files = glob.glob('*.html')

for file in all_html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Only inject if we haven't already enforced it
        if "UNIVERSAL ANTIGRAVITY THEME ENFORCEMENT" not in content:
            # Replace before closing head
            content = content.replace('</head>', bulletproof_theme + '\n</head>')
            
            # Also enforce body style directly just to be 100% safe
            content = re.sub(r'<body[^>]*>', '<body style="background-color: #050505; color: #ffffff;">', content)

            with open(file, 'w') as f:
                f.write(content)
            print(f"Applied Universal Theme to {file}")
        else:
            print(f"Theme already exists in {file}")
            
    except Exception as e:
        print(f"Error applying theme to {file}: {e}")

