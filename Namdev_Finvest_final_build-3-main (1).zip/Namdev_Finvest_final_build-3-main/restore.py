import glob
import re

# 1. Remove the "UNIVERSAL ANTIGRAVITY THEME ENFORCEMENT" block from all files
html_files = glob.glob('*.html')

for file in html_files:
    try:
        with open(file, 'r') as f:
            content = f.read()

        # Remove the injected style block
        if "<!-- UNIVERSAL ANTIGRAVITY THEME ENFORCEMENT -->" in content:
            # regex to remove the whole block up to </style>
            content = re.sub(r'<!-- UNIVERSAL ANTIGRAVITY THEME ENFORCEMENT -->.*?</style>', '', content, flags=re.DOTALL)
            
        # Revert the forced body style to standard
        content = re.sub(r'<body style="background-color: #050505; color: #ffffff;">', '<body>', content)
        
        with open(file, 'w') as f:
            f.write(content)
        print(f"Cleaned {file}")
    except Exception as e:
        print(f"Failed to clean {file}: {e}")

